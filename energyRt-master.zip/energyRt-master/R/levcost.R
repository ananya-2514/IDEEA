# levcost.R
# Levelized cost of energy (production) for energyRt technology, scenario, and
# model objects.
#
# For a technology object the function builds a minimal single-technology
# energyRt model with unit demand, solves it with GLPK (or a user-supplied
# solver), and returns a per-year LCOE table plus an NPV-weighted scalar,
# together with a structured cost-component breakdown.s
#
# Ported and adapted from IDEEA project (ideea_levcost.R).

# ── S4 generic ─────────────────────────────────────────────────────────────────

# NB: never put a paragraph break (blank roxygen line) INSIDE an \item{}{}
# argument -- roxygen's markdown-to-Rd translation then reports "@details has
# mismatched braces or quotes". Multi-paragraph text goes AFTER \describe{}.
#' Levelized cost of commodity production
#'
#' Computes the levelized cost of energy (LCOE) for a \code{technology},
#' \code{repository}, \code{model}, or \code{scenario} object.
#'
#' \describe{
#'   \item{\code{technology}}{a minimal single-technology energyRt model is built
#'     around the technology, solved, and the LCOE derived from the resulting
#'     cost and production variables.}
#'   \item{\code{repository} / \code{model}}{give the technology \code{name}; the
#'     method selects the related commodity and supply objects from the container
#'     and prices the named technology as above. If an input commodity has no
#'     supply in the container, it returns \code{NULL} with a message unless
#'     \code{autocomplete = TRUE} (which adds a zero-cost / \code{fuel_costs}
#'     supply). The \code{model} method also takes the calendar, region, horizon
#'     and discount rate from the model's configuration (each overridable).}
#'   \item{\code{scenario}}{an \emph{ex-post} cost of the named process in the
#'     \emph{solved} scenario: the discounted sum of its own costs (annualised
#'     investment, fixed and variable O&M, plus attributed fuel cost) divided by
#'     its discounted output. The process may be a \code{technology},
#'     \code{storage} or \code{trade}; each reads its own solved variables
#'     (\code{vTechOut}/\code{vStorageOut}/\code{vTradeIr} and the matching
#'     \code{*Eac}/\code{*Fixom}/\code{*Varom}). For a \code{trade} the
#'     denominator is what ARRIVES, i.e. \code{vTradeIr} times the route
#'     efficiency.}
#' }
#'
#' On the \code{scenario} path, fuel is attributed from the process's own
#' input variable and priced from the \code{supply} objects in the model. A
#' commodity with no \code{supply} -- anything the model produces itself,
#' which is the usual case for a store's charging electricity -- is charged
#' at ZERO here, because what it is worth is the commodity balance's dual and
#' not a slot. The scenario path therefore reports a store's OWN cost per
#' unit discharged, not its delivered cost; use \code{levcost()} on the
#' \code{storage} object with \code{price =} for the latter. Likewise a
#' technology with a \emph{grouped} input (whose per-commodity consumption
#' is not a solution variable) reports no fuel component.
#'
#' @param object  A \code{technology} (or list thereof), \code{repository},
#'   \code{model}, or solved \code{scenario} object.
#' @param comm    Character vector or \code{NULL}.  Output commodity(ies) to
#'   use for LCOE normalisation.  \code{NULL} uses all commodities in the
#'   resolved output group.
#' @param name    Character. For \code{technology}, a name tag; for
#'   \code{repository}/\code{model}/\code{scenario}, the name of the technology /
#'   process to price.
#' @param ...     Additional arguments passed to the underlying implementation.
#'   For \code{technology} objects the most useful are:
#'   \describe{
#'     \item{\code{group}}{Character or \code{NULL}.  Output group name.}
#'     \item{\code{repo}}{A \code{repository} or list of energyRt objects
#'       (supplies, commodities, weather) to supplement the mini-model.}
#'     \item{\code{fuel_costs}}{Named numeric vector \code{[commodity -> cost]}
#'       for input commodities not found in \code{repo}. Auxiliary
#'       commodities consumed by the process (aux inputs) can be priced the
#'       same way; unnamed ones are supplied at zero cost.}
#'     \item{\code{autocomplete}}{Logical, default \code{FALSE}
#'       (\code{repository}/\code{model} methods). When \code{TRUE}, input
#'       commodities without a supply in the container are auto-supplied
#'       (zero-cost, or priced via \code{fuel_costs}) instead of returning
#'       \code{NULL}.}
#'     \item{\code{discount}}{Numeric (0–1), default \code{0.05}.}
#'     \item{\code{base_year}}{Integer or \code{NULL}.}
#'     \item{\code{horizon}}{A \code{horizon} object, numeric year vector, or
#'       \code{NULL} (derives from \code{@olife}).}
#'     \item{\code{calendar}}{A \code{calendar} object or \code{NULL}.}
#'     \item{\code{timeframe}}{\code{"auto"} (default), \code{"ANNUAL"} or
#'       \code{"native"}.
#'       \code{"ANNUAL"} prices the technology on a single annual time-timeslice: any
#'       weather profile is collapsed to an annual capacity factor (applied as the
#'       technology's annual availability), so capacity is sized to serve unit
#'       annual demand at that factor (textbook LCOE). \code{"native"} keeps the
#'       supplied (sub-annual) calendar and normalises by total generation --
#'       useful when the technology is analysed together with storage or
#'       transmission, where sub-annual dispatch matters; it requires a
#'       \code{calendar} holding the process's timeslices and will not choose one
#'       for you.
#'       \code{"auto"} annualizes when that collapse is sound and prices natively
#'       when it is not. It is unsound when a process carries more than one
#'       \code{@weather} factor (the annual mean of a product is not the product of
#'       the annual means, so the pair has no single annual equivalent) or has
#'       parameter rows pinned to a named sub-annual timeslice (the slice stops
#'       existing). An explicit \code{"ANNUAL"} declines in those cases rather than
#'       return a number built on an invalid collapse.}
#'     \item{\code{backstop}}{Logical, default \code{TRUE}. Enables a very
#'       expensive dummy-import slack on the output commodity balance so the
#'       mini-model always solves even when the technology cannot serve a timeslice on
#'       its own; the slack cost is excluded from the LCOE.}
#'     \item{\code{region}}{Character or \code{NULL}.}
#'     \item{\code{weather}}{A \code{weather} object, list of weather objects,
#'       or \code{NULL}.}
#'     \item{\code{frontier}}{Logical, default \code{TRUE}.  When \code{TRUE}
#'       additional solves are performed to map the production frontier for
#'       technologies with multi-commodity grouped output and share constraints
#'       (one solve per output / input corner solution).  Has no effect for
#'       single-output or unconstrained technologies (the frontier is not
#'       meaningful, so only the base solve runs).  Set \code{FALSE} to skip the
#'       extra solves.}
#'     \item{\code{solver}}{Solver spec list, default
#'       \code{solver_options$glpk}.}
#'     \item{\code{method}}{\code{"auto"} (default), \code{"analytic"}, or
#'       \code{"solve"}. The unit-demand annual mini-model has a closed-form
#'       optimum for most technologies; \code{"auto"} computes it analytically
#'       (no solver needed) whenever the technology qualifies and falls back
#'       to the solver otherwise, with a message naming the reason.
#'       \code{"analytic"} refuses non-qualifying technologies instead of
#'       falling back; \code{"solve"} always builds and solves the mini-model.
#'       The analytic result carries the same fields (plus
#'       \code{$method = "analytic"} and \code{$frontier_vertices}, which
#'       reports EVERY corner of the input/output share polytopes with its
#'       per-activity NPV cost breakdown and an \code{optimal} flag);
#'       \code{$scenario} is \code{NULL} on this path. Not analytically
#'       representable (solver required): technology chains,
#'       \code{timeframe = "native"}, \code{afc.*} bounds, availability lower
#'       bounds, \code{optimizeRetirement}, year-varying \code{invcost},
#'       reserve- or availability-constrained supplies, and group
#'       substitution combined with year-varying prices or efficiencies.}
#'     \item{\code{run}}{\code{"single"} (default) or \code{"sequential"} --
#'       only meaningful for a technology declaring vintages or clusters.
#'       \code{"single"} prices every variant in one model (each in its own
#'       region, so they cannot compete); if that model does not solve it is
#'       retried with the dummy-import slack enabled and then, failing that,
#'       falls back to one model per variant. \code{"sequential"} goes straight
#'       to one model per variant, so a single non-converging variant cannot
#'       take the rest down.}
#'     \item{\code{max_failures}}{Integer, default \code{10}. Abort the
#'       sequential fallback after this many consecutive failed variant solves,
#'       to bound the time spent on a technology whose variants all fail.}
#'     \item{\code{as_scenario}}{Logical, default \code{FALSE}.  When
#'       \code{TRUE} the full solved \code{scenario} is returned with LCOE
#'       tables attached to \code{scenario@@misc}.}
#'     \item{\code{verbose}}{Logical, default \code{TRUE}.}
#'   }
#'
#' @return
#'   For \code{technology} input: a list of class \code{"levcost"} with fields:
#'   \describe{
#'     \item{\code{$levcost}}{data.frame – total levelized cost by year.}
#'     \item{\code{$levcost_npv}}{Named numeric – NPV-weighted average LCOE.}
#'     \item{\code{$cost_breakdown}}{data.frame – tidy cost components by year.
#'       Components: \code{eac}, \code{fixom}, \code{varom}, \code{supply},
#'       \code{import}, \code{export} (negative, a credit).}
#'     \item{\code{$cost_breakdown_npv}}{data.frame – NPV-weighted component
#'       breakdown.}
#'     \item{\code{$cost_yearly}}{data.frame – wide undiscounted cost table with
#'       activity, capacity, per-commodity outputs and inputs.}
#'     \item{\code{$levcost_per_act}}{data.frame or \code{NULL}.}
#'     \item{\code{$frontier}}{data.frame or \code{NULL} (requires
#'       \code{frontier = TRUE} and multi-commodity grouped output).}
#'     \item{\code{$scenario}}{The solved \code{scenario} object.}
#'   }
#'   For a list of technology objects: a named list of class
#'   \code{"levcost_list"}.
#'
#'   For a technology declaring \strong{vintages} and/or \strong{clusters}: a
#'   named list of class \code{"levcost_variants"} (which inherits
#'   \code{"levcost_list"}), holding one full \code{"levcost"} result per
#'   variant, keyed by variant name (\code{"PWR_VIN2030"}). Each variant is
#'   priced in its own region so the variants cannot serve each other's demand;
#'   without that isolation they compete for one unit of demand and the result
#'   silently sums across them. The stacked tables are reachable with
#'   \code{levcost(x, by_variant = )}, and \code{autoplot()} compares the
#'   variants.
#'   \code{$frontier} is \code{NULL} on this path -- the frontier corners are a
#'   per-commodity sweep, orthogonal to variants, and are not fanned out.
#'   A technology with no vintages or clusters is unaffected and still returns a
#'   single \code{"levcost"} object.
#'
#' @param by_variant for a technology declaring vintages or clusters: `FALSE`
#'   (default) returns the result object; `TRUE` (= `"levcost"`), `"npv"` or
#'   `"components"` returns that per-variant table instead. Passing an existing
#'   result — `levcost(lc, by_variant = "npv")` — extracts without re-solving.
#' @param by_region `FALSE` (default) prices a process once, in one of the
#'   regions it spans. `TRUE` prices it once PER region and returns a
#'   `levcost_list` named by region — the ladder a technology whose costs or
#'   efficiency vary by region actually has. levcost() builds a single-region
#'   mini-model, so without this a multi-region process reports only its first
#'   region's cost. On a container the entries are named `<process>@<region>`.
#'   A `trade` is unaffected: it spans two regions by construction and is
#'   priced across both at once.
#' @export
#'
#' @include solve.R
#' @examples
#' \dontrun{
#' lc <- levcost(my_tech, discount = 0.07, base_year = 2025)
#' lc$levcost_npv
#' lc$cost_breakdown
#' autoplot(lc)
#' autoplot(lc, type = "npv")
#'
#' # List of technologies (each solved independently):
#' lc_list <- levcost(list(tech1, tech2), discount = 0.07)
#' autoplot(lc_list, type = "npv")
#' }
setGeneric("levcost", function(object, comm, name, ...) {
  standardGeneric("levcost")
})

# `levcost_variants` is the S3 class a variant fan-out returns; registering it
# lets levcost() dispatch on an existing result (`by_variant =` without a
# re-solve). The plain `levcost` result is registered too, so passing one back
# reports what is wrong instead of failing S4 dispatch.
setOldClass(c("levcost_variants", "levcost_list", "list"))
setOldClass(c("levcost", "list"))

# Scratch anchor for levcost mini-scenarios. Keeps them out of the project's
# scenarios store (they used to land under get_scenarios_path() and be indexed
# by refresh_registry() as real scenarios). interpolate_model(ondisk = FALSE)
# creates no directory here -- the path only anchors where the transient
# solver dir lands, and solve_scenario(transient = TRUE) deletes that.
.levcost_scratch_path <- function(name) {
  fp(tempdir(), "energyRt-levcost",
     paste0(.path_slug(name), "_", format(Sys.time(), "%Y%m%d%H%M%OS3")))
}

# Price a process once PER REGION it spans.
#
# levcost() builds a single-region mini-model whose region is synthetic
# ("REGION"), so anything region-aware is invisible to it: a technology whose
# parameters vary by region is priced at ONE of them, and a cluster scoped to a
# region matches none. Pricing region by region restores both -- each run sees
# that region's parameters and the clusters that exist there.
#
# Returns a `levcost_list` named by region, the class the container path
# already returns, so print / autoplot / report handle it unchanged.
#' @noRd
.levcost_each_region <- function(price_one, regions, what = "process") {
  regions <- unique(regions[!is.na(regions) & nzchar(regions)])
  if (length(regions) == 0L) {
    stop("`by_region = TRUE` needs a ", what, " that names its regions; this ",
         "one names none, so there is nothing to price per region.",
         call. = FALSE)
  }
  out <- lapply(regions, function(r)
    tryCatch(price_one(r),
             error = function(e) {
               warning("levcost(): region '", r, "' could not be priced: ",
                       conditionMessage(e), call. = FALSE)
               NULL
             }))
  names(out) <- regions
  out <- Filter(Negate(is.null), out)
  class(out) <- c("levcost_list", "list")
  out
}

setMethod("levcost", "technology",
  function(object, comm, name, by_variant = FALSE, by_region = FALSE, ...) {
    comm_arg <- if (missing(comm)) NULL else comm
    dots <- list(...)
    if (isTRUE(by_region)) {
      return(.levcost_each_region(
        function(r) {
          d <- dots
          d$region <- r
          res <- .levcost_with_cache("technology", object,
                                     c(list(comm = comm_arg), d),
                                     levcost_technology_)
          if (isFALSE(by_variant)) res else .levcost_by_variant(res, by_variant)
        },
        .levcost_tech_regions(object), what = "technology"))
    }
    res <- .levcost_with_cache("technology", object,
                               c(list(comm = comm_arg), dots),
                               levcost_technology_)
    if (isFALSE(by_variant)) res else .levcost_by_variant(res, by_variant)
  })

#' @rdname levcost
setMethod("levcost", "storage", function(object, comm, name, ...) {
  comm_arg <- if (missing(comm)) NULL else comm
  .levcost_with_cache("storage", object, c(list(comm = comm_arg), list(...)),
                      levcost_storage_)
})

#' @rdname levcost
setMethod("levcost", "trade", function(object, comm, name, ...) {
  comm_arg <- if (missing(comm)) NULL else comm
  .levcost_with_cache("trade", object, c(list(comm = comm_arg), list(...)),
                      levcost_trade_)
})

# ── levcost() for containers: repository & model ─────────────────────────────

# The process classes levcost() can price, in the order a name is searched for.
.LEVCOST_CLASSES <- c("technology", "storage", "trade")

# The per-class entry point. Kept as a lookup rather than an S4 dispatch because
# the container path needs to know WHICH class it found before it decides how to
# prepare the object -- a trade must not be region-subset, for one.
.levcost_driver <- function(cls) {
  switch(cls,
         technology = levcost_technology_,
         storage    = levcost_storage_,
         trade      = levcost_trade_,
         stop("levcost(): no engine for class ", cls, call. = FALSE))
}

# Every process in a container that levcost() can price, as
# list(name = , class = , object = ), optionally narrowed to `classes`.
.levcost_processes <- function(container, classes = NULL) {
  cls <- if (is.null(classes)) .LEVCOST_CLASSES else
    intersect(classes, .LEVCOST_CLASSES)
  bad <- setdiff(classes %||% character(0), .LEVCOST_CLASSES)
  if (length(bad))
    stop("levcost(): cannot price class(es) ", paste(bad, collapse = ", "),
         "; supported: ", paste(.LEVCOST_CLASSES, collapse = ", "),
         call. = FALSE)
  out <- list()
  for (cl in cls) {
    objs <- tryCatch(getObjects(container, cl), error = function(e) list())
    for (nm in names(objs))
      out[[length(out) + 1L]] <- list(name = nm, class = cl,
                                      object = objs[[nm]])
  }
  out
}

# Find a named process of any priceable class inside a repository/model/scenario.
# `classes` narrows the search, which is also how a name shared by two classes is
# disambiguated.
.levcost_find_process <- function(container, name, classes = NULL) {
  if (is.null(name) || !nzchar(name)) return(NULL)
  hits <- Filter(function(p) identical(p$name, name),
                 .levcost_processes(container, classes))
  if (!length(hits)) return(NULL)
  if (length(hits) > 1)
    stop("levcost(): '", name, "' names more than one process (",
         paste(vapply(hits, `[[`, character(1), "class"), collapse = ", "),
         "); pass classes = to choose.", call. = FALSE)
  hits[[1]]
}

# Back-compat: the technology-only finder some callers still use.
.levcost_find_tech <- function(container, name) {
  p <- .levcost_find_process(container, name, classes = "technology")
  if (is.null(p)) NULL else p$object
}

# Commodities a process consumes. A trade moves its own commodity rather than
# consuming a different one, so it has no input to cover.
.levcost_input_comms <- function(tech) {
  if (inherits(tech, "trade")) return(character(0))
  ic <- character(0)
  if (.hasSlot(tech, "input") && nrow(tech@input) > 0)
    ic <- unique(as.character(tech@input$comm))
  unique(ic[!is.na(ic) & nzchar(ic)])
}

# Commodities that have a supply object in the container.
.levcost_supplied_comms <- function(container) {
  sups <- tryCatch(getObjects(container, "supply"), error = function(e) list())
  unique(unlist(lapply(sups, function(s) as.character(s@commodity))))
}

# Regions a technology spans (from its region-bearing data slots), so the caller
# can price it in one of them.
.levcost_tech_regions <- function(tech) {
  regs <- character(0)
  for (sl in methods::slotNames(tech)) {
    x <- tryCatch(methods::slot(tech, sl), error = function(e) NULL)
    if (sl == "region" && is.character(x)) regs <- c(regs, x)
    else if (is.data.frame(x) && "region" %in% names(x)) regs <- c(regs, as.character(x$region))
  }
  unique(regs[!is.na(regs) & nzchar(regs)])
}

# The LCOE mini-model is single-region; a kit technology may carry data for
# several regions. Subset every region-bearing slot to `region` (keeping
# region-agnostic NA rows) and pin the @region slot, so the mini-model declares
# exactly the one region it prices.
.levcost_subset_tech_region <- function(tech, region) {
  region <- region[1]
  for (sl in methods::slotNames(tech)) {
    x <- tryCatch(methods::slot(tech, sl), error = function(e) NULL)
    if (sl == "region" && is.character(x) && length(x) > 0) {
      methods::slot(tech, sl) <- region
    } else if (is.data.frame(x) && "region" %in% names(x) && nrow(x) > 0) {
      keep <- is.na(x$region) | as.character(x$region) == region
      methods::slot(tech, sl) <- x[keep, , drop = FALSE]
    }
  }
  tech
}

# Annual (share-weighted) capacity factor of a weather object, by region & year.
# `timeslice_share` (from the native calendar) supplies the per-timeslice weights; when
# absent a plain mean is used. Returns a data.frame(region, year, cf).
.levcost_weather_annual_cf <- function(wobj, timeslice_share) {
  wd <- tryCatch(wobj@weather, error = function(e) NULL)
  if (is.null(wd) || nrow(wd) == 0 || !"wval" %in% names(wd))
    return(data.frame(region = character(), year = integer(), cf = numeric()))
  wcol <- NULL
  if (!is.null(timeslice_share) && "timeslice" %in% names(timeslice_share)) {
    wcol <- if ("share" %in% names(timeslice_share)) "share"
            else if ("weight" %in% names(timeslice_share)) "weight" else NULL
  }
  # NA-safe grouping key over region x year (weather year is often NA = all
  # years; `split()` on a factor would silently drop NA groups).
  agg_by <- function(df, wc) {
    yk  <- ifelse(is.na(df$year), "\rNA", as.character(df$year))
    key <- paste(as.character(df$region), yk, sep = "\r")
    do.call(rbind, lapply(split(df, key), function(d) {
      cf <- if (is.null(wc)) mean(d$wval) else sum(d$wval * d[[wc]]) / sum(d[[wc]])
      data.frame(region = d$region[1], year = d$year[1], cf = cf,
                 stringsAsFactors = FALSE)
    }))
  }
  if (!is.null(wcol)) {
    m <- merge(wd, as.data.frame(timeslice_share)[, c("timeslice", wcol)], by = "timeslice")
    if (nrow(m) > 0) return(agg_by(m, wcol))
  }
  agg_by(wd, NULL)
}

# Collapse a technology's weather dependence to an annual availability factor.
# Each @weather row (weather name + waf.lo/up/fx coefficient) is turned into the
# matching af.lo/up/fx = coefficient x annual-CF row on @af; the @weather slot is
# then cleared so the mini-model needs no weather object or sub-annual calendar.
# Can a process be priced on a collapsed ANNUAL timeframe?
#
# Annualization replaces the calendar with a single ANNUAL slice and rewrites
# each weather profile as one annual capacity factor. Two things make that
# substitution invalid rather than merely approximate:
#
#   * MORE THAN ONE weather factor on one process. `.levcost_weatherize_annual()`
#     emits one `@af` row per `@weather` row, all at `timeslice = NA`, so they
#     collide on a single key. Pre-combining them does not help either: the
#     annual mean of a product is not the product of the annual means unless the
#     series are uncorrelated, so two factors have no single annual equivalent.
#   * SUB-ANNUAL parameter rows. A row pinned to a named timeslice refers to a
#     slice the collapsed calendar no longer contains, so the model either fails
#     its domain check or silently drops the row.
#
# Returns the reasons, empty when the collapse is sound. `auto` falls back to the
# native timeframe on a non-empty result; an explicit `"ANNUAL"` declines.
#' @noRd
.levcost_annual_blockers <- function(techs) {
  if (!is.list(techs)) techs <- list(techs)
  multi <- FALSE
  sub   <- character()
  for (t in techs) {
    if (methods::.hasSlot(t, "weather") && NROW(t@weather) > 1L) multi <- TRUE
    for (sl in methods::slotNames(t)) {
      if (sl == "weather") next
      d <- methods::slot(t, sl)
      if (!is.data.frame(d) || nrow(d) == 0) next
      for (k in intersect(c("timeslice", "slice"), names(d))) {
        v <- unique(as.character(d[[k]]))
        v <- v[!is.na(v) & nzchar(v) & v != "ANNUAL"]
        if (length(v) > 0)
          sub <- c(sub, paste0("@", sl, " (", paste(utils::head(v, 3),
                                                    collapse = ", "), ")"))
      }
    }
  }
  reasons <- character()
  if (multi)
    reasons <- c(reasons, paste0(
      "more than one @weather factor on a single process -- each would become ",
      "its own annual availability row and they collide, and the annual mean of ",
      "a product is not the product of the annual means"))
  if (length(sub) > 0)
    reasons <- c(reasons, paste0(
      "sub-annual parameter rows the collapsed calendar would not contain: ",
      paste(unique(sub), collapse = "; ")))
  reasons
}

.levcost_weatherize_annual <- function(tech, weather_objects, timeslice_share,
                                       verbose = TRUE) {
  wdf <- tech@weather
  if (nrow(wdf) == 0) return(tech)
  wmap <- list()
  for (w in weather_objects) if (isS4(w) && .hasSlot(w, "name")) wmap[[w@name]] <- w
  af_proto <- tech@af[0, , drop = FALSE]
  af_cols  <- names(af_proto)
  new_rows <- list()
  for (i in seq_len(nrow(wdf))) {
    wr    <- wdf[i, , drop = FALSE]
    wname <- as.character(wr$weather)
    wobj  <- wmap[[wname]]
    if (is.null(wobj)) {
      if (verbose) message("levcost(): no weather object '", wname,
                           "' for annual CF of '", tech@name, "'; skipping.")
      next
    }
    cf <- .levcost_weather_annual_cf(wobj, timeslice_share)
    if (nrow(cf) == 0) next
    bound <- NULL
    for (b in c("fx", "up", "lo")) {
      col <- paste0("waf.", b)
      if (col %in% names(wr) && !is.na(wr[[col]])) {
        bound <- b; coef <- as.numeric(wr[[col]]); break
      }
    }
    if (is.null(bound)) { bound <- "up"; coef <- 1 }
    r <- af_proto[rep(1L, nrow(cf)), , drop = FALSE]
    if (nrow(r) == 0) {                       # empty @af: build a fresh frame
      r <- data.frame(region = cf$region, year = cf$year, timeslice = NA_character_,
                      af.lo = NA_real_, af.up = NA_real_, af.fx = NA_real_,
                      rampup = NA_real_, rampdown = NA_real_,
                      stringsAsFactors = FALSE)
      af_cols <- names(r)
    } else {
      r$region <- cf$region; r$year <- cf$year
      if ("timeslice" %in% af_cols) r$timeslice <- NA_character_
    }
    afc <- paste0("af.", bound)
    if (afc %in% af_cols) r[[afc]] <- coef * cf$cf
    new_rows[[length(new_rows) + 1L]] <- r
  }
  if (length(new_rows) > 0) {
    add <- do.call(rbind, new_rows)
    tech@af <- if (nrow(tech@af) > 0) rbind(tech@af, add[, names(tech@af)]) else add
  }
  tech@weather <- tech@weather[0, , drop = FALSE]
  tech
}

# Bring a weather object DOWN to the region levcost is costing.
#
# A profile may be declared at a coarser region than the technology sits in --
# one adm1 series shared by its adm2 children (`mWeatherRegionAt`). The
# single-region mini-model levcost builds knows only the technology's own
# region, so subsetting to it would drop every row and the capacity factor
# would silently vanish: measured on a 2-child fixture, levcost came out
# 0.650514 with the profile at the parent against 0.867352 with a copy per
# child -- the same system, 33% apart, no warning.
#
# The values are identical whichever label they carry, so the nearest ancestor
# the weather serves is RELABELLED to `region`. Returns NULL when nothing
# resolves, leaving the caller's existing behaviour untouched.
#' @noRd
.levcost_localize_weather <- function(w, region, gs = NULL) {
  region <- region[1]
  if (!.hasSlot(w, "weather") || !is.data.frame(w@weather) ||
      nrow(w@weather) == 0 || !"region" %in% names(w@weather)) return(NULL)
  wr <- as.character(w@weather$region)
  if (any(is.na(wr) | wr == region)) return(NULL)   # already usable as-is
  if (is.null(gs) || !is_geoscale(gs)) return(NULL)

  h <- tryCatch(.geo_hierarchy(gs, region), error = function(e) NULL)
  if (is.null(h)) return(NULL)
  anc <- setdiff(as.character(h$region), region)
  cand <- intersect(unique(wr), anc)
  if (length(cand) == 0) return(NULL)
  if (length(cand) > 1) {                            # nearest = finest level
    cand <- cand[which.max(.geo_region_rank(h)[cand])]
  }
  keep <- wr == cand
  w@weather <- w@weather[keep, , drop = FALSE]
  w@weather$region <- region                         # relabel, values unchanged
  if (.hasSlot(w, "region") && is.character(w@region) && length(w@region) > 0)
    w@region <- region
  w
}

# Subset a weather object's @region slot and @weather table to a single region.
.levcost_subset_weather_region <- function(w, region) {
  region <- region[1]
  if (.hasSlot(w, "region") && is.character(w@region) && length(w@region) > 0)
    w@region <- region
  if (.hasSlot(w, "weather") && is.data.frame(w@weather) &&
      "region" %in% names(w@weather) && nrow(w@weather) > 0) {
    keep <- is.na(w@weather$region) | as.character(w@weather$region) == region
    w@weather <- w@weather[keep, , drop = FALSE]
  }
  w
}

# Shared LCOE for a technology named `name` inside a repository/model. Selects
# the related commodity, supply and weather objects from the container; if an
# input commodity has no supply, returns NULL with a message unless
# `autocomplete = TRUE` (which lets the mini-model add a zero-cost /
# `fuel_costs` supply).

# The price `fuel_costs` gives a commodity, else `default`. `fuel_costs` may
# be a named vector or list; `[[` on a named VECTOR errors for a missing
# name (unlike a list), so lookup must go through names().
#' @noRd
.fuel_cost_or <- function(fuel_costs, cm, default = 0) {
  if (is.null(fuel_costs) || !cm %in% names(fuel_costs)) return(default)
  v <- suppressWarnings(as.numeric(fuel_costs[[cm]]))
  if (length(v) == 1 && is.finite(v)) v else default
}

# One un-vintaged instance of a technology: the selected cell (default the
# newest vintage / first cluster -- draw()'s defaults), with the cell's
# investment window and life kept. Used for single-instance analyses
# (cost frontiers, per-activity costs) where the variant fan is not needed.
# Returns the object unchanged when it has no variants.
#' @noRd
.levcost_instance <- function(object, vintage = NULL, cluster = NULL) {
  v <- .tech_variants(object)
  if (is.null(v)) return(object)
  cell <- .resolve_cell(v, vintage, cluster)
  .levcost_devintage(v$objects[[cell$index]], object@region)
}

# Auto-horizon for levcost mini-models. Starts at `base_year` (else the
# earliest declared vintage/window year, else the current year) and runs
# long enough for the LAST vintage to live out its olife -- a horizon that
# ends before a late vintage's investment window made that vintage price
# to zero via the backstop instead of erroring.
#' @noRd
.levcost_auto_horizon <- function(techs, base_year = NULL, verbose = TRUE) {
  if (!is.list(techs)) techs <- list(techs)
  olife_vals <- vapply(techs, function(t) {
    ol <- .lifespan_col(t, "olife")
    if (nrow(ol) == 0) NA_real_ else max(ol$olife, na.rm = TRUE)
  }, numeric(1))
  olife_val <- if (any(is.finite(olife_vals)))
    max(olife_vals, na.rm = TRUE) else NA_real_
  if (!is.finite(olife_val) || olife_val <= 0) {
    olife_val <- 20
    if (verbose) message("No olife found; using default horizon of 20 years.")
  }
  vin_years <- unlist(lapply(techs, function(t) {
    vt <- tryCatch(as.data.frame(t@vintage), error = function(e) NULL)
    if (!is.data.frame(vt) || nrow(vt) == 0) return(integer())
    unlist(lapply(intersect(c("vintage", "start", "end"), names(vt)),
                  function(cc) suppressWarnings(as.integer(vt[[cc]]))))
  }))
  vin_years <- vin_years[is.finite(vin_years)]
  by <- if (!is.null(base_year)) {
    as.integer(base_year)
  } else if (length(vin_years) > 0) {
    min(vin_years)
  } else {
    as.integer(format(Sys.Date(), "%Y"))
  }
  end_y <- max(by, if (length(vin_years) > 0) max(vin_years) else by) +
    as.integer(olife_val) - 1L
  hor_years <- seq(by, end_y)
  if (verbose)
    message("Auto-created horizon: ", min(hor_years), "–",
            max(hor_years), " (", length(hor_years),
            " years) from technology olife",
            if (length(vin_years) > 0) " and vintage windows" else "", ".")
  newHorizon(period = hor_years)
}
.levcost_container <- function(container, name, comm = NULL, autocomplete = FALSE,
                               fuel_costs = NULL, verbose = TRUE,
                               classes = NULL, by_region = FALSE, ...) {
  # No name: price every process the container holds that levcost() can price.
  # `classes` narrows it -- classes = "technology" is exactly the historical
  # single-class behaviour, one process at a time.
  if (is.null(name) || !nzchar(name)) {
    procs <- .levcost_processes(container, classes)
    if (!length(procs)) {
      message("levcost(): the ", class(container)[1], " holds no ",
              "technology, storage or trade to price.")
      return(invisible(NULL))
    }
    out <- lapply(procs, function(p)
      tryCatch(.levcost_container(container, name = p$name, comm = comm,
                                  autocomplete = autocomplete,
                                  fuel_costs = fuel_costs, verbose = verbose,
                                  classes = p$class, by_region = by_region,
                                  ...),
               error = function(e) {
                 warning("levcost(): ", p$class, " '", p$name, "' could not be ",
                         "priced: ", conditionMessage(e), call. = FALSE)
                 NULL
               }))
    names(out) <- vapply(procs, `[[`, character(1), "name")
    out <- Filter(Negate(is.null), out)
    # `by_region` makes each entry a per-region list; flatten to one level so
    # the result stays a plain `levcost_list`, keyed `<process>@<region>`
    if (isTRUE(by_region)) {
      flat <- list()
      for (nm in names(out)) {
        el <- out[[nm]]
        if (inherits(el, "levcost_list")) {
          for (r in names(el)) flat[[paste0(nm, "@", r)]] <- el[[r]]
        } else {
          flat[[nm]] <- el
        }
      }
      out <- flat
    }
    # `levcost_list` is the class the VARIANT path already returns, so its
    # print / autoplot / plot methods and report()'s handling of a multi-result
    # apply to this unchanged
    class(out) <- c("levcost_list", "list")
    return(out)
  }
  proc <- .levcost_find_process(container, name, classes)
  if (is.null(proc)) {
    message("levcost(): process '", name, "' not found in the ",
            class(container)[1], ".")
    return(invisible(NULL))
  }
  tech <- proc$object
  cls  <- proc$class
  in_comms <- .levcost_input_comms(tech)
  # a commodity is "covered" if the container supplies it, an IMPORT prices it
  # (rest-of-world fuel at its import price), or `fuel_costs` prices it
  imps <- tryCatch(getObjects(container, "import"), error = function(e) list())
  for (im in imps) {
    cm <- tryCatch(as.character(im@commodity)[1], error = function(e) NA_character_)
    if (is.na(cm) || cm %in% names(fuel_costs)) next
    pr <- tryCatch(suppressWarnings(as.numeric(im@import$price)), error = function(e) NULL)
    pr <- pr[is.finite(pr)]
    if (length(pr) > 0) fuel_costs[cm] <- mean(pr)
  }
  covered  <- unique(c(.levcost_supplied_comms(container), names(fuel_costs)))
  missing  <- setdiff(in_comms, covered)
  if (length(missing) > 0 && !isTRUE(autocomplete)) {
    message("levcost(): technology '", name, "' consumes commodity(ies) with no ",
            "supply in the ", class(container)[1], ": ",
            paste(missing, collapse = ", "), ".\n",
            "  Set autocomplete = TRUE to add zero-cost supplies, or pass e.g. ",
            "fuel_costs = c(", missing[1], " = <price>).")
    return(invisible(NULL))
  }
  dots <- list(...)
  # the mini-model is single-region: pick one region the tech spans and subset
  # its data to it (a multi-region kit tech would otherwise reference regions the
  # mini-model has not declared, or mismatch demand rows)
  reg1 <- dots$region
  tr <- .levcost_tech_regions(tech)
  # `by_region`: one mini-model per region the process spans, rather than one
  # for its first region. A trade is excluded -- it spans two regions by
  # construction and is priced across both at once.
  if (isTRUE(by_region) && !identical(cls, "trade")) {
    rr <- if (is.null(reg1)) tr else intersect(as.character(reg1), tr)
    if (length(rr) > 1L) {
      return(.levcost_each_region(
        function(r) {
          d <- dots
          d$region <- r
          do.call(.levcost_container,
                  c(list(container = container, name = name, comm = comm,
                         autocomplete = autocomplete, fuel_costs = fuel_costs,
                         verbose = verbose, classes = classes,
                         by_region = FALSE), d))
        },
        rr, what = class(container)[1]))
    }
  }
  if (is.null(reg1)) {
    reg1 <- if (length(tr) > 0) tr[1] else NULL
  } else {
    # The container methods pass the WHOLE region set (a model hands over
    # `cfg@region`), so taking `reg1[1]` would price EVERY process as if it
    # lived in the container's first region. One that does not then has its
    # region-keyed rows -- invcost, fixom, ceff -- subset away below, and the
    # result is a levelized cost carrying fuel only: about 25x too cheap, with
    # no warning. Pick a region the process actually lives in.
    hit <- intersect(as.character(reg1), tr)
    reg1 <- if (length(hit) > 0) hit[1] else
      if (length(tr) > 0) tr[1] else reg1[1]
  }
  # A trade spans two regions by construction and its costs are charged in
  # BOTH; subsetting it to one would silently halve the capital charge.
  if (!is.null(reg1) && !identical(cls, "trade")) {
    tech <- .levcost_subset_tech_region(tech, reg1)
    dots$region <- reg1
  }
  # attach ONLY the weather object(s) this technology references (thermal techs
  # have an empty @weather slot and need none), region-subset to `reg1` so they
  # do not reference regions the single-region mini-model has not declared
  if (is.null(dots$weather)) {
    wneed <- tryCatch(unique(as.character(tech@weather$weather)), error = function(e) character(0))
    wneed <- wneed[!is.na(wneed) & nzchar(wneed)]
    if (length(wneed) > 0) {
      wall <- tryCatch(getObjects(container, "weather"), error = function(e) list())
      wsel <- wall[intersect(names(wall), wneed)]
      if (length(wsel) > 0) {
        if (!is.null(reg1)) {
          gs1 <- tryCatch(getGeoscale(container), error = function(e) NULL)
          wsel <- lapply(wsel, function(w) {
            loc <- .levcost_localize_weather(w, reg1, gs1)
            if (!is.null(loc)) loc else
              .levcost_subset_weather_region(w, region = reg1)
          })
        }
        dots$weather <- unname(wsel)
      }
    }
  }
  # the container's commodities + supplies become the levcost `repo`
  repo <- c(tryCatch(getObjects(container, "commodity"), error = function(e) list()),
            tryCatch(getObjects(container, "supply"),     error = function(e) list()))
  # container-priced processes cache under the CONTAINER's owning folder
  # (<scenario>/levcost/, models/<n>@<h8>/levcost/) unless redirected
  if (is.null(dots[["cache_dir"]])) {
    own <- .object_store_dir(container)
    if (!is.null(own)) dots$cache_dir <- fp(own, "levcost")
  }
  args <- c(list(comm = comm, repo = repo, fuel_costs = fuel_costs,
                 verbose = verbose), dots)
  # a trade is priced across BOTH endpoints, so the single-region arguments the
  # technology path resolves above are meaningless to it
  if (identical(cls, "trade")) args$region <- NULL
  .levcost_with_cache(cls, tech, args, .levcost_driver(cls))
}

#' @rdname levcost
setMethod("levcost", "repository",
  function(object, comm, name, by_variant = FALSE, by_region = FALSE, ...) {
    comm_arg <- if (missing(comm)) NULL else comm
    name_arg <- if (missing(name)) NULL else name
    res <- .levcost_container(object, name = name_arg, comm = comm_arg,
                              by_region = by_region, ...)
    if (isFALSE(by_variant) || inherits(res, "levcost_list")) res else
      .levcost_by_variant(res, by_variant)
  })

# The scalar rate a levelised cost is annuitised at: the cost of CAPITAL, not
# the social discount rate. Levelised cost answers "what must this unit earn per
# year to repay its investor", which is a financing question; `sdr` prices the
# system's cost stream to society and has no business here.
.levcost_model_discount <- function(cfg, default = 0.05) {
  d <- tryCatch(cfg@discount, error = function(e) NULL)
  if (is.null(d) || !is.data.frame(d) || nrow(d) == 0) return(default)
  if (!"wacc" %in% names(d)) return(default)
  v <- suppressWarnings(as.numeric(d[["wacc"]]))
  v <- v[is.finite(v) & v > 0]
  if (length(v) > 0) mean(v) else default
}

#' @rdname levcost
setMethod("levcost", "model",
          function(object, comm, name, by_variant = FALSE, by_region = FALSE, ...) {
  comm_arg <- if (missing(comm)) NULL else comm
  name_arg <- if (missing(name)) NULL else name
  cfg  <- object@config
  dots <- list(...)
  # take calendar / region / horizon / discount from the model unless overridden
  cal <- if (!is.null(dots$calendar)) dots$calendar else {
    x <- tryCatch(cfg@calendar, error = function(e) NULL)
    if (!is.null(x) && length(x@timeframe_rank) > 1) x else NULL
  }
  reg <- if (!is.null(dots$region)) dots$region else {
    x <- tryCatch(cfg@region, error = function(e) NULL)
    if (length(x) > 0) x else NULL      # all model regions (mini-model declares them)
  }
  hor <- if (!is.null(dots$horizon)) dots$horizon else {
    x <- tryCatch(cfg@horizon, error = function(e) NULL)
    if (!is.null(x) && nrow(x@intervals) > 0) x else NULL
  }
  disc <- if (!is.null(dots$discount)) dots$discount else .levcost_model_discount(cfg)
  dots$calendar <- dots$region <- dots$horizon <- dots$discount <- NULL
  res <- do.call(.levcost_container,
                 c(list(object, name = name_arg, comm = comm_arg,
                        calendar = cal, region = reg, horizon = hor,
                        discount = disc, by_region = by_region), dots))
  if (isFALSE(by_variant) || inherits(res, "levcost_list")) res else
    .levcost_by_variant(res, by_variant)
})

#' @rdname levcost
setMethod("levcost", "scenario", function(object, comm, name, ...) {
  dots <- list(...)
  by_variant <- if (is.null(dots$by_variant)) FALSE else dots$by_variant
  dots$by_variant <- NULL
  res <- do.call(.levcost_scenario,
                 c(list(object, name = if (missing(name)) NULL else name,
                        comm = if (missing(comm)) NULL else comm), dots))
  # same contract as the object path: TRUE / "npv" / "components" reduce a
  # multi-variant result to its tidy table, anything else returns the object
  if (isFALSE(by_variant) || !inherits(res, "levcost_variants")) res else
    .levcost_by_variant(res, by_variant)
})

# Fuel cost of a process in a solved scenario: sum over inputs of
# vTechInp[tech, comm] x mean supply price of that commodity, by year.
# Which solved variables carry a class's output and costs, and which index
# column names the process. Everything class-specific about pricing a SOLVED
# scenario lives here; `.levcost_scenario()` below is otherwise class-agnostic.
#
# `deliver_eff` matters for trade only: `vTradeIr` is what LEAVES the sending
# region, so what arrives is `vTradeIr * teff`. `vStorageOut` and `vTechOut` are
# already post-efficiency.
.LEVCOST_SCEN_VARS <- list(
  technology = list(index = "tech",  out = "vTechOut",
                    eac = "vTechEac", fixom = "vTechFixom",
                    varom = "vTechVarom", inp = "vTechInp"),
  storage    = list(index = "stg",   out = "vStorageOut",
                    eac = "vStorageEac", fixom = "vStorageFixom",
                    varom = "vStorageVarom", inp = "vStorageInp"),
  trade      = list(index = "trade", out = "vTradeIr",
                    eac = "vTradeEac", fixom = "vTradeFixom",
                    varom = NULL, inp = NULL)
)

# The class of a named process in a solved scenario's model.
.levcost_scen_class <- function(scen, name) {
  mdl <- tryCatch(scen@model, error = function(e) NULL)
  if (is.null(mdl)) return(NULL)
  for (cl in .LEVCOST_CLASSES) {
    objs <- tryCatch(getObjects(mdl, cl), error = function(e) list())
    if (name %in% names(objs)) return(cl)
  }
  NULL
}

.levcost_scenario_fuel <- function(scen, name, cls = "technology") {
  vars <- .LEVCOST_SCEN_VARS[[cls]]
  if (is.null(vars) || is.null(vars$inp))
    return(setNames(numeric(0), character(0)))
  inp <- .levcost_scen_get(scen, vars$inp, vars$index, name)
  .levcost_scenario_fuel_(inp, scen)
}

# One solved variable as an annual data.frame, filtered to the named process by
# whichever index column its class uses.
.levcost_scen_get <- function(scen, var, index, name) {
  if (is.null(var)) return(NULL)
  args <- list(scen, var, merge = TRUE, timeframe = "lowest")
  args[[index]] <- name
  tryCatch(do.call(getData, args), error = function(e) NULL)
}

.levcost_scenario_fuel_ <- function(inp, scen) {
  # `timeframe = "lowest"` is pinned by the caller, not inherited: levcost wants
  # ANNUAL totals, and the getData() default is now "highest" (native).
  if (is.null(inp) || !nrow(inp)) return(setNames(numeric(0), character(0)))
  sups <- tryCatch(getObjects(scen@model, "supply"), error = function(e) list())
  price <- list()
  for (s in sups) {
    cm <- as.character(s@commodity)
    av <- tryCatch(as.data.frame(s@supply), error = function(e) NULL)
    if (!is.null(av) && "cost" %in% names(av) && nrow(av) > 0)
      price[[cm]] <- mean(suppressWarnings(as.numeric(av$cost)), na.rm = TRUE)
  }
  # A commodity with no `supply` object has no price here -- it is produced
  # inside the model, and what it is worth is the balance dual, not a slot.
  # `unlist()` on all-NULL lookups returns NULL, which silently collapsed
  # `inp$value * pr` to length zero and made aggregate() fail; charge 0 and let
  # the caller's documentation say so.
  pr <- vapply(as.character(inp$comm), function(cm) {
    v <- price[[cm]]
    if (is.null(v) || !isTRUE(is.finite(v))) 0 else as.numeric(v)
  }, numeric(1), USE.NAMES = FALSE)
  a <- aggregate(inp$value * pr, list(year = as.integer(inp$year)), sum, na.rm = TRUE)
  setNames(a$x, as.character(a$year))
}

# A scenario holds EXPANDED processes (`EWIN_VIN2035_CL01`), while the name a
# caller knows is usually the base one `getVariants()` reports. Resolve each
# given name to the processes it stands for: itself when the scenario declares
# it, otherwise every variant of that base. An unknown name is passed through so
# the caller gets the "not a technology ..." message rather than silence.
#' @noRd
.levcost_scen_names <- function(scen, name) {
  prov <- tryCatch(getVariants(scen), error = function(e) NULL)
  unlist(lapply(as.character(name), function(nm) {
    if (!is.null(.levcost_scen_class(scen, nm))) return(nm)
    if (is.null(prov) || !NROW(prov)) return(nm)
    v <- prov$name[!is.na(prov$base) & prov$base == nm]
    if (length(v)) v else nm
  }), use.names = FALSE)
}

# Ex-post levelized cost of a process in a SOLVED scenario: the discounted sum of
# the process's own costs (annualised investment `vTechEac`, `vTechFixom`,
# `vTechVarom`, plus attributed fuel cost) divided by its discounted output.
.levcost_scenario <- function(scen, name, comm = NULL, discount = NULL,
                              base_year = NULL, verbose = TRUE, ...) {
  if (is.null(name) || !length(name) || !any(nzchar(as.character(name)))) {
    message("levcost(): please give the process `name = ` to price."); return(invisible(NULL))
  }

  # One call may name several processes, or one base that expands into many.
  # Price each and bundle them exactly as the declared-object path does, so
  # `autoplot()`, `by_variant = ` and the report plumbing see one shape.
  nms <- unique(.levcost_scen_names(scen, name))
  if (length(nms) > 1L) {
    # A variant the solver never built has no output to divide by, which is not
    # an error here -- it is the usual case for the grades that lost. Report
    # them once, rather than one message per variant.
    per_variant <- suppressMessages(lapply(nms, function(nm)
      .levcost_scenario(scen, name = nm, comm = comm, discount = discount,
                        base_year = base_year, verbose = FALSE, ...)))
    names(per_variant) <- nms
    per_variant <- Filter(function(x) inherits(x, "levcost"), per_variant)
    skipped <- setdiff(nms, names(per_variant))
    if (length(skipped) && isTRUE(verbose)) {
      message("levcost(): ", length(skipped), " of ", length(nms),
              " variant(s) were not priced -- no output in the solved ",
              "scenario: ", paste(utils::head(skipped, 5), collapse = ", "),
              if (length(skipped) > 5) ", ..." else "")
    }
    if (!length(per_variant)) return(invisible(NULL))
    if (length(per_variant) == 1L) return(per_variant[[1]])
    prov <- tryCatch(getVariants(scen), error = function(e) NULL)
    bases <- if (is.null(prov)) character(0) else
      unique(prov$base[match(names(per_variant), prov$name)])
    bases <- bases[!is.na(bases)]
    if (length(bases) == 1L && !is.null(prov)) {
      return(.levcost_variants_object(per_variant, prov, bases))
    }
    # several unrelated processes: a plain list, since `levcost_variants`
    # describes the variants of ONE base
    class(per_variant) <- c("levcost_list", "list")
    return(per_variant)
  }
  name <- nms[[1L]]
  # `@stage`, not the number of variables: `modOut` pre-populates one empty
  # `variable` per declared variable, so a failed solve has as many as a good one.
  if (!isTRUE(scen@status$interpolated) ||
      is.null(tryCatch(scen@modOut, error = function(e) NULL)) ||
      !identical(scen@modOut@stage, "solved")) {
    message("levcost(): the scenario is not solved -- solve it first."); return(invisible(NULL))
  }
  cls <- .levcost_scen_class(scen, name)
  if (is.null(cls)) {
    message("levcost(): process '", name, "' is not a technology, storage or ",
            "trade in the scenario's model."); return(invisible(NULL))
  }
  vars <- .LEVCOST_SCEN_VARS[[cls]]
  out_all <- .levcost_scen_get(scen, vars$out, vars$index, name)
  if (is.null(out_all) || !nrow(out_all)) {
    message("levcost(): process '", name, "' has no output in the solved scenario."); return(invisible(NULL))
  }
  # `vTradeIr` is what LEAVES the sending region; what arrives -- the thing a
  # levelized cost is per unit OF -- is that times the route's efficiency.
  if (identical(cls, "trade")) {
    teff <- tryCatch({
      td <- getObjects(scen@model, "trade")[[name]]@trade
      if (NROW(td) && "teff" %in% names(td)) {
        v <- unique(stats::na.omit(as.numeric(td$teff)))
        if (length(v) == 1L) v else 1
      } else 1
    }, error = function(e) 1)
    out_all$value <- out_all$value * teff
  }
  if (!is.null(comm)) out_all <- out_all[as.character(out_all$comm) %in% comm, , drop = FALSE]
  ms <- suppressWarnings(as.integer(scen@modInp@sets$year))
  ms <- ms[is.finite(ms)]; if (!length(ms)) ms <- sort(unique(as.integer(out_all$year)))
  if (is.null(base_year)) base_year <- min(ms)
  if (is.null(discount)) discount <- .levcost_model_discount(scen@settings)

  by_year <- function(df) {
    if (is.null(df) || !nrow(df)) return(setNames(numeric(0), character(0)))
    a <- aggregate(df$value, list(year = as.integer(df$year)), sum, na.rm = TRUE)
    setNames(a$x, as.character(a$year))
  }
  gy <- function(v) by_year(.levcost_scen_get(scen, v, vars$index, name))
  eac <- gy(vars$eac); fixom <- gy(vars$fixom); varom <- gy(vars$varom)
  fuel <- .levcost_scenario_fuel(scen, name, cls)
  out  <- by_year(out_all)

  yrs <- sort(unique(as.integer(c(names(eac), names(fixom), names(varom),
                                  names(fuel), names(out)))))
  pick <- function(v, y) { x <- v[as.character(y)]; x[is.na(x)] <- 0; unname(x) }
  comp <- data.frame(
    year  = yrs,
    eac   = pick(eac, yrs),   fixom = pick(fixom, yrs),
    varom = pick(varom, yrs), fuel  = pick(fuel, yrs),
    output = pick(out, yrs), stringsAsFactors = FALSE)
  comp$total <- comp$eac + comp$fixom + comp$varom + comp$fuel
  disc <- (1 + discount)^(comp$year - base_year)
  npv_cost <- sum(comp$total / disc)
  npv_out  <- sum(comp$output / disc)
  lcoe_npv <- if (is.finite(npv_out) && npv_out > 0) npv_cost / npv_out else NA_real_

  comp$levcost <- ifelse(comp$output > 0, comp$total / comp$output, NA_real_)
  # component name "supply" matches the technology levcost / autoplot convention
  breakdown <- data.frame(
    year = rep(comp$year, 4),
    component = rep(c("eac", "fixom", "varom", "supply"), each = nrow(comp)),
    value = c(comp$eac, comp$fixom, comp$varom, comp$fuel), stringsAsFactors = FALSE)
  bd_npv <- aggregate(value ~ component,
    transform(breakdown, value = value / rep((1 + discount)^(comp$year - base_year), 4)),
    sum)
  bd_npv$value <- bd_npv$value / npv_out

  structure(list(
    levcost = data.frame(tech = name, comm = paste(unique(out_all$comm), collapse = "+"),
                         year = comp$year, levcost = comp$levcost, stringsAsFactors = FALSE),
    levcost_npv = setNames(lcoe_npv, name),
    cost_breakdown = breakdown, cost_breakdown_npv = bd_npv,
    cost_yearly = comp, units = list(costs = "MEUR", activity = "PJ"),
    scenario = scen), class = "levcost")
}

# ── tech_share_frontier ─────────────────────────────────────────────────────────
# Standalone helper: extract feasible share ranges for ALL grouped inputs and
# outputs of a technology.  No solve required – purely geometric.
#
# Returns a data.frame with columns:
#   tech, direction ("input"/"output"), group, comm, others,
#   share_lo, share_hi           – direct per-commodity constraints
#   share_lo_eff, share_hi_eff   – effective range after intersecting all group
#                                  member constraints (the true feasible band)
#
# Only groups where at least one commodity has an explicit grp.share.up or
# grp.share.lo > 0 are included (skip fully-unconstrained groups).

#' Extract feasible share ranges for grouped inputs/outputs
#'
#' Purely geometric helper — no model solve required.  Returns the feasible
#' share band for each commodity in each constrained input or output group of
#' the technology.
#'
#' @param object A \code{technology} S4 object.
#' @return A \code{data.frame} or \code{NULL} if no constrained groups found.
#' @export
#' @examples
#' # a co-firing plant whose biomass may cover at most 30% of the fuel group
#' chp <- newTechnology(
#'   "CHP",
#'   input   = data.frame(comm = c("COA", "BIO"), group = "fuel"),
#'   output  = data.frame(comm = "ELC"),
#'   group   = data.frame(group = "fuel", unit = "MMBtu"),
#'   ceff    = data.frame(comm = c("COA", "BIO"), cinp2use = c(0.40, 0.35),
#'                        grp.share.up = c(1, 0.3)),
#'   cap2act = 8760
#' )
#'
#' # the feasible share band per commodity, and what it does to efficiency
#' tech_share_frontier(chp)
tech_share_frontier <- function(object) {
  stopifnot(inherits(object, "technology"))
  tech_name <- if (nzchar(object@name)) object@name else "TECH"

  .extract_shares <- function(comms) {
    su <- setNames(rep(NA_real_, length(comms)), comms)
    sl <- setNames(rep(0,        length(comms)), comms)
    if (nrow(object@ceff) == 0) return(list(up = su, lo = sl))
    ci <- object@ceff[object@ceff$comm %in% comms, , drop = FALSE]
    if ("grp.share.up" %in% names(ci))
      for (cm in comms) {
        r <- ci[ci$comm == cm & !is.na(ci$grp.share.up), , drop = FALSE]
        if (nrow(r) > 0) su[[cm]] <- r$grp.share.up[1]
      }
    if ("grp.share.lo" %in% names(ci))
      for (cm in comms) {
        r <- ci[ci$comm == cm & !is.na(ci$grp.share.lo), , drop = FALSE]
        if (nrow(r) > 0) sl[[cm]] <- r$grp.share.lo[1]
      }
    if ("grp.share.fx" %in% names(ci))
      for (cm in comms) {
        r <- ci[ci$comm == cm & !is.na(ci$grp.share.fx), , drop = FALSE]
        if (nrow(r) > 0) { su[[cm]] <- r$grp.share.fx[1]; sl[[cm]] <- r$grp.share.fx[1] }
      }
    list(up = su, lo = sl)
  }

  .eff_range <- function(su, sl) {
    comms  <- names(su)
    hi     <- ifelse(is.finite(su), su, 1)
    lo     <- sl
    lo_eff <- setNames(numeric(length(comms)), comms)
    hi_eff <- setNames(numeric(length(comms)), comms)
    for (cm in comms) {
      others_hi_sum <- sum(hi[names(hi) != cm])
      others_lo_sum <- sum(lo[names(lo) != cm])
      raw_lo <- if (is.finite(sl[[cm]])) sl[[cm]] else 0
      raw_hi <- if (is.finite(su[[cm]])) su[[cm]] else 1
      lo_eff[[cm]] <- max(raw_lo, 1 - others_hi_sum)
      hi_eff[[cm]] <- min(raw_hi, 1 - others_lo_sum)
    }
    list(lo_eff = lo_eff, hi_eff = hi_eff)
  }

  all_rows <- list()

  # Input groups
  in_df     <- object@input
  in_groups <- character(0)
  if ("group" %in% names(in_df))
    in_groups <- unique(in_df$group[!is.na(in_df$group) & nzchar(as.character(in_df$group))])

  for (grp in in_groups) {
    gc  <- in_df$comm[!is.na(in_df$group) & as.character(in_df$group) == grp]
    sh  <- .extract_shares(gc)
    if (!any(is.finite(sh$up[gc]) | (sh$lo[gc] > 0))) next
    eff <- .eff_range(sh$up, sh$lo)
    for (cm in gc) {
      all_rows[[paste("in", grp, cm, sep = "_")]] <- data.frame(
        tech         = tech_name, direction  = "input",  group = grp, comm = cm,
        others       = paste(setdiff(gc, cm), collapse = "+"),
        n_in_group   = length(gc),
        share_lo     = if (is.finite(sh$lo[[cm]])) sh$lo[[cm]] else 0,
        share_hi     = if (is.finite(sh$up[[cm]])) sh$up[[cm]] else 1,
        share_lo_eff = max(0, eff$lo_eff[[cm]]),
        share_hi_eff = min(1, eff$hi_eff[[cm]]),
        stringsAsFactors = FALSE
      )
    }
  }

  # Output groups
  out_df     <- object@output
  out_groups <- character(0)
  if ("group" %in% names(out_df))
    out_groups <- unique(out_df$group[!is.na(out_df$group) & nzchar(as.character(out_df$group))])

  for (grp in out_groups) {
    gc  <- out_df$comm[!is.na(out_df$group) & as.character(out_df$group) == grp]
    if (length(gc) < 2) next
    sh  <- .extract_shares(gc)
    if (!any(is.finite(sh$up[gc]) | (sh$lo[gc] > 0))) next
    eff <- .eff_range(sh$up, sh$lo)
    for (cm in gc) {
      all_rows[[paste("out", grp, cm, sep = "_")]] <- data.frame(
        tech         = tech_name, direction  = "output", group = grp, comm = cm,
        others       = paste(setdiff(gc, cm), collapse = "+"),
        n_in_group   = length(gc),
        share_lo     = if (is.finite(sh$lo[[cm]])) sh$lo[[cm]] else 0,
        share_hi     = if (is.finite(sh$up[[cm]])) sh$up[[cm]] else 1,
        share_lo_eff = max(0, eff$lo_eff[[cm]]),
        share_hi_eff = min(1, eff$hi_eff[[cm]]),
        stringsAsFactors = FALSE
      )
    }
  }

  if (length(all_rows) == 0L) return(NULL)
  df <- do.call(rbind, all_rows)
  rownames(df) <- NULL
  df
}

# ── levcost_chain_ ──────────────────────────────────────────────────────────────
# Private implementation for chain LCOE: builds ONE model from an ordered list
# of technology objects, connecting intermediate commodities automatically.

levcost_chain_ <- function(
    object,
    comm        = NULL,
    repo        = NULL,
    fuel_costs  = NULL,
    discount    = 0.05,
    base_year   = NULL,
    horizon     = NULL,
    calendar    = NULL,
    region      = NULL,
    solver      = solver_options$glpk,
    verbose     = TRUE,
    ...
) {
  if (length(object) == 0) stop("`object` is an empty list.")
  if (!all(sapply(object, inherits, "technology")))
    stop("All elements of `object` must be energyRt 'technology' objects.")

  tech_names <- sapply(object, function(t) {
    nm <- t@name
    if (length(nm) == 1 && nzchar(nm)) nm else NA_character_
  })
  chain_name <- paste(tech_names, collapse = "+")

  # ── 1. Classify commodities ────────────────────────────────────────────────
  all_inputs  <- unique(unlist(lapply(object, function(t) t@input$comm)))
  all_outputs <- unique(unlist(lapply(object, function(t) t@output$comm)))

  intermediate  <- intersect(all_inputs, all_outputs)
  external_inps <- setdiff(all_inputs,  all_outputs)   # need supply
  terminal_outs <- setdiff(all_outputs, all_inputs)    # need demand

  if (verbose) {
    message("Chain: ", chain_name)
    if (length(intermediate)  > 0) message("  Intermediate:    ", paste(intermediate,  collapse = ", "))
    if (length(external_inps) > 0) message("  External inputs: ", paste(external_inps, collapse = ", "))
    if (length(terminal_outs) > 0) message("  Terminal outputs: ", paste(terminal_outs, collapse = ", "))
  }

  # ── 2. Resolve terminal output (normaliser) ───────────────────────────────
  if (!is.null(comm)) {
    if (!comm %in% terminal_outs)
      stop("Commodity '", comm, "' is not a terminal output of the chain.\n",
           "Terminal outputs: ", paste(terminal_outs, collapse = ", "))
    norm_comm <- comm
  } else if (length(terminal_outs) == 1) {
    norm_comm <- terminal_outs
  } else if (length(terminal_outs) == 0) {
    stop("No terminal output found (all outputs are consumed within the chain). ",
         "Check that `object` is ordered correctly.")
  } else {
    stop("Multiple terminal outputs: ", paste(terminal_outs, collapse = ", "),
         ".\nSpecify one via `comm = `.")
  }

  # ── 3. Resolve region ─────────────────────────────────────────────────────
  if (is.null(region)) {
    reg_cands <- unique(unlist(lapply(object, function(t) {
      r <- unique(na.omit(t@region))
      r[nzchar(as.character(r))]
    })))
    region <- if (length(reg_cands) > 0) reg_cands[1] else "REGION"
    if (verbose) {
      if (length(reg_cands) == 0)  message("No region found; using 'REGION'.")
      else if (length(reg_cands) > 1) message("Multiple regions; using '", region, "'.")
    }
  }

  # ── 4. Resolve horizon ────────────────────────────────────────────────────
  if (inherits(horizon, "horizon")) {
    hor       <- horizon
    hor_years <- sort(hor@period)
  } else if (is.numeric(horizon) || is.integer(horizon)) {
    hor_years <- sort(as.integer(horizon))
    hor       <- newHorizon(period = hor_years)
  } else {
    hor       <- .levcost_auto_horizon(object, base_year, verbose)
    hor_years <- sort(hor@period)
  }
  if (is.null(base_year)) base_year <- min(hor_years)

  # ── 5. Calendar ───────────────────────────────────────────────────────────
  if (is.null(calendar)) calendar <- newCalendar()

  # ── 6. Pull supplies / commodities from repo ──────────────────────────────
  repo_supplies <- list()
  repo_comms    <- list()
  if (!is.null(repo)) {
    objs <- if (inherits(repo, "repository")) repo@data else
      if (is.list(repo)) repo else
        stop("`repo` must be a 'repository' object or a named list.")
    for (obj in objs) {
      if (inherits(obj, "supply"))    repo_supplies[[if (nzchar(obj@commodity)) obj@commodity else obj@name]] <- obj
      if (inherits(obj, "commodity")) repo_comms[[obj@name]] <- obj
    }
  }

  # ── 7. Build commodity objects ────────────────────────────────────────────
  all_comms <- unique(c(all_inputs, all_outputs))
  commodity_objects <- list()
  for (cm in all_comms) {
    if (!is.null(repo_comms[[cm]])) {
      cm_obj <- repo_comms[[cm]]
      if (isS4(cm_obj) && .hasSlot(cm_obj, "emis") && nrow(cm_obj@emis) > 0)
        cm_obj@emis <- cm_obj@emis[0L, , drop = FALSE]
      # A screening model is one region with no hierarchy, so a commodity
      # balanced at a coarser `@geoframe` would be refused outright ("no
      # geoscale with coarser levels"). Drop the declaration, as `@emis` is
      # dropped: what is screened here is the technology, per region.
      if (isS4(cm_obj) && .hasSlot(cm_obj, "geoframe"))
        cm_obj@geoframe <- character(0)
      commodity_objects[[cm]] <- cm_obj
    } else {
      unit_val <- ""
      for (t in object) {
        in_row  <- t@input [t@input$comm  == cm, , drop = FALSE]
        out_row <- t@output[t@output$comm == cm, , drop = FALSE]
        if (nrow(in_row)  > 0 && "unit" %in% names(in_row)  && !is.na(in_row$unit[1])  && nzchar(in_row$unit[1]))  unit_val <- in_row$unit[1]
        if (nrow(out_row) > 0 && "unit" %in% names(out_row) && !is.na(out_row$unit[1]) && nzchar(out_row$unit[1])) unit_val <- out_row$unit[1]
      }
      commodity_objects[[cm]] <- newCommodity(name = cm, timeframe = "ANNUAL",
                                              unit = unit_val)
      if (verbose) message("Created commodity '", cm, "'.")
    }
  }

  # ── 8. Build supply objects for external inputs ───────────────────────────
  supply_objects <- list()
  for (cm in external_inps) {
    if (!is.null(repo_supplies[[cm]])) {
      sup <- repo_supplies[[cm]]
      if (isS4(sup)) {
        if (.hasSlot(sup, "region") && length(sup@region) > 0) sup@region <- region
        if (.hasSlot(sup, "supply") && nrow(sup@supply) > 0 &&
            "region" %in% names(sup@supply))
          sup@supply$region <- region
      }
      supply_objects[[cm]] <- sup
    } else {
      fc_val <- .fuel_cost_or(fuel_costs, cm)
      supply_objects[[cm]] <- newSupply(
        name         = paste0("SUP_", cm),
        commodity    = cm,
        region       = region,
        supply = data.frame(region = region, year = as.integer(base_year),
                                  cost = fc_val, stringsAsFactors = FALSE)
      )
      if (verbose) message("Created supply for '", cm, "' (cost = ", fc_val, ").")
    }
  }

  # ── 9. Build demands / sinks for terminal outputs ─────────────────────────
  # norm_comm → unit demand (normaliser); other terminal outputs → zero-cost supply sink
  demand_objects <- list()
  for (cm in terminal_outs) {
    if (cm == norm_comm) {
      out_unit <- ""
      for (t in object) {
        row <- t@output[t@output$comm == cm, , drop = FALSE]
        if (nrow(row) > 0 && "unit" %in% names(row) && !is.na(row$unit[1]) && nzchar(row$unit[1]))
          out_unit <- row$unit[1]
      }
      demand_objects[[cm]] <- newDemand(
        name      = paste0("DEM_", cm),
        commodity = cm,
        unit      = out_unit,
        region    = region,
        demand       = data.frame(region = region, year = as.integer(base_year),
                               demand = 1, stringsAsFactors = FALSE)
      )
      if (verbose) message("Created unit demand for '", cm, "'.")
    } else {
      # by-product: zero-cost supply sink keeps model feasible
      supply_objects[[cm]] <- newSupply(
        name         = paste0("SUP_", cm),
        commodity    = cm,
        region       = region,
        supply = data.frame(region = region, year = as.integer(base_year),
                                  cost = 0, stringsAsFactors = FALSE)
      )
      if (verbose) message("Created supply sink for by-product '", cm, "'.")
    }
  }

  # ── 10. Strip capacity constraints ────────────────────────────────────────
  cap_cols <- c("stock", "cap.lo", "cap.up", "cap.fx",
                "ncap.lo", "ncap.up", "ncap.fx", "ret.lo", "ret.up", "ret.fx")
  object <- lapply(object, function(t) {
    if (nrow(t@capacity) > 0)
      for (col in intersect(cap_cols, names(t@capacity)))
        t@capacity[[col]] <- NA_real_
    t
  })

  # ── 11. Build and solve model ─────────────────────────────────────────────
  chain_id <- paste(tech_names, collapse = "_")
  sn  <- paste0(".lc_chain_", chain_id)
  mdl <- newModel(
    name     = paste0("levcost_chain_", chain_id),
    desc     = paste0("Chain LCOE model: ", chain_name),
    data     = newRepository("repo_lc_chain",
                 c(unname(commodity_objects), unname(object),
                   unname(supply_objects), unname(demand_objects))),
    region   = region,
    discount = discount,
    calendar = calendar,
    horizon  = hor
  )
  # New mapping pipeline: interpolate in memory (unfolded, so the writers see
  # explicit rows) then solve. `solve_scenario()` writes, runs and reads the solution
  # in one call (replacing the legacy write_sc / solve_scenario / read_solution).
  # Scratch-anchored + transient: nothing lands in the project's scenarios store.
  iarg <- list(...)
  if (is.null(iarg[["path"]])) iarg$path <- .levcost_scratch_path(sn)
  scen <- do.call(interpolate_model,
                  c(list(mdl, name = sn, ondisk = FALSE, fold = FALSE), iarg))
  scen <- solve_scenario(scen, solver = solver, transient = TRUE)

  # ── 12. Extract results ───────────────────────────────────────────────────
  sfget <- function(v) tryCatch({
    d <- getData(scen, name = v, merge = TRUE, drop.zeros = FALSE,
                 timeframe = "lowest")   # annual totals; see .levcost_scenario_fuel
    if (is.null(d) || nrow(d) == 0) return(NULL)
    as.data.frame(d)
  }, error = function(e) NULL)

  agg_yr <- function(df, filter_tech = NULL) {
    if (is.null(df) || nrow(df) == 0 || !"year" %in% names(df)) return(NULL)
    df$year <- as.integer(df$year)
    if (!is.null(filter_tech) && "tech" %in% names(df))
      df <- df[df$tech == filter_tech, , drop = FALSE]
    if (nrow(df) == 0) return(NULL)
    out <- aggregate(df[["value"]], by = list(year = df$year), FUN = sum, na.rm = TRUE)
    names(out)[2] <- "value"
    out
  }

  tc <- sfget("vTotalCost")
  if (is.null(tc) || nrow(tc) == 0) {
    warning("Chain LCOE solve returned no cost data.")
    return(NULL)
  }
  tc$year <- as.integer(tc$year)
  tc_agg  <- aggregate(value ~ year, data.frame(year = tc$year, value = tc$value),
                       sum, na.rm = TRUE)

  # LCOE table (cost per unit terminal output, which is 1 per year)
  lc_tbl <- data.frame(tech = chain_name, comm = norm_comm, region = region,
                        year = tc_agg$year, levcost = tc_agg$value,
                        stringsAsFactors = FALSE)
  rownames(lc_tbl) <- NULL

  # NPV LCOE
  te_npv  <- tc_agg$year - as.integer(base_year)
  dsc_tc  <- (1 + discount)^te_npv
  npv_num <- sum(ifelse(is.finite(dsc_tc) & dsc_tc > 0, tc_agg$value / dsc_tc, 0))
  npv_den <- sum(ifelse(is.finite(dsc_tc) & dsc_tc > 0, 1 / dsc_tc, 0))
  levcost_npv <- if (is.finite(npv_den) && npv_den > 0) npv_num / npv_den else NA_real_

  # Per-tech cost breakdown
  cost_breakdown <- do.call(rbind, c(
    lapply(tech_names, function(tn) {
      cmp <- list(eac   = agg_yr(sfget("vTechEac"),   tn),
                  fixom = agg_yr(sfget("vTechFixom"), tn),
                  varom = agg_yr(sfget("vTechVarom"), tn))
      do.call(rbind, Filter(Negate(is.null), lapply(names(cmp), function(nm) {
        d <- cmp[[nm]]
        if (is.null(d) || nrow(d) == 0) return(NULL)
        data.frame(tech = tn, chain = chain_name, comm = norm_comm, region = region,
                   year = as.integer(d$year), component = nm, value = d$value,
                   stringsAsFactors = FALSE)
      })))
    }),
    list(local({
      sup <- agg_yr(sfget("vSupCost"))
      if (is.null(sup)) return(NULL)
      data.frame(tech = "supply", chain = chain_name, comm = norm_comm, region = region,
                 year = as.integer(sup$year), component = "supply", value = sup$value,
                 stringsAsFactors = FALSE)
    }))
  ))
  if (!is.null(cost_breakdown)) rownames(cost_breakdown) <- NULL

  # Per-tech NPV share
  chain_breakdown <- do.call(rbind, c(
    lapply(tech_names, function(tn) {
      npv_t <- 0
      for (pn in c("vTechEac", "vTechFixom", "vTechVarom")) {
        d <- agg_yr(sfget(pn), tn)
        if (!is.null(d) && nrow(d) > 0) {
          dsc_d <- (1 + discount)^(as.integer(d$year) - as.integer(base_year))
          npv_t <- npv_t + sum(ifelse(is.finite(dsc_d) & dsc_d > 0, d$value / dsc_d, 0))
        }
      }
      data.frame(tech = tn, npv_cost = npv_t, share = NA_real_, stringsAsFactors = FALSE)
    }),
    list(local({
      sup <- agg_yr(sfget("vSupCost"))
      if (is.null(sup)) return(NULL)
      dsc_s <- (1 + discount)^(as.integer(sup$year) - as.integer(base_year))
      npv_s <- sum(ifelse(is.finite(dsc_s) & dsc_s > 0, sup$value / dsc_s, 0))
      data.frame(tech = "supply", npv_cost = npv_s, share = NA_real_, stringsAsFactors = FALSE)
    }))
  ))
  if (!is.null(chain_breakdown)) {
    rownames(chain_breakdown) <- NULL
    tot <- sum(chain_breakdown$npv_cost, na.rm = TRUE)
    if (is.finite(tot) && tot > 0)
      chain_breakdown$share <- chain_breakdown$npv_cost / tot
  }

  # ── 13. Return ────────────────────────────────────────────────────────────
  result <- list(
    levcost         = lc_tbl,
    levcost_npv     = setNames(levcost_npv, chain_name),
    cost_breakdown  = cost_breakdown,
    chain_breakdown = chain_breakdown,
    discount        = discount,
    base_year       = as.integer(base_year),
    tech_names      = tech_names,
    norm_comm       = norm_comm,
    scenario        = scen
  )
  class(result) <- c("levcost_chain", "levcost", "list")
  result
}

# ── Variant (vintage / cluster) support ────────────────────────────────────────
# A technology declaring vintages or clusters expands at interpolation time into
# one process per cell. The LCOE mini-model prices ONE process against a unit
# demand, so left alone the variants all compete for that single unit and the
# extraction sums across them -- a plausible-looking number that is simply wrong.
#
# Isolation is by REGION: each cell gets its own artificial region (`IND_VIN2030`)
# holding its own copy of the technology and its own unit of demand. Regions do
# not exchange commodities without an explicit trade object, so the cells cannot
# cross inside one solve. Region is also the only usable axis: `vTotalCost` has no
# `tech` dimension but is on a region x year grid (see `map_mvTotalCost()`), so a
# per-cell system cost can only be attributed regionally.

# Collapse one expanded cell to a genuinely un-vintaged process.
#
# `.tech_variants()` returns per-cell objects that still carry a one-row
# `@vintage`; left as-is `expand_variants()` inside `interpolate_model()` would
# expand them a second time and suffix the names twice.
#' @noRd
.levcost_devintage <- function(obj, region, real_region = NULL) {
  # Collapse the cell's rows to ONE region-blanked row, column by column:
  # a broadcast olife row and a window row legitimately coexist after
  # expansion, and the old `vt[1, ]` lost whichever was not first. Each
  # column is resolved independently (`.lifespan_resolve()` errors on
  # conflicting keys), preferring the broadcast (region-NA) value -- the
  # mini-model pins an artificial region, so region-specific labels
  # cannot survive here anyway.
  nv <- data.frame(vintage = NA_character_, region = NA_character_,
                   cluster = NA_character_, start = NA_integer_,
                   end = NA_integer_, olife = NA_integer_,
                   stringsAsFactors = FALSE)
  for (cc in .vintage_val_cols) {
    d <- .lifespan_resolve(obj, cc)
    if (nrow(d) == 0L) next
    v <- if (any(is.na(d$region))) {
      d[[cc]][is.na(d$region)][1]
    } else {
      d[[cc]][1]
    }
    nv[[cc]] <- if (is.na(v) || !is.finite(v)) v else as.integer(v)
  }
  obj@vintage <- nv
  if (methods::.hasSlot(obj, "cluster"))
    obj@cluster <- obj@cluster[0, , drop = FALSE]

  # Rows are already timesliced to this cell, so the selectors carry no information;
  # blanking them is what stops a second expansion.
  #
  # The `region` COLUMN moves with the pin below. The technology path gives each
  # cell its own artificial region, so a cost row left keyed to the REAL region
  # matches nothing downstream: `.la_series()` drops it for a default of 0, the
  # mini-model's parameter lookup does the same, and the cell then prices at zero
  # and reports NA. Storage and trade pin the real region, so there it is a no-op.
  #
  # `real_region` says which region the rows currently speak for. `@region` is
  # often empty (a technology with no declared region exists everywhere), so the
  # caller passes the region levcost resolved; with neither, nothing is
  # relabelled rather than guess and collide two regions' rows onto one key.
  has_reg <- methods::.hasSlot(obj, "region")
  old_reg <- if (!is.null(real_region)) as.character(real_region)
             else if (has_reg) as.character(obj@region) else character()
  old_reg <- old_reg[!is.na(old_reg) & nzchar(old_reg)]
  for (sl in methods::slotNames(obj)) {
    if (sl %in% c("vintage", "cluster")) next
    d <- methods::slot(obj, sl)
    if (!is.data.frame(d) || nrow(d) == 0) next
    touched <- FALSE
    hit <- intersect(.variant_dims, names(d))
    if (length(hit) > 0) {
      for (cc in hit) d[[cc]] <- NA_character_
      touched <- TRUE
    }
    if (has_reg && length(region) > 0 && length(old_reg) > 0 &&
        "region" %in% names(d)) {
      # Only the cell's own region is relabelled: overwriting every row would
      # promote a foreign region's row into the cell and duplicate the key.
      # An NA row is a broadcast and already applies, so it is left alone.
      rr <- as.character(d$region)
      pin <- !is.na(rr) & rr %in% old_reg
      if (any(pin)) {
        rr[pin] <- region[1]
        d$region <- rr
        touched <- TRUE
      }
    }
    if (touched) methods::slot(obj, sl) <- d
  }

  # A `trade` has no `region` slot at all -- its geography is `@routes` (src/dst)
  # and its capacity carries no region index -- so pinning one is both
  # impossible and meaningless. Technology and storage both have it.
  if (methods::.hasSlot(obj, "region")) obj@region <- region
  obj
}

#' Drop a devintaged cell's build window, keeping its lifetime
#'
#' `.levcost_devintage()` carries `start`/`end` through, and for a levelized
#' cost they are actively wrong: the question is what a unit of THIS vintage
#' costs, not whether it could have been built inside the priced horizon.
#' Left in, a vintage whose window falls outside the priced horizon cannot be
#' built at all: the mini-model goes infeasible, and the closed form prices it
#' to ZERO via the backstop -- which reads as a free technology. Both engines
#' read the window (`levcost_analytic.R` resolves it in `.la_eval()`), so
#' neither is safe without this. `olife` is untouched; it is what drives the
#' annuity.
#'
#' Shared by all three fan-out paths: technology, storage and trade.
#' @noRd
.levcost_unwindow <- function(obj) {
  v <- obj@vintage
  if (NROW(v) == 0) return(obj)
  for (cc in intersect(c("start", "end"), names(v))) v[[cc]] <- NA_integer_
  obj@vintage <- v
  obj
}

# One artificial region per cell, built with the same namer (and the same
# configurable `_VIN`/`_CL` prefixes) that names the processes themselves.
#' @noRd
.levcost_variant_regions <- function(region, prov,
                                     prefix = .variant_prefix_default()) {
  regs <- vapply(seq_len(nrow(prov)), function(i)
    .variant_name(region, prov$vintage[i], prov$cluster[i], prefix), character(1))

  bad <- regs[!vapply(regs, check_name, logical(1))]
  if (length(bad) > 0)
    stop("Cannot build a valid region name for variant(s): ",
         paste(unique(bad), collapse = ", "),
         ". Region names must match '^[[:alpha:]][[:alnum:]_]*$'.", call. = FALSE)
  if (anyDuplicated(regs) > 0)
    stop("Variant region names collide: ",
         paste(unique(regs[duplicated(regs)]), collapse = ", "), ".", call. = FALSE)
  if (region %in% regs)
    stop("Variant region name collides with the base region '", region, "'.",
         call. = FALSE)
  regs
}

# Replicate region-keyed rows across every region of the mini-model.
#
# The single-region path simply overwrote `region` with the one resolved value.
# With a region per variant the rows must exist in each, otherwise only the first
# cell sees the supply and the rest are unservable.
#' @noRd
# Re-point a parent model's availability table at the screening regions.
#
# Three cases, and only the first one is a plain spread:
#
#   * the table says nothing region-specific for this screening model (one row,
#     or rows keyed only by year / timeslice): give every region a copy;
#   * every screening region has its OWN row: keep them, so a region is priced
#     at its own price rather than at some average;
#   * the rows name regions this model does not have -- another region's price,
#     or a COARSER level such as a zone, since the screening model carries no
#     hierarchy: they cannot be told apart here, so screening takes the
#     cheapest. A levelized cost is an a-priori lower bound, and the
#     alternative (replicating every row into every region) wrote a repeated
#     (sup, comm, region, year, timeslice) key and interpolation stopped with
#     "multiplied a series".
#
# Rows that differ by year or timeslice are preserved in every case: the
# collapse happens WITHIN such a group, never across it.
#' @noRd
.levcost_spread_region <- function(df, regions) {
  if (is.null(df) || nrow(df) == 0 || length(regions) == 0) return(df)
  if (!"region" %in% names(df)) return(df)
  own <- df[!is.na(df$region) & df$region %in% regions, , drop = FALSE]
  if (nrow(own) > 0 && all(regions %in% own$region)) {
    rownames(own) <- NULL
    return(own)
  }
  price <- intersect(c("cost", "price"), names(df))
  # group on DIMENSIONS only: `ava.up` and friends are values, and treating one
  # as a key would keep the duplicate rows this function exists to collapse
  grp <- intersect(c("year", "timeslice", "vintage", "cluster", "comm",
                     "group"), names(df))
  cheapest <- function(d) {
    if (nrow(d) <= 1) return(d)
    if (length(price) > 0) d[which.min(d[[price[1]]]), , drop = FALSE]
    else d[1, , drop = FALSE]
  }
  base <- if (length(grp) > 0 && nrow(unique(df[grp])) > 1) {
    key <- do.call(paste, c(lapply(grp, function(g) as.character(df[[g]])),
                            list(sep = "")))
    do.call(rbind, lapply(split(df, key), cheapest))
  } else cheapest(df)
  out <- base[rep(seq_len(nrow(base)), times = length(regions)), , drop = FALSE]
  out$region <- rep(regions, each = nrow(base))
  rownames(out) <- NULL
  out
}

# Unit labels of a technology; shared by the plain and per-variant return paths.
#' @noRd
.levcost_tech_units <- function(object, out_comms) {
  pick <- function(col) {
    if (nrow(object@units) > 0 && col %in% names(object@units)) {
      v <- object@units[[col]][1]
      if (!is.na(v) && nzchar(v)) return(v)
    }
    ""
  }
  output_units <- setNames(
    vapply(out_comms, function(cm) {
      if (nrow(object@output) > 0 && "unit" %in% names(object@output)) {
        r <- object@output$unit[object@output$comm == cm]
        if (length(r) > 0 && !is.na(r[1]) && nzchar(r[1])) return(r[1])
      }
      ""
    }, character(1)), out_comms)
  list(costs = pick("costs"), activity = pick("activity"), output = output_units)
}

# One cell's extraction turned into an ordinary `levcost` object, so every
# existing accessor and plot works per variant unchanged. Frontier fields are
# NULL: the frontier corners are a per-commodity sweep, orthogonal to variants,
# and are not fanned out per cell.
#' @noRd
.levcost_variant_result <- function(res, name, object, out_comms, discount,
                                    base_year, scen) {
  result <- list(
    levcost            = res$levcost,
    levcost_npv        = setNames(res$levcost_npv, name),
    cost_breakdown     = res$cost_breakdown,
    cost_breakdown_npv = res$cost_breakdown_npv,
    levcost_per_act    = res$levcost_per_act,
    cost_yearly        = res$cost_yearly,
    frontier           = NULL,
    levcost_by_comm    = NULL,
    levcost_by_act     = NULL,
    levcost_by_act_cbd = NULL,
    input_frontier     = tech_share_frontier(object),
    discount           = discount,
    base_year          = as.integer(base_year),
    units              = .levcost_tech_units(object, out_comms),
    scenario           = scen
  )
  class(result) <- c("levcost", "list")
  result
}

# Bundle the per-variant results. Elements are variants ONLY -- the stacked
# tables ride as attributes, because `autoplot.levcost_list()` iterates
# `names(x)` and would otherwise treat a table as another variant.
#' @noRd
.levcost_variants_object <- function(per_variant, prov, base_tech) {
  nms <- names(per_variant)
  key <- data.frame(
    tech    = base_tech,
    variant = nms,
    vintage = prov$vintage[match(nms, prov$name)],
    cluster = prov$cluster[match(nms, prov$name)],
    stringsAsFactors = FALSE
  )

  stack <- function(field) {
    parts <- Filter(Negate(is.null), lapply(nms, function(nm) {
      d <- per_variant[[nm]][[field]]
      if (is.null(d) || nrow(d) == 0) return(NULL)
      k <- key[key$variant == nm, , drop = FALSE]
      # `tech` in the per-variant table is the variant name; the key supplies
      # both the base technology and the variant, so drop the duplicate.
      d <- d[, setdiff(names(d), "tech"), drop = FALSE]
      cbind(k[rep(1L, nrow(d)), , drop = FALSE], d, row.names = NULL)
    }))
    if (length(parts) == 0) return(NULL)
    out <- do.call(rbind, parts)
    rownames(out) <- NULL
    out
  }

  npv_tbl <- do.call(rbind, lapply(nms, function(nm) {
    k <- key[key$variant == nm, , drop = FALSE]
    k$levcost_npv <- unname(per_variant[[nm]]$levcost_npv)
    k
  }))
  rownames(npv_tbl) <- NULL

  structure(
    per_variant,
    base_tech             = base_tech,
    variants              = key,
    by_variant            = stack("levcost"),
    by_variant_npv        = npv_tbl,
    by_variant_components = stack("cost_breakdown"),
    class                 = c("levcost_variants", "levcost_list", "list")
  )
}

# Per-variant tables of a levcost result. Reached through
# `levcost(x, by_variant = )` -- both on a fresh computation and on an
# already-computed `levcost_variants` object (the method below), so the
# tables never require a re-solve.
#' @noRd
.levcost_by_variant <- function(x, what = c("levcost", "npv", "components")) {
  if (isTRUE(what)) what <- "levcost"
  what <- match.arg(as.character(what), c("levcost", "npv", "components"))
  if (!inherits(x, "levcost_variants")) {
    stop("`by_variant` needs a levcost() result for a technology declaring ",
         "vintages or clusters; this one has none.", call. = FALSE)
  }
  switch(what,
    levcost    = attr(x, "by_variant"),
    npv        = attr(x, "by_variant_npv"),
    components = attr(x, "by_variant_components"))
}

#' Per-variant levelized cost tables, from an existing result
#'
#' `levcost()` on a `levcost_variants` object stacks its per-variant tables
#' without re-solving: `levcost(lc, by_variant = "npv")`.
#'
#' @rdname levcost
#' @export
setMethod("levcost", "levcost_variants",
  function(object, comm, name, by_variant = TRUE, ...) {
    .levcost_by_variant(object, by_variant)
  })

# A result from a technology with no vintages/clusters: say so, rather than
# letting S4 dispatch fail with "unable to find an inherited method".
#' @rdname levcost
#' @export
setMethod("levcost", "levcost",
  function(object, comm, name, by_variant = FALSE, ...) {
    if (isFALSE(by_variant)) {
      stop("`object` is already a levcost() result. Pass `by_variant = ` to ",
           "stack its per-variant tables, or call levcost() on the process ",
           "object to price it again.", call. = FALSE)
    }
    .levcost_by_variant(object, by_variant)
  })

#' @method print levcost_variants
#' @export
print.levcost_variants <- function(x, ...) {
  npv <- attr(x, "by_variant_npv")
  cat("Levelized cost by variant\n")
  cat("Technology: ", attr(x, "base_tech") %||% "", "\n", sep = "")
  cat("Variants:   ", length(x), "\n", sep = "")
  if (!is.null(npv)) {
    show <- npv[, intersect(c("variant", "vintage", "cluster", "levcost_npv"),
                            names(npv)), drop = FALSE]
    print(show, row.names = FALSE)
  }
  cat("\nUse levcost(x, by_variant = ) for the stacked tables, ",
      "autoplot(x) to compare.\n", sep = "")
  invisible(x)
}

# ── levcost_technology_ ─────────────────────────────────────────────────────────
# Private implementation called by setMethod("levcost", "technology", ...).

levcost_technology_ <- function(
    object,
    comm           = NULL,
    group          = NULL,
    repo           = NULL,
    fuel_costs     = NULL,
    discount       = 0.05,
    base_year      = NULL,
    horizon        = NULL,
    calendar       = NULL,
    timeframe      = c("auto", "ANNUAL", "native"),
    region         = NULL,
    weather        = NULL,
    frontier       = TRUE,
    backstop       = TRUE,
    solver         = solver_options$glpk,
    method         = c("auto", "analytic", "solve"),
    run            = c("single", "sequential"),
    max_failures   = 10L,
    as_scenario    = FALSE,
    verbose        = TRUE,
    ...
) {
  run    <- match.arg(run)
  method <- match.arg(method)

  # ── 0. Handle list of technologies → chain LCOE ────────────────────────────
  if (is.list(object) && !inherits(object, "technology")) {
    if (length(object) == 0) stop("`object` is an empty list.")
    if (!all(sapply(object, inherits, "technology")))
      stop("All elements of `object` must be energyRt 'technology' objects.")
    if (method == "analytic")
      stop("levcost(method = \"analytic\") does not support a technology ",
           "chain; the intermediate flows need the solver.", call. = FALSE)
    if (method == "auto" && verbose)
      message("levcost(): a technology chain is priced with the solver.")

    return(levcost_chain_(
      object,
      comm       = comm,
      repo       = repo,
      fuel_costs = fuel_costs,
      discount   = discount,
      base_year  = base_year,
      horizon    = horizon,
      calendar   = calendar,
      region     = region,
      solver     = solver,
      verbose    = verbose,
      ...
    ))
  }

  # ── 1. Validate input ───────────────────────────────────────────────────────
  if (!inherits(object, "technology"))
    stop("`object` must be an energyRt 'technology' object or a list thereof.")
  tech_name <- if (nzchar(object@name)) object@name else "TECH"
  timeframe  <- match.arg(timeframe)
  # native timeslice shares of the supplied calendar, used to weight weather into an
  # annual capacity factor when `timeframe = "ANNUAL"` (captured before the
  # calendar is overridden to annual below).
  native_timeslice_share <- if (!is.null(calendar) && .hasSlot(calendar, "timeslice_share"))
    calendar@timeslice_share else NULL

  # ── 1b. Strip capacity constraints (distort unit-demand mini-model) ─────────
  if (nrow(object@capacity) > 0) {
    object <- .levcost_strip_capacity(object, verbose = verbose,
                                      what = "LCOE mini-model")
  }

  # ── 2. Resolve region ───────────────────────────────────────────────────────
  if (is.null(region)) {
    reg_candidates <- unique(na.omit(object@region))
    if (length(reg_candidates) == 0 && nrow(object@capacity) > 0 &&
        "region" %in% names(object@capacity))
      reg_candidates <- unique(na.omit(object@capacity$region))
    reg_candidates <- reg_candidates[nzchar(as.character(reg_candidates)) &
                                       !is.na(reg_candidates)]
    if (length(reg_candidates) == 0) {
      region <- "REGION"
      if (verbose) message("No region found in technology; using 'REGION'.")
    } else {
      region <- reg_candidates[1]
      if (length(reg_candidates) > 1 && verbose)
        message("Multiple regions in technology; using first: '", region, "'.")
    }
  } else {
    region <- region[1]
  }
  # The mini-model is single-region; subset a multi-region technology's data to
  # the resolved region so it does not reference undeclared regions.
  if (length(.levcost_tech_regions(object)) > 1)
    object <- .levcost_subset_tech_region(object, region)

  # ── 2b. Expand vintage / cluster variants ──────────────────────────────────
  # `.tech_variants()` is NULL for a plain technology, in which case everything
  # below is exactly the historical single-process path.
  vinfo <- .tech_variants(object)
  has_variants <- !is.null(vinfo)

  if (has_variants) {
    vprov  <- vinfo$prov
    reg_v  <- .levcost_variant_regions(region, vprov, .variant_prefix_default())
    # One devintaged copy per cell, each pinned to its own artificial region.
    # `.levcost_unwindow()` as on the storage and trade paths: the build window
    # is not part of what a unit of this vintage costs, and a window outside the
    # priced horizon otherwise prices the cell to zero.
    tech_objects <- Map(function(o, r)
                          .levcost_unwindow(.levcost_devintage(o, r,
                                                               real_region = region)),
                        vinfo$objects, reg_v)
    names(tech_objects) <- vapply(tech_objects, function(o) o@name, character(1))
    # Structural attributes (@input/@output/@aux/@units) are variant-invariant,
    # but @ceff is not: derive shares, commodities and units from the FIRST cell
    # so a per-vintage efficiency does not double-count rows below.
    object_struct <- tech_objects[[1]]
    reg_all <- reg_v
    if (verbose)
      message("Technology '", tech_name, "' has ", length(tech_objects),
              " variants; pricing each in its own region (",
              paste(utils::head(reg_v, 3), collapse = ", "),
              if (length(reg_v) > 3) ", …" else "", ").")
  } else {
    vprov         <- NULL
    reg_v         <- region
    tech_objects  <- list(object)
    object_struct <- object
    reg_all       <- region
  }
  # Everything downstream derives structure from `object`; for a vintaged
  # technology that is the first cell (see above). The full set of processes
  # goes into the model via `tech_objects`.
  object <- object_struct

  # ── 3. Resolve output group / commodities ───────────────────────────────────
  out_df       <- object@output
  if (nrow(out_df) == 0) stop("Technology '", tech_name, "' has no output commodities.")
  avail_groups <- unique(out_df$group)
  avail_groups <- avail_groups[!is.na(avail_groups) & nzchar(as.character(avail_groups))]

  if (!is.null(group)) {
    if (!(group %in% avail_groups))
      stop("Output group '", group, "' not found in technology '", tech_name, "'.\n",
           "Available groups: ", paste(avail_groups, collapse = ", "))
    out_df_grp <- out_df[out_df$group == group, , drop = FALSE]
  } else if (length(avail_groups) > 1) {
    stop("Technology '", tech_name, "' has multiple output groups: ",
         paste(avail_groups, collapse = ", "),
         ".\nSpecify one via the `group = ` parameter.")
  } else if (length(avail_groups) == 1) {
    group      <- avail_groups
    out_df_grp <- out_df[!is.na(out_df$group) & out_df$group == avail_groups, , drop = FALSE]
    if (nrow(out_df_grp) == 0) out_df_grp <- out_df
  } else {
    out_df_grp <- out_df
  }

  if (!is.null(comm)) {
    miss_comm <- setdiff(comm, out_df_grp$comm)
    if (length(miss_comm) > 0)
      stop("Commodity/ies not found in resolved output: ", paste(miss_comm, collapse = ", "),
           ".\nAvailable: ", paste(out_df_grp$comm, collapse = ", "))
    out_comms <- comm
  } else {
    out_comms <- out_df_grp$comm
  }
  all_out_comms      <- out_df_grp$comm
  has_grouped_output <- !is.null(group)

  # ── 3.5. Extract output share constraints ───────────────────────────────────
  share_up <- setNames(rep(NA_real_, length(out_comms)), out_comms)
  share_lo <- setNames(rep(0,        length(out_comms)), out_comms)
  if (has_grouped_output && nrow(object@ceff) > 0) {
    ceff_out <- object@ceff[object@ceff$comm %in% out_comms, , drop = FALSE]
    for (slot_name in c("grp.share.up", "grp.share.lo", "grp.share.fx")) {
      if (!slot_name %in% names(ceff_out)) next
      for (cm in out_comms) {
        rows <- ceff_out[ceff_out$comm == cm & !is.na(ceff_out[[slot_name]]), , drop = FALSE]
        if (nrow(rows) == 0) next
        if (slot_name == "grp.share.up") share_up[[cm]] <- rows[[slot_name]][1]
        if (slot_name == "grp.share.lo") share_lo[[cm]] <- rows[[slot_name]][1]
        if (slot_name == "grp.share.fx") { share_up[[cm]] <- rows[[slot_name]][1]
                                       share_lo[[cm]] <- rows[[slot_name]][1] }
      }
    }
  }
  do_frontier <- frontier &&
    has_grouped_output &&
    length(out_comms) >= 2 &&
    any(is.finite(share_up))

  # ── 4. Collect input commodities + input group share constraints ─────────────
  in_comms <- unique(object@input$comm)
  in_df    <- object@input
  in_groups <- if ("group" %in% names(in_df))
    unique(in_df$group[!is.na(in_df$group) & nzchar(as.character(in_df$group))])
  else character(0)

  in_group_comms <- list()
  in_share_up    <- list()
  in_share_lo    <- list()
  for (.grp in in_groups) {
    .gc <- in_df$comm[!is.na(in_df$group) & as.character(in_df$group) == .grp]
    in_group_comms[[.grp]] <- .gc
    .su <- setNames(rep(NA_real_, length(.gc)), .gc)
    .sl <- setNames(rep(0,        length(.gc)), .gc)
    if (nrow(object@ceff) > 0) {
      .ci <- object@ceff[object@ceff$comm %in% .gc, , drop = FALSE]
      for (.sn in c("grp.share.up", "grp.share.lo", "grp.share.fx")) {
        if (!.sn %in% names(.ci)) next
        for (.cm in .gc) {
          .r <- .ci[.ci$comm == .cm & !is.na(.ci[[.sn]]), , drop = FALSE]
          if (nrow(.r) == 0) next
          if (.sn == "grp.share.up") .su[[.cm]] <- .r[[.sn]][1]
          if (.sn == "grp.share.lo") .sl[[.cm]] <- .r[[.sn]][1]
          if (.sn == "grp.share.fx") { .su[[.cm]] <- .r[[.sn]][1]; .sl[[.cm]] <- .r[[.sn]][1] }
        }
      }
    }
    in_share_up[[.grp]] <- .su
    in_share_lo[[.grp]] <- .sl
  }
  # these loop temporaries only exist when `in_groups` is non-empty; remove only
  # the ones actually created so a group-free tech doesn't warn (see #levcost).
  rm(list = intersect(c(".grp", ".gc", ".su", ".sl", ".sn", ".cm", ".r"), ls()))

  # ── 4.5. Auxiliary commodities (from @aux / @aeff) ───────────────────────────
  # Collect all auxiliary commodity names declared in @aux$acomm so that they
  # can be registered as commodity objects and — when consumed as inputs — also
  # get zero-cost supply objects in the mini-model.
  aux_comms <- character(0)
  if (.hasSlot(object, "aux") && nrow(object@aux) > 0 &&
      "acomm" %in% names(object@aux))
    aux_comms <- unique(na.omit(as.character(object@aux$acomm)))

  # Which aux commodities are consumed as inputs?  Look for non-NA values in
  # any of the input-type @aeff columns (cinp2ainp, act2ainp, cap2ainp, etc.).
  inp_aux_cols  <- c("cinp2ainp", "cout2ainp", "act2ainp", "cap2ainp", "ncap2ainp",
                     "sinp2ainp", "sout2ainp", "stg2ainp",
                     # storage per-part capacity couplings
                     "inp.cap2ainp", "inp.ncap2ainp",
                     "stg.cap2ainp", "stg.ncap2ainp",
                     "out.cap2ainp", "out.ncap2ainp")
  aux_inp_comms <- character(0)
  if (.hasSlot(object, "aeff") && nrow(object@aeff) > 0 && length(aux_comms) > 0) {
    aeff_inp_cols <- intersect(inp_aux_cols, names(object@aeff))
    if (length(aeff_inp_cols) > 0) {
      for (.ac in aux_comms) {
        .rows <- object@aeff[!is.na(object@aeff$acomm) & object@aeff$acomm == .ac,
                              aeff_inp_cols, drop = FALSE]
        if (any(!is.na(.rows))) aux_inp_comms <- c(aux_inp_comms, .ac)
      }
    }
  }

  # ── 5. Resolve horizon ──────────────────────────────────────────────────────
  if (inherits(horizon, "horizon")) {
    hor       <- horizon
    hor_years <- sort(hor@period)
  } else if (is.numeric(horizon) || is.integer(horizon)) {
    hor_years <- sort(as.integer(horizon))
    hor       <- newHorizon(period = hor_years)
  } else {
    # ALL cells, not `object`: for a vintaged technology `object` is the
    # first cell by now, and a horizon sized to it alone ends before the
    # later vintages' windows -- which priced them to zero via the backstop
    hor       <- .levcost_auto_horizon(tech_objects, base_year, verbose)
    hor_years <- sort(hor@period)
  }
  if (is.null(base_year)) base_year <- min(hor_years)

  # ── 6. Calendar ─────────────────────────────────────────────────────────────
  # Tracked because the ANNUAL path legitimately defaults to a single-slice
  # calendar, while the native path must not: see the timeframe resolution below.
  calendar_supplied <- !is.null(calendar)
  if (is.null(calendar)) calendar <- newCalendar()

  # ── 7. Pull supplies / commodities from repo ─────────────────────────────────
  repo_supplies <- list()
  repo_comms    <- list()
  if (!is.null(repo)) {
    objs <- if (inherits(repo, "repository")) repo@data else
      if (is.list(repo)) repo else
        stop("`repo` must be a 'repository' object or a named list.")
    for (obj in objs) {
      if (inherits(obj, "supply")) {
        key <- if (nzchar(obj@commodity)) obj@commodity else obj@name
        repo_supplies[[key]] <- obj
      }
      if (inherits(obj, "commodity")) repo_comms[[obj@name]] <- obj
    }
  }

  # ── 7b. Weather validation ───────────────────────────────────────────────────
  tech_has_weather <- nrow(object@weather) > 0 &&
    any(sapply(object@weather, function(col) any(nzchar(as.character(col)))))
  supply_has_weather <- any(sapply(repo_supplies, function(s) {
    nrow(s@weather) > 0 &&
      any(sapply(s@weather, function(col) any(nzchar(as.character(col)))))
  }))
  if ((tech_has_weather || supply_has_weather) && is.null(weather)) {
    who <- character(0)
    if (tech_has_weather) who <- c(who, paste0("technology '", tech_name, "'"))
    if (supply_has_weather) {
      wnames <- names(Filter(function(s) {
        nrow(s@weather) > 0 &&
          any(sapply(s@weather, function(col) any(nzchar(as.character(col)))))
      }, repo_supplies))
      who <- c(who, paste0("supply '", wnames, "'"))
    }
    stop("The following objects have a non-empty @weather slot and require a ",
         "weather object:\n  ", paste(who, collapse = "\n  "),
         "\nPlease supply one via `weather = `.")
  }
  weather_objects <- list()
  if (!is.null(weather)) {
    if (inherits(weather, "weather"))           weather_objects <- list(weather)
    else if (is.list(weather))                  weather_objects <- weather
    else stop("`weather` must be a 'weather' object or a list of 'weather' objects.")
  }

  # ── 7b. Resolve the pricing timeframe ───────────────────────────────────────
  # `auto` annualizes when the collapse is sound and prices on the native
  # calendar when it is not; an explicit `"ANNUAL"` declines rather than price
  # something the collapse would misrepresent. The cells are scanned, not the
  # parent: a per-cluster weather row is one factor per cell, which is fine.
  annual_blockers <- .levcost_annual_blockers(tech_objects)
  if (identical(timeframe, "auto")) {
    timeframe <- if (length(annual_blockers) > 0) "native" else "ANNUAL"
    if (identical(timeframe, "native") && verbose)
      message("levcost(): pricing '", tech_name, "' on its native timeframe; it ",
              "cannot be annualized -- ",
              paste(annual_blockers, collapse = "; "), ".")
  } else if (identical(timeframe, "ANNUAL") && length(annual_blockers) > 0) {
    stop("levcost(timeframe = \"ANNUAL\") cannot price '", tech_name, "': ",
         paste(annual_blockers, collapse = "; "), ".",
         "
Price it with `timeframe = \"native\"` and a matching `calendar = `.",
         call. = FALSE)
  }

  # A native sub-annual process needs a calendar holding its timeslices, and
  # levcost() will not choose one: the choice changes both the problem size and
  # the numbers, so it belongs to the caller.
  if (identical(timeframe, "native") && !calendar_supplied) {
    tf_need <- unique(unlist(lapply(tech_objects, function(t)
      if (methods::.hasSlot(t, "timeframe")) as.character(t@timeframe)
      else character())))
    tf_need <- tf_need[!is.na(tf_need) & nzchar(tf_need) & tf_need != "ANNUAL"]
    if (length(tf_need) > 0 || length(weather_objects) > 0)
      stop("levcost(timeframe = \"native\") needs a `calendar = ` containing the ",
           "timeslices of '", tech_name, "'",
           if (length(tf_need) > 0)
             paste0(" (timeframe ", paste(tf_need, collapse = "/"), ")") else "",
           ". None was supplied, and levcost() does not pick one for you.",
           call. = FALSE)
  }

  # ── 7c. Annual timeframe collapse ───────────────────────────────────────────
  # `levcost` measures the cost of dispatchable generation, so by default it
  # prices the technology on an ANNUAL timeframe: any weather profile is
  # collapsed to an annual capacity factor (share-weighted mean, applied as the
  # technology's annual availability), the weather objects are dropped, and a
  # single-timeslice annual calendar is used. This sizes capacity to serve unit
  # annual demand at the technology's capacity factor (textbook LCOE) and avoids
  # the sub-annual must-run overbuild artefact. `timeframe = "native"` keeps the
  # supplied (sub-annual) calendar and normalises by total generation — useful
  # when the technology is studied together with storage or transmission.
  if (identical(timeframe, "ANNUAL")) {
    if (nrow(object@weather) > 0) {
      wobjs <- lapply(weather_objects, .levcost_subset_weather_region,
                      region = region)
      object <- .levcost_weatherize_annual(object, wobjs,
                                           native_timeslice_share, verbose = verbose)
      # The model is built from `tech_objects`, not `object` -- weatherize
      # each cell too, or the annual CF silently never reaches the solver
      # (capacity then sizes to af = 1). A variant cell is pinned to its
      # artificial region, so CF rows written for the real region are
      # relabelled to the cell's own.
      tech_objects <- lapply(tech_objects, function(t) {
        if (nrow(t@weather) == 0) return(t)
        t2 <- .levcost_weatherize_annual(t, wobjs, native_timeslice_share,
                                         verbose = FALSE)
        if (has_variants && nrow(t2@af) > 0 && "region" %in% names(t2@af)) {
          hit <- !is.na(t2@af$region) & t2@af$region == region
          t2@af$region[hit] <- t2@region[1]
        }
        t2
      })
    }
    weather_objects <- list()
    calendar <- newCalendar()          # annual, single ANNUAL timeslice
    # ... and the process's own timeframe. `get_process_timeframe()` reads
    # `@timeframe` to build the timeslice domain, so a process left declaring a
    # sub-annual timeframe is indexed at slices this calendar does not contain
    # (`pTechAfLo[...,HOUR] out of domain`). The commodity gets the same
    # treatment below; both halves are needed.
    if (methods::.hasSlot(object, "timeframe")) object@timeframe <- "ANNUAL"
    tech_objects <- lapply(tech_objects, function(t) {
      if (methods::.hasSlot(t, "timeframe")) t@timeframe <- "ANNUAL"
      t
    })
  }

  # ── 8. Auto-create commodity objects ─────────────────────────────────────────
  # Include aux_comms so auxiliary commodities referenced in @aeff are declared
  # in the mini-model commodity set even when not in @input / @output.
  all_comms_needed <- unique(c(in_comms, all_out_comms, aux_comms))
  commodity_objects <- list()
  for (cm in all_comms_needed) {
    if (!is.null(repo_comms[[cm]])) {
      cm_obj <- repo_comms[[cm]]
      if (isS4(cm_obj) && .hasSlot(cm_obj, "emis") && nrow(cm_obj@emis) > 0)
        cm_obj@emis <- cm_obj@emis[0L, , drop = FALSE]
      # On the annual timeframe every commodity must resolve to the single ANNUAL
      # timeslice; a repo commodity carrying a sub-annual timeframe would mismatch the
      # calendar (mCommTimeslice).
      if (identical(timeframe, "ANNUAL") && .hasSlot(cm_obj, "timeframe"))
        cm_obj@timeframe <- "ANNUAL"
      # A screening model is one region with no hierarchy, so a commodity
      # balanced at a coarser `@geoframe` would be refused outright ("no
      # geoscale with coarser levels"). Drop the declaration, as `@emis` is
      # dropped: what is screened here is the technology, per region.
      if (isS4(cm_obj) && .hasSlot(cm_obj, "geoframe"))
        cm_obj@geoframe <- character(0)
      commodity_objects[[cm]] <- cm_obj
    } else {
      unit_val <- ""
      in_row   <- object@input [object@input$comm  == cm, , drop = FALSE]
      out_row  <- object@output[object@output$comm == cm, , drop = FALSE]
      if (nrow(in_row)  > 0 && "unit" %in% names(in_row))  unit_val <- in_row$unit[1]
      if (nrow(out_row) > 0 && "unit" %in% names(out_row)) unit_val <- out_row$unit[1]
      commodity_objects[[cm]] <- newCommodity(
        name      = cm,
        timeframe = "ANNUAL",
        unit      = if (!is.na(unit_val)) unit_val else ""
      )
      if (verbose) message("Created commodity '", cm, "'.")
    }
  }

  # ── 9. Auto-create supply objects ────────────────────────────────────────────
  supply_objects <- list()
  for (cm in in_comms) {
    if (!is.null(repo_supplies[[cm]])) {
      sup <- repo_supplies[[cm]]
      if (isS4(sup)) {
        if (.hasSlot(sup, "region") && length(sup@region) > 0)
          sup@region <- reg_all
        if (.hasSlot(sup, "supply") &&
            nrow(sup@supply) > 0 &&
            "region" %in% names(sup@supply))
          sup@supply <- .levcost_spread_region(sup@supply, reg_all)
      }
      supply_objects[[cm]] <- sup
    } else {
      fc_val <- .fuel_cost_or(fuel_costs, cm)
      supply_objects[[cm]] <- newSupply(
        name         = paste0("SUP_", cm),
        commodity    = cm,
        region       = reg_all,
        supply = data.frame(
          region = reg_all, year = as.integer(base_year),
          cost   = fc_val, stringsAsFactors = FALSE
        )
      )
      if (verbose) message("Created supply for '", cm, "' (cost = ", fc_val, ").")
    }
  }

  # ── 9.5. Zero-cost supply for input-type auxiliary commodities ─────────────
  # Auxiliary commodities consumed as inputs (cinp2ainp, act2ainp, etc.) need a
  # supply object so the mini-model balances; reuse from repo when possible.
  for (.cm in aux_inp_comms) {
    if (!is.null(supply_objects[[.cm]])) next   # already handled in step 9
    if (!is.null(repo_supplies[[.cm]])) {
      sup <- repo_supplies[[.cm]]
      if (isS4(sup)) {
        if (.hasSlot(sup, "region") && length(sup@region) > 0)
          sup@region <- reg_all
        if (.hasSlot(sup, "supply") &&
            nrow(sup@supply) > 0 &&
            "region" %in% names(sup@supply))
          sup@supply <- .levcost_spread_region(sup@supply, reg_all)
      }
      supply_objects[[.cm]] <- sup
    } else {
      # priced like fuels when `fuel_costs` names the aux commodity
      # (e.g. a charging-infrastructure cost per GWh); zero otherwise
      fc_val <- .fuel_cost_or(fuel_costs, .cm)
      supply_objects[[.cm]] <- newSupply(
        name         = paste0("SUP_", .cm),
        commodity    = .cm,
        region       = reg_all,
        supply = data.frame(
          region = reg_all, year = as.integer(base_year),
          cost   = fc_val, stringsAsFactors = FALSE
        )
      )
      if (verbose) message("Created aux supply for '", .cm, "' (cost = ",
                           fc_val, ").")
    }
  }

  # ── 9.7. Analytic (no-solve) path ──────────────────────────────────────────
  # The mini-model built below is a unit-demand annual LP with a closed-form
  # optimum; R/levcost_analytic.R mirrors it equation by equation. Anything it
  # cannot represent is refused (never approximated): `method = "auto"` then
  # falls back to the solver, `method = "analytic"` errors.
  if (method != "solve") {
    to_named <- tech_objects
    if (is.null(names(to_named)))
      names(to_named) <- vapply(to_named, function(o) o@name, character(1))
    ctx <- list(
      tech_name = tech_name, object = object, tech_objects = to_named,
      has_variants = has_variants, vprov = vprov, region = region,
      out_comms = out_comms, all_out_comms = all_out_comms, group = group,
      has_grouped_output = has_grouped_output,
      share_up = share_up, share_lo = share_lo,
      in_comms = in_comms, in_groups = in_groups,
      in_group_comms = in_group_comms,
      in_share_up = in_share_up, in_share_lo = in_share_lo,
      aux_comms = aux_comms, aux_inp_comms = aux_inp_comms,
      hor_years = hor_years, base_year = base_year, discount = discount,
      timeframe = timeframe, as_scenario = as_scenario,
      do_frontier = do_frontier, frontier = frontier,
      supply_objects = supply_objects,
      comm_label = paste(out_comms, collapse = "+"),
      verbose = verbose, prices = NULL)
    blk <- character(0)
    res <- tryCatch({
      prices <- list()
      for (cm in names(supply_objects))
        prices[[cm]] <- .la_supply_price(supply_objects[[cm]], hor_years, cm)
      ctx$prices <- prices
      blk <- .levcost_analytic_blockers(ctx)
      if (length(blk) == 0) .levcost_analytic_run(ctx) else NULL
    }, levcost_analytic_unsupported = function(e) {
      blk <<- unique(c(blk, conditionMessage(e)))
      NULL
    })
    if (!is.null(res)) {
      if (verbose) message("Levelized cost computed analytically (no solver).")
      return(res)
    }
    if (method == "analytic")
      stop("levcost(method = \"analytic\") cannot price '", tech_name, "': ",
           paste(blk, collapse = "; "), call. = FALSE)
    if (verbose)
      message("levcost(): analytic path unavailable (",
              paste(blk, collapse = "; "), "); using the solver.")
  }

  # ── 9.9. Backstop slack (dummy import) ─────────────────────────────────────
  # A unit-demand mini-model can be infeasible when the technology cannot serve
  # every timeslice on its own (e.g. solar at night on a sub-annual calendar). Enable
  # the model's built-in dummy-import slack (via config `@debug`) at a very high
  # cost for each output commodity, so the balance always closes; the technology
  # is still dispatched to its physical limit (the slack is far dearer than any
  # real cost), and the slack's cost is excluded from the LCOE, which is
  # normalised by the technology's own output.
  BACKSTOP_PRICE  <- 1e6
  backstop_debug  <- NULL
  if (isTRUE(backstop) && length(all_out_comms) > 0) {
    backstop_debug <- data.frame(
      comm = all_out_comms, region = NA_character_, year = NA_integer_,
      timeslice = NA_character_, dummyImport = BACKSTOP_PRICE, dummyExport = Inf,
      stringsAsFactors = FALSE)
  }

  # ── 10. Inner helpers ────────────────────────────────────────────────────────
  make_demands_ <- function(dvals, regions = reg_all) {
    lapply(setNames(names(dvals), names(dvals)), function(cm) {
      dv       <- max(dvals[[cm]], 1e-9)
      unit_val <- ""
      out_row  <- object@output[object@output$comm == cm, , drop = FALSE]
      if (nrow(out_row) > 0 && "unit" %in% names(out_row)) unit_val <- out_row$unit[1]
      # One unit of demand PER REGION: with a variant per region, each cell then
      # faces its own unit and they cannot compete for a shared one.
      newDemand(
        name      = paste0("DEM_", cm),
        commodity = cm,
        unit      = if (!is.na(unit_val)) unit_val else "",
        region    = regions,
        demand       = data.frame(region = regions, year = as.integer(base_year),
                               demand = dv, stringsAsFactors = FALSE)
      )
    })
  }

  # `techs`/`regions` default to every variant (the combined run); the sequential
  # fallback passes one cell at a time. Supplies are re-regioned to match, or the
  # model would reference regions it does not declare.
  build_and_solve_ <- function(demand_objs, suffix = "", techs = tech_objects,
                               regions = reg_all, debug_df = backstop_debug) {
    sups <- supply_objects
    if (!identical(regions, reg_all))
      sups <- lapply(sups, function(s) {
        if (!isS4(s)) return(s)
        if (.hasSlot(s, "region") && length(s@region) > 0) s@region <- regions
        if (.hasSlot(s, "supply") && nrow(s@supply) > 0 &&
            "region" %in% names(s@supply))
          s@supply <- .levcost_spread_region(s@supply, regions)
        s
      })
    mdl <- newModel(
      name     = paste0("levcost_", tech_name, suffix),
      desc     = paste0("Mini model for levelized cost of '", tech_name, "'"),
      data     = newRepository("repo_lc",
                   c(unname(commodity_objects), unname(techs),
                     unname(sups), unname(demand_objs),
                     weather_objects)),
      region   = regions,
      discount = discount,
      calendar = calendar,
      horizon  = hor
    )
    if (!is.null(debug_df)) mdl@config@debug <- debug_df
    sn   <- paste0(".lc_", tech_name, suffix)
    # New mapping pipeline (see levcost_chain_): interpolate in memory, unfolded,
    # then write + run + read via solve_scenario() in one call. The scenario is
    # anchored in scratch (a caller-supplied `path` in `...` wins) and solved
    # transiently, so nothing lands in the project's scenarios store.
    iarg <- list(...)
    if (is.null(iarg[["path"]])) iarg$path <- .levcost_scratch_path(sn)
    scen <- do.call(interpolate_model,
                    c(list(mdl, name = sn, ondisk = FALSE, fold = FALSE), iarg))
    solve_scenario(scen, solver = solver, transient = TRUE)
  }

  # ── 11. Inner closure: extract LCOE from a solved scenario ──────────────────
  comm_label <- paste(out_comms, collapse = "+")
  group_val  <- if (!is.null(group)) group else NA_character_

  # `reg_filter` / `tech_label` restrict the extraction to ONE variant. Filtering
  # to a single region is what keeps every aggregation below a single-region
  # problem, so none of it needed to learn about vintages.
  levcost_extract_ <- function(sc, dem_vals, primary_comm = NULL,
                               reg_filter = NULL, tech_label = tech_name,
                               region_label = region) {
    sfget <- function(v) tryCatch({
      d <- getData(sc, name = v, merge = TRUE, drop.zeros = FALSE,
                   timeframe = "lowest")   # annual totals; see .levcost_scenario_fuel
      if (is.null(d) || nrow(d) == 0) return(NULL)
      d <- as.data.frame(d)
      if (!is.null(reg_filter) && "region" %in% names(d)) {
        d <- d[!is.na(d$region) & d$region %in% reg_filter, , drop = FALSE]
        if (nrow(d) == 0) return(NULL)
        # Report against the real region, never the artificial variant label.
        d$region <- region_label
      }
      d
    }, error = function(e) NULL)
    tech_name <- tech_label   # shadows the outer name in the tables built below

    agg_yr <- function(df) {
      if (is.null(df) || nrow(df) == 0 || !"year" %in% names(df)) return(NULL)
      df$year <- as.integer(df$year)
      out <- aggregate(df[["value"]], by = list(year = df$year), FUN = sum, na.rm = TRUE)
      names(out)[2] <- "value"; out
    }

    use_act_norm <- is.null(primary_comm) && has_grouped_output
    comm_lbl <- if (!is.null(primary_comm)) primary_comm else
                  if (use_act_norm) "activity" else comm_label

    tc <- sfget("vTotalCost")
    if (is.null(tc) || nrow(tc) == 0) {
      lc_tbl <- data.frame(tech = tech_name, group = group_val, comm = comm_lbl,
                            region = region, year = NA_integer_, levcost = NA_real_,
                            stringsAsFactors = FALSE)
      return(list(levcost = lc_tbl, levcost_npv = NA_real_,
                  cost_breakdown = NULL, cost_breakdown_npv = NULL,
                  cost_yearly = NULL, levcost_per_act = NULL, scen = sc))
    }

    # Own system cost = total minus the backstop dummy-import cost. The slack only
    # covers timeslices the technology physically cannot serve; its (deliberately
    # huge) cost is not the technology's and must not enter the LCOE.
    tc_df  <- agg_yr(as.data.frame(tc))            # year, value
    imp_yr <- agg_yr(sfget("vDummyImportCost"))
    if (!is.null(imp_yr) && nrow(imp_yr) > 0) {
      mm <- merge(tc_df, imp_yr, by = "year", all.x = TRUE, suffixes = c("", "_imp"))
      mm$value_imp[is.na(mm$value_imp)] <- 0
      tc_df <- data.frame(year = as.integer(mm$year),
                          value = mm$value - mm$value_imp, stringsAsFactors = FALSE)
    }
    tc_df$year <- as.integer(tc_df$year)

    # Resolve normaliser: the technology's OWN output, so the LCOE is cost per
    # unit the technology actually produces (not per unit of demand, part of
    # which the backstop may serve).
    norm_yr  <- NULL
    prim_dem <- 1
    if (use_act_norm) {
      act_ag <- agg_yr(sfget("vTechAct"))
      if (!is.null(act_ag) && nrow(act_ag) > 0)
        norm_yr <- setNames(act_ag$value, as.character(act_ag$year))
    } else if (!is.null(primary_comm)) {
      prim_dem <- max(dem_vals[[primary_comm]], 1e-9)
    } else {
      out_d <- sfget("vTechOut")
      if (!is.null(out_d) && "comm" %in% names(out_d))
        out_d <- out_d[out_d$comm %in% out_comms, , drop = FALSE]
      out_ag <- agg_yr(out_d)
      if (!is.null(out_ag) && nrow(out_ag) > 0 &&
          all(is.finite(out_ag$value)) && all(out_ag$value > 0))
        norm_yr <- setNames(out_ag$value, as.character(out_ag$year))
      else
        prim_dem <- max(sum(unlist(dem_vals)), 1e-9)
    }

    normalise_ <- function(yr_int, val) {
      if (!is.null(norm_yr)) {
        nrm <- norm_yr[as.character(yr_int)]
        ifelse(is.finite(nrm) & nrm > 0, val / nrm, NA_real_)
      } else {
        val / prim_dem
      }
    }

    lc_tbl <- tc_df
    names(lc_tbl)[names(lc_tbl) == "value"] <- "levcost"
    lc_tbl$levcost <- normalise_(lc_tbl$year, lc_tbl$levcost)
    lc_tbl$tech  <- tech_name; lc_tbl$group <- group_val; lc_tbl$comm <- comm_lbl
    lc_tbl$region <- region
    cf <- c("tech", "group", "comm", "region", "year", "levcost")
    lc_tbl <- lc_tbl[, c(cf, setdiff(names(lc_tbl), cf)), drop = FALSE]

    # NPV LCOE
    tc_agg  <- aggregate(value ~ year,
                         data.frame(year = as.integer(tc_df$year), value = tc_df$value),
                         sum, na.rm = TRUE)
    yr_int  <- tc_agg$year
    te_npv  <- yr_int - as.integer(base_year)
    dsc_tc  <- (1 + discount)^te_npv
    npv_num <- sum(ifelse(is.finite(dsc_tc) & dsc_tc > 0, tc_agg$value / dsc_tc, 0))

    npv_act_for_act <- NULL
    if (!is.null(norm_yr)) {
      qty_yr  <- norm_yr[as.character(yr_int)]
      npv_den <- sum(ifelse(is.finite(dsc_tc) & dsc_tc > 0 & is.finite(qty_yr),
                            qty_yr / dsc_tc, 0))
      npv_act_for_act <- npv_den
    } else if (!is.null(primary_comm)) {
      cact2cout_val <- NA_real_
      if (nrow(object@ceff) > 0 && "cact2cout" %in% names(object@ceff)) {
        r <- object@ceff$cact2cout[object@ceff$comm == primary_comm &
                                   !is.na(object@ceff$cact2cout)]
        if (length(r) > 0) cact2cout_val <- as.numeric(r[1])
      }
      act_fr <- agg_yr(sfget("vTechAct"))
      if (!is.null(act_fr) && nrow(act_fr) > 0 &&
          is.finite(cact2cout_val) && cact2cout_val > 0) {
        dsc_fr  <- (1 + discount)^(act_fr$year - as.integer(base_year))
        npv_act <- sum(ifelse(is.finite(dsc_fr) & dsc_fr > 0 & is.finite(act_fr$value),
                              act_fr$value / dsc_fr, 0))
        npv_den <- npv_act * cact2cout_val
        npv_act_for_act <- npv_act
      } else {
        npv_den <- prim_dem * sum(ifelse(is.finite(dsc_tc) & dsc_tc > 0, 1 / dsc_tc, 0))
      }
    } else {
      npv_den <- prim_dem * sum(ifelse(is.finite(dsc_tc) & dsc_tc > 0, 1 / dsc_tc, 0))
    }
    lc_npv <- if (is.finite(npv_den) && npv_den > 0) npv_num / npv_den else NA_real_

    # Cost components
    param_var_cost_ <- function(pname, vname) {
      p <- sfget(pname); v <- sfget(vname)
      if (is.null(p) || is.null(v) || nrow(p) == 0 || nrow(v) == 0) return(NULL)
      jc <- intersect(c("year", "region", "tech", "timeslice"), intersect(names(p), names(v)))
      m  <- merge(p[, c(jc, "value"), drop = FALSE],
                  v[, c(jc, "value"), drop = FALSE],
                  by = jc, suffixes = c("_p", "_v"))
      if (nrow(m) == 0) return(NULL)
      agg_yr(data.frame(year = m$year, value = m$value_p * m$value_v,
                        stringsAsFactors = FALSE))
    }

    fixom_val <- agg_yr(sfget("vTechFixom"))
    varom_val <- agg_yr(sfget("vTechVarom"))
    if (is.null(fixom_val)) fixom_val <- param_var_cost_("pTechFixom", "vTechCap")
    if (is.null(varom_val)) varom_val <- param_var_cost_("pTechVarom", "vTechAct")

    cmp_raw <- list(eac = agg_yr(sfget("vTechEac")),
                    fixom = fixom_val,
                    varom = varom_val,
                    supply = agg_yr(sfget("vSupCost")))
    # NB: vDummyImportCost is the backstop slack and is deliberately excluded — it
    # is not part of the technology's own levelized cost.
    ex <- sfget("vExportRowCost")
    if (!is.null(ex)) {
      ea <- agg_yr(ex)
      if (!is.null(ea)) { ea$value <- -ea$value; cmp_raw[["export"]] <- ea }
    }

    cbd <- do.call(rbind, Filter(Negate(is.null), lapply(names(cmp_raw), function(nm) {
      d <- cmp_raw[[nm]]; if (is.null(d)) return(NULL)
      data.frame(tech = tech_name, group = group_val, comm = comm_lbl,
                 region = region, year = as.integer(d$year),
                 component = nm, value = normalise_(as.integer(d$year), d$value),
                 stringsAsFactors = FALSE)
    })))
    if (!is.null(cbd)) rownames(cbd) <- NULL

    # Wide yearly table
    cost_yearly <- data.frame(tech = tech_name, group = group_val,
                              region = region, year = as.integer(tc_df$year),
                              total = tc_df$value, stringsAsFactors = FALSE)
    for (cnm in c("eac", "fixom", "varom", "supply", "import", "export")) {
      d <- cmp_raw[[cnm]]
      if (!is.null(d) && nrow(d) > 0) {
        dd <- data.frame(year = as.integer(d$year), v__ = d$value, stringsAsFactors = FALSE)
        names(dd)[2] <- cnm
        cost_yearly <- merge(cost_yearly, dd, by = "year", all.x = TRUE)
      }
    }
    act_raw <- agg_yr(sfget("vTechAct"))
    if (!is.null(act_raw) && nrow(act_raw) > 0) {
      cost_yearly <- merge(cost_yearly,
        data.frame(year = as.integer(act_raw$year), activity = act_raw$value,
                   stringsAsFactors = FALSE), by = "year", all.x = TRUE)
    }
    cap_raw <- agg_yr(sfget("vTechCap"))
    if (!is.null(cap_raw) && nrow(cap_raw) > 0) {
      cost_yearly <- merge(cost_yearly,
        data.frame(year = as.integer(cap_raw$year), capacity = cap_raw$value,
                   stringsAsFactors = FALSE), by = "year", all.x = TRUE)
    }
    out_raw <- sfget("vTechOut")
    if (!is.null(out_raw) && nrow(out_raw) > 0) {
      out_raw$year <- as.integer(out_raw$year)
      for (cm in unique(out_raw$comm)) {
        oa <- aggregate(value ~ year, out_raw[out_raw$comm == cm, ], sum, na.rm = TRUE)
        names(oa)[2] <- paste0("out_", cm)
        cost_yearly <- merge(cost_yearly, oa, by = "year", all.x = TRUE)
      }
    }
    inp_raw <- sfget("vTechInp")
    if (!is.null(inp_raw) && nrow(inp_raw) > 0) {
      inp_raw$year <- as.integer(inp_raw$year)
      for (cm in unique(inp_raw$comm)) {
        ia <- aggregate(value ~ year, inp_raw[inp_raw$comm == cm, ], sum, na.rm = TRUE)
        names(ia)[2] <- paste0("inp_", cm)
        cost_yearly <- merge(cost_yearly, ia, by = "year", all.x = TRUE)
      }
    }
    cy_front <- c("tech", "group", "region", "year")
    cost_yearly <- cost_yearly[, c(cy_front, setdiff(names(cost_yearly), cy_front)),
                               drop = FALSE]
    rownames(cost_yearly) <- NULL

    # NPV component breakdown
    cbd_npv <- NULL
    if (is.finite(lc_npv) && is.finite(npv_den) && npv_den > 0) {
      npv_parts <- Filter(Negate(is.null), lapply(names(cmp_raw), function(nm) {
        d <- cmp_raw[[nm]]; if (is.null(d) || nrow(d) == 0) return(NULL)
        d$te_c  <- as.integer(d$year) - as.integer(base_year)
        d$dsc_c <- (1 + discount)^d$te_c
        vld_c   <- is.finite(d$value) & is.finite(d$dsc_c) & d$dsc_c > 0
        pv      <- if (any(vld_c)) sum(d$value[vld_c] / d$dsc_c[vld_c]) else NA_real_
        data.frame(tech = tech_name, group = group_val, comm = comm_lbl,
                   component = nm, value = pv / npv_den, stringsAsFactors = FALSE)
      }))
      if (length(npv_parts) > 0) {
        cbd_npv <- do.call(rbind, npv_parts)
        rownames(cbd_npv) <- NULL
      }
    }

    # Per-activity NPV breakdown (for frontier scenarios)
    cbd_npv_per_act <- NULL
    if (!is.null(npv_act_for_act) && is.finite(npv_act_for_act) && npv_act_for_act > 0) {
      if (isTRUE(all.equal(npv_act_for_act, npv_den, tolerance = 1e-9))) {
        cbd_npv_per_act <- cbd_npv
      } else {
        pa_parts <- Filter(Negate(is.null), lapply(names(cmp_raw), function(nm) {
          d <- cmp_raw[[nm]]; if (is.null(d) || nrow(d) == 0) return(NULL)
          d$te_c  <- as.integer(d$year) - as.integer(base_year)
          d$dsc_c <- (1 + discount)^d$te_c
          vld_c   <- is.finite(d$value) & is.finite(d$dsc_c) & d$dsc_c > 0
          pv      <- if (any(vld_c)) sum(d$value[vld_c] / d$dsc_c[vld_c]) else NA_real_
          data.frame(tech = tech_name, group = group_val, comm = comm_lbl,
                     component = nm, value = pv / npv_act_for_act,
                     stringsAsFactors = FALSE)
        }))
        if (length(pa_parts) > 0) {
          cbd_npv_per_act <- do.call(rbind, pa_parts)
          rownames(cbd_npv_per_act) <- NULL
        }
      }
    }

    # Per-activity LCOE (grouped-output only)
    lc_act <- NULL
    if (has_grouped_output) {
      act_ag2 <- if (!is.null(norm_yr))
        data.frame(year = as.integer(names(norm_yr)), value = unname(norm_yr),
                   stringsAsFactors = FALSE)
      else agg_yr(sfget("vTechAct"))
      if (!is.null(act_ag2) && nrow(act_ag2) > 0) {
        mrg <- merge(tc_df[, c("year", "value"), drop = FALSE], act_ag2,
                     by = "year", suffixes = c("_cost", "_act"))
        mrg$lca <- ifelse(is.finite(mrg$value_act) & mrg$value_act != 0,
                          mrg$value_cost / mrg$value_act, NA_real_)
        lc_act <- data.frame(
          tech = tech_name, group = group_val, comm = comm_lbl, region = region,
          year = as.integer(mrg$year), activity = mrg$value_act,
          cost = mrg$value_cost, levcost_per_act = mrg$lca,
          stringsAsFactors = FALSE
        )
      }
    }

    list(levcost = lc_tbl, levcost_npv = lc_npv,
         cost_breakdown = cbd, cost_breakdown_npv = cbd_npv,
         cost_breakdown_npv_per_act = cbd_npv_per_act,
         cost_yearly = cost_yearly,
         levcost_per_act = lc_act, scen = sc)
  }

  # ── 12. Base solve ───────────────────────────────────────────────────────────
  # set_default_solver(solver)
  base_model_dvals <- setNames(rep(1, length(all_out_comms)), all_out_comms)
  base_lcoe_dvals  <- base_model_dvals[out_comms]
  demand_objects   <- make_demands_(base_model_dvals)
  if (verbose) for (cm in all_out_comms) message("Created unit demand for '", cm, "'.")

  # ── 12a. Per-variant path ──────────────────────────────────────────────────
  # All cells ride in ONE model (each in its own region), then each is extracted
  # by filtering to its region. `run = "sequential"` -- or a combined run that
  # will not solve -- falls back to one model per cell, so a single bad cell
  # cannot take the rest down.
  if (has_variants) {
    okay <- function(s) !is.null(s) && isTRUE(s@status$optimal)

    scen_all <- NULL
    if (run == "single") {
      scen_all <- tryCatch(build_and_solve_(demand_objects),
                           error = function(e) {
                             if (verbose) message("Combined run errored: ",
                                                  conditionMessage(e)); NULL })
      if (!okay(scen_all) && is.null(backstop_debug) && length(all_out_comms) > 0) {
        # Retry once with the dummy-import slack enabled, which is the usual cure
        # for a cell that cannot serve every timeslice on its own.
        if (verbose) message("Combined run did not solve; retrying with dummy import.")
        retry_debug <- data.frame(
          comm = all_out_comms, region = NA_character_, year = NA_integer_,
          timeslice = NA_character_, dummyImport = BACKSTOP_PRICE, dummyExport = Inf,
          stringsAsFactors = FALSE)
        scen_all <- tryCatch(
          build_and_solve_(demand_objects, suffix = "_bs", debug_df = retry_debug),
          error = function(e) NULL)
      }
    }

    var_scens <- NULL
    if (!okay(scen_all)) {
      if (run == "single" && verbose)
        message("Falling back to one model per variant.")
      var_scens <- vector("list", length(tech_objects))
      names(var_scens) <- names(tech_objects)
      consecutive <- 0L
      for (i in seq_along(tech_objects)) {
        if (consecutive >= max_failures) {
          warning("Stopped after ", max_failures, " consecutive failed variant ",
                  "solves; skipped: ",
                  paste(names(tech_objects)[i:length(tech_objects)], collapse = ", "),
                  call. = FALSE)
          break
        }
        s <- tryCatch(
          build_and_solve_(
            make_demands_(base_model_dvals, regions = reg_v[i]),
            suffix = paste0("_v", i),
            techs  = tech_objects[i], regions = reg_v[i]),
          error = function(e) NULL)
        if (okay(s)) { var_scens[[i]] <- s; consecutive <- 0L }
        else consecutive <- consecutive + 1L
      }
    }

    per_variant <- list()
    for (i in seq_along(tech_objects)) {
      sc_i <- if (!is.null(var_scens)) var_scens[[i]] else scen_all
      if (!okay(sc_i)) {
        warning("Variant '", names(tech_objects)[i], "' did not solve; omitted.",
                call. = FALSE)
        next
      }
      res_i <- levcost_extract_(sc_i, base_lcoe_dvals,
                                reg_filter   = reg_v[i],
                                tech_label   = names(tech_objects)[i],
                                region_label = region)
      per_variant[[names(tech_objects)[i]]] <- .levcost_variant_result(
        res_i, name = names(tech_objects)[i], object = tech_objects[[i]],
        out_comms = out_comms, discount = discount,
        base_year = base_year, scen = sc_i)
    }
    if (length(per_variant) == 0)
      stop("No variant of '", tech_name, "' produced a levelized cost.",
           call. = FALSE)

    return(.levcost_variants_object(per_variant, vprov, tech_name))
  }

  scen <- build_and_solve_(demand_objects)
  if (!isTRUE(scen@status$optimal))
    warning("Mini model for '", tech_name, "' did not solve to optimality. ",
            "LCOE results may be unreliable.")
  base_res           <- levcost_extract_(scen, base_lcoe_dvals)
  levcost_tbl        <- base_res$levcost
  levcost_npv        <- base_res$levcost_npv
  cost_breakdown     <- base_res$cost_breakdown
  cost_breakdown_npv <- base_res$cost_breakdown_npv
  cost_yearly        <- base_res$cost_yearly
  levcost_per_act    <- base_res$levcost_per_act

  # ── 12.5. Frontier solves: one per output commodity corner ──────────────────
  frontier_raw <- list()
  if (do_frontier) {
    for (prim in out_comms) {
      si      <- if (is.finite(share_up[[prim]])) share_up[[prim]] else 1 / length(out_comms)
      n_other <- length(out_comms) - 1
      dv_oth  <- if (n_other > 0) (1 - si) / n_other else 0
      dem_fr  <- setNames(rep(max(dv_oth, 1e-6), length(out_comms)), out_comms)
      dem_fr[[prim]] <- si
      dobj_fr  <- make_demands_(dem_fr)
      scen_fr  <- build_and_solve_(dobj_fr, suffix = paste0("_fr_", prim))
      if (!isTRUE(scen_fr@status$optimal))
        warning("Frontier scenario max_", prim, " for '", tech_name,
                "' did not solve to optimality.")
      fr_res <- levcost_extract_(scen_fr, dem_fr, primary_comm = prim)
      frontier_raw[[paste0("max_", prim)]] <- c(fr_res,
        list(primary_comm = prim, primary_input = NA_character_, dem_vals = dem_fr))
    }
  }

  # ── 12.7. Input frontier solves ──────────────────────────────────────────────
  if (do_frontier && length(in_groups) > 0) {
    inp_frontier_groups <- Filter(function(g) length(in_group_comms[[g]]) >= 2, in_groups)
    if (length(inp_frontier_groups) > 0) {
      original_ceff <- object@ceff
      for (prim_out in out_comms) {
        si_out  <- if (is.finite(share_up[[prim_out]])) share_up[[prim_out]] else
          1 / length(out_comms)
        n_oth   <- length(out_comms) - 1
        dv_oth  <- if (n_oth > 0) (1 - si_out) / n_oth else 0
        dem_ifr <- setNames(rep(max(dv_oth, 1e-6), length(out_comms)), out_comms)
        dem_ifr[[prim_out]] <- si_out
        dobj_ifr <- make_demands_(dem_ifr)

        for (grp in inp_frontier_groups) {
          grp_comms <- in_group_comms[[grp]]
          already_fixed <- character(0)
          if ("grp.share.fx" %in% names(original_ceff)) {
            for (cm in grp_comms) {
              rf <- original_ceff[original_ceff$comm == cm &
                !is.na(original_ceff$grp.share.fx), , drop = FALSE]
              if (nrow(rf) > 0) already_fixed <- c(already_fixed, cm)
            }
          }
          vary_comms <- setdiff(grp_comms, already_fixed)
          if (length(vary_comms) < 2) next

          for (prim_inp in vary_comms) {
            object@ceff <- original_ceff
            inp_su  <- in_share_up[[grp]][[prim_inp]]
            fx_val  <- if (is.finite(inp_su)) inp_su else 1.0
            other_comms <- setdiff(grp_comms, prim_inp)
            other_fx    <- if (length(other_comms) > 0) (1 - fx_val) / length(other_comms) else 0
            if (!"grp.share.fx" %in% names(object@ceff)) object@ceff$grp.share.fx <- NA_real_
            for (cm in grp_comms) {
              rows <- which(object@ceff$comm == cm)
              if (length(rows) > 0)
                object@ceff$grp.share.fx[rows] <- if (cm == prim_inp) fx_val else other_fx
            }
            suffix   <- paste0("_fr_", prim_out, "_", prim_inp)
            scen_ifr <- build_and_solve_(dobj_ifr, suffix = suffix)
            if (!isTRUE(scen_ifr@status$optimal))
              warning("Input frontier scenario max_", prim_out, "_max_", prim_inp,
                      " for '", tech_name, "' did not solve to optimality.")
            ifr_res <- levcost_extract_(scen_ifr, dem_ifr, primary_comm = prim_out)
            frontier_raw[[paste0("max_", prim_out, "_max_", prim_inp)]] <-
              c(ifr_res, list(primary_comm = prim_out,
                              primary_input = prim_inp,
                              dem_vals = dem_ifr))
            if (verbose) message("Input frontier: max_", prim_out, "_max_", prim_inp)
          }
        }
      }
      object@ceff <- original_ceff
    }
  }

  # ── 13. Frontier result assembly ─────────────────────────────────────────────
  frontier_df        <- NULL
  levcost_by_comm    <- NULL
  levcost_by_act     <- NULL
  levcost_by_act_cbd <- NULL

  if (length(frontier_raw) > 0) {
    bc_rows <- lapply(names(frontier_raw), function(sc_nm) {
      fr     <- frontier_raw[[sc_nm]]
      npv_df <- fr$cost_breakdown_npv
      if (is.null(npv_df)) return(NULL)
      npv_df$scenario      <- sc_nm
      npv_df$comm          <- fr$primary_comm
      npv_df$primary_input <- if (!is.null(fr$primary_input)) fr$primary_input else NA_character_
      npv_df
    })
    levcost_by_comm <- do.call(rbind, Filter(Negate(is.null), bc_rows))
    if (!is.null(levcost_by_comm)) rownames(levcost_by_comm) <- NULL

    act_rows <- lapply(names(frontier_raw), function(sc_nm) {
      fr     <- frontier_raw[[sc_nm]]
      lca_df <- fr$levcost_per_act
      if (is.null(lca_df) || nrow(lca_df) == 0) return(NULL)
      lca_df$te  <- lca_df$year - as.integer(base_year)
      lca_df$dsc <- (1 + discount)^lca_df$te
      vld_cost <- is.finite(lca_df$cost)     & is.finite(lca_df$dsc) & lca_df$dsc > 0
      vld_act  <- is.finite(lca_df$activity) & is.finite(lca_df$dsc) & lca_df$dsc > 0
      npv_cost <- if (any(vld_cost)) sum(lca_df$cost[vld_cost]     / lca_df$dsc[vld_cost]) else NA_real_
      npv_act  <- if (any(vld_act))  sum(lca_df$activity[vld_act]  / lca_df$dsc[vld_act])  else NA_real_
      npv_lca  <- if (is.finite(npv_act) && npv_act > 0) npv_cost / npv_act else NA_real_
      data.frame(
        tech = lca_df$tech[1], group = lca_df$group[1],
        scenario = sc_nm, primary_comm  = fr$primary_comm,
        primary_input = if (!is.null(fr$primary_input)) fr$primary_input else NA_character_,
        npv_act = npv_lca, stringsAsFactors = FALSE
      )
    })
    levcost_by_act <- do.call(rbind, Filter(Negate(is.null), act_rows))
    if (!is.null(levcost_by_act)) rownames(levcost_by_act) <- NULL

    act_cbd_rows <- lapply(names(frontier_raw), function(sc_nm) {
      fr     <- frontier_raw[[sc_nm]]
      cbd_pa <- fr$cost_breakdown_npv_per_act
      if (is.null(cbd_pa) || nrow(cbd_pa) == 0) return(NULL)
      cbd_pa$scenario      <- sc_nm
      cbd_pa$primary_comm  <- fr$primary_comm
      cbd_pa$primary_input <- if (!is.null(fr$primary_input)) fr$primary_input else NA_character_
      cbd_pa
    })
    levcost_by_act_cbd <- do.call(rbind, Filter(Negate(is.null), act_cbd_rows))
    if (!is.null(levcost_by_act_cbd)) rownames(levcost_by_act_cbd) <- NULL

    # 2D production frontier table (only for 2-output-commodity grouped techs)
    if (length(out_comms) == 2) {
      c1 <- out_comms[1]; c2 <- out_comms[2]
      sfget_fr <- function(sc, v) tryCatch({
        d <- getData(sc, name = v, merge = TRUE, drop.zeros = FALSE,
                   timeframe = "lowest")   # annual totals; see .levcost_scenario_fuel
        if (is.null(d) || nrow(d) == 0) return(NULL); as.data.frame(d)
      }, error = function(e) NULL)

      out_only_names <- names(frontier_raw)[vapply(frontier_raw, function(fr)
        is.null(fr$primary_input) || is.na(fr$primary_input), logical(1))]
      fr_pts <- do.call(rbind, lapply(out_only_names, function(sc_nm) {
        fr   <- frontier_raw[[sc_nm]]
        sc   <- fr$scen
        tout <- sfget_fr(sc, "vTechOut")
        if (is.null(tout)) return(NULL)
        tout$year <- as.integer(tout$year)
        agg <- aggregate(value ~ comm + year, tout, sum, na.rm = TRUE)
        tc_f <- sfget_fr(sc, "vTotalCost")
        if (is.null(tc_f)) return(NULL)
        tc_f$year <- as.integer(tc_f$year)
        do.call(rbind, lapply(unique(agg$year), function(yr) {
          p1 <- agg$value[agg$comm == c1 & agg$year == yr]
          p2 <- agg$value[agg$comm == c2 & agg$year == yr]
          tc <- tc_f$value[tc_f$year == yr]
          data.frame(
            scenario   = sc_nm, year = yr,
            prod_comm1 = if (length(p1) > 0) p1[1] else NA_real_,
            prod_comm2 = if (length(p2) > 0) p2[1] else NA_real_,
            total_cost = if (length(tc) > 0) tc[1] else NA_real_,
            stringsAsFactors = FALSE
          )
        }))
      }))
      if (!is.null(fr_pts) && nrow(fr_pts) > 0) {
        fr_pts$tech           <- tech_name
        fr_pts$comm1          <- c1
        fr_pts$comm2          <- c2
        fr_pts$share_up_comm1 <- share_up[[c1]]
        fr_pts$share_up_comm2 <- share_up[[c2]]
        frontier_df <- fr_pts; rownames(frontier_df) <- NULL
      }
    }
  }

  # ── 13.5. Geometric share constraint segments ─────────────────────────────────
  input_frontier <- tech_share_frontier(object)

  # ── 13.9. Technology units ────────────────────────────────────────────────────
  tech_units <- .levcost_tech_units(object, out_comms)

  # ── 14. Return ────────────────────────────────────────────────────────────────
  if (as_scenario) {
    scen@misc$levcost            <- levcost_tbl
    scen@misc$levcost_npv        <- levcost_npv
    scen@misc$cost_breakdown     <- cost_breakdown
    scen@misc$cost_breakdown_npv <- cost_breakdown_npv
    scen@misc$cost_yearly        <- cost_yearly
    scen@misc$levcost_per_act    <- levcost_per_act
    scen@misc$frontier           <- frontier_df
    scen@misc$levcost_by_comm    <- levcost_by_comm
    scen@misc$levcost_by_act     <- levcost_by_act
    scen@misc$levcost_by_act_cbd <- levcost_by_act_cbd
    scen@misc$input_frontier     <- input_frontier
    return(scen)
  }

  lc_name <- tech_name
  result <- list(
    levcost            = levcost_tbl,
    levcost_npv        = setNames(levcost_npv, lc_name),
    cost_breakdown     = cost_breakdown,
    cost_breakdown_npv = cost_breakdown_npv,
    levcost_per_act    = levcost_per_act,
    cost_yearly        = cost_yearly,
    frontier           = frontier_df,
    levcost_by_comm    = levcost_by_comm,
    levcost_by_act     = levcost_by_act,
    levcost_by_act_cbd = levcost_by_act_cbd,
    input_frontier     = input_frontier,
    discount           = discount,
    base_year          = as.integer(base_year),
    units              = tech_units,
    scenario           = scen
  )
  class(result) <- c("levcost", "list")
  result
}

# ── plot_share_frontier ─────────────────────────────────────────────────────────

#' Plot feasible share-mix diagram for technology inputs/outputs
#'
#' Builds the diagonal share-mix chart from a \code{\link{tech_share_frontier}}
#' data.frame.  Returns a named list of class \code{"share_frontier_plots"} of
#' \code{ggplot2} objects, one per (direction × group).
#'
#' @param object data.frame from \code{tech_share_frontier()}.
#' @param title  Optional character string prepended to each plot title.
#' @param base_size Integer. Base font size passed to \code{theme_energyRt()}.
#' @return A list of class \code{"share_frontier_plots"}, or \code{NULL}.
#' @export
#' @examples
#' # a co-firing plant whose biomass may cover at most 30% of the fuel group
#' chp <- newTechnology(
#'   "CHP",
#'   input   = data.frame(comm = c("COA", "BIO"), group = "fuel"),
#'   output  = data.frame(comm = "ELC"),
#'   group   = data.frame(group = "fuel", unit = "MMBtu"),
#'   ceff    = data.frame(comm = c("COA", "BIO"), cinp2use = c(0.40, 0.35),
#'                        grp.share.up = c(1, 0.3)),
#'   cap2act = 8760
#' )
#'
#' # one ggplot per (direction x group)
#' p <- plot_share_frontier(tech_share_frontier(chp))
#' names(p)
#' p[[1]]
plot_share_frontier <- function(object, title = NULL, base_size = 11L) {
  if (is.null(object) || nrow(object) == 0) return(NULL)
  check_package("ggplot2")

  if (!"share_lo_eff" %in% names(object)) object$share_lo_eff <- object$share_lo
  if (!"share_hi_eff" %in% names(object)) object$share_hi_eff <- object$share_hi
  if (!"n_in_group"  %in% names(object)) object$n_in_group    <- NA_integer_

  dir_cols <- c(input = "#E84B35", output = "#4E79A7")

  .diagonal_layers <- function(col) {
    list(
      ggplot2::annotate("segment",
        x = 0, xend = 1, y = 1, yend = 0,
        colour = "grey80", linewidth = 0.5, linetype = "solid"),
      ggplot2::geom_rect(
        ggplot2::aes(xmin = share_lo_eff, xmax = share_hi_eff, ymin = 0, ymax = 1),
        fill = col, alpha = 0.12),
      ggplot2::geom_segment(
        ggplot2::aes(x = share_lo_eff, xend = share_hi_eff,
                     y = 1 - share_lo_eff, yend = 1 - share_hi_eff),
        colour = col, linewidth = 2.2),
      ggplot2::geom_point(
        ggplot2::aes(x = share_lo_eff, y = 1 - share_lo_eff),
        colour = col, size = 2.5, shape = 16),
      ggplot2::geom_point(
        ggplot2::aes(x = share_hi_eff, y = 1 - share_hi_eff),
        colour = col, size = 2.5, shape = 16),
      ggplot2::geom_text(
        ggplot2::aes(x = share_lo_eff, y = 1 - share_lo_eff,
                     label = paste0(round(share_lo_eff * 100), "%")),
        hjust = 1.25, vjust = 0.5, size = 2.5, colour = col),
      ggplot2::geom_text(
        ggplot2::aes(x = share_hi_eff, y = 1 - share_hi_eff,
                     label = paste0(round(share_hi_eff * 100), "%")),
        hjust = -0.25, vjust = 0.5, size = 2.5, colour = col)
    )
  }

  .base_scales <- function(x_name, y_name) {
    list(
      ggplot2::coord_fixed(ratio = 1, xlim = c(0, 1), ylim = c(0, 1),
                           expand = TRUE, clip = "off"),
      ggplot2::scale_x_continuous(
        name = x_name, breaks = c(0, 0.25, 0.5, 0.75, 1),
        labels = function(x) paste0(round(x * 100), "%")),
      ggplot2::scale_y_continuous(
        name = y_name, breaks = c(0, 0.25, 0.5, 0.75, 1),
        labels = function(x) paste0(round(x * 100), "%")),
      theme_energyRt(base_size = base_size),
      ggplot2::theme(
        panel.grid.minor = ggplot2::element_blank(),
        strip.text       = ggplot2::element_text(size = 7),
        axis.title       = ggplot2::element_text(size = 8, face = "bold"),
        plot.title       = ggplot2::element_text(size = 8, colour = "grey30",
                                                 hjust = 0.5, face = "bold"),
        plot.margin      = ggplot2::margin(4, 8, 4, 4))
    )
  }

  all_plots <- list()
  for (dir in c("input", "output")) {
    sub_dir <- object[object$direction == dir, , drop = FALSE]
    if (nrow(sub_dir) == 0L) next
    col <- dir_cols[[dir]]
    for (grp in unique(sub_dir$group)) {
      sub <- sub_dir[sub_dir$group == grp, , drop = FALSE]
      n_g <- if (!is.na(sub$n_in_group[1])) sub$n_in_group[1] else nrow(sub)
      plot_title <- if (!is.null(title)) paste0(title, "  |  ", dir, ": ", grp)
                    else paste0(dir, ": ", grp)
      if (n_g == 2L) {
        row1 <- sub[1L, , drop = FALSE]
        p <- ggplot2::ggplot(row1) +
          .diagonal_layers(col) +
          .base_scales(x_name = row1$comm[1], y_name = row1$others[1]) +
          ggplot2::labs(title = plot_title)
      } else {
        sub$facet_lab <- paste0(sub$comm, "\nvs. ", sub$others)
        p <- ggplot2::ggplot(sub) +
          .diagonal_layers(col) +
          ggplot2::facet_wrap(~facet_lab) +
          .base_scales(x_name = "Share of commodity", y_name = "Share of rest") +
          ggplot2::labs(title = plot_title)
      }
      all_plots[[paste(dir, grp, sep = ":::")]] <- p
    }
  }
  if (length(all_plots) == 0L) return(NULL)
  n_total <- length(all_plots)
  if (n_total > 16L) all_plots <- all_plots[seq_len(16L)]
  n_panels <- length(all_plots)
  attr(all_plots, "n_per_row") <- min(n_panels, 4L)
  attr(all_plots, "n_panels")  <- n_panels
  attr(all_plots, "n_total")   <- n_total
  class(all_plots) <- c("share_frontier_plots", "list")
  all_plots
}

#' @method print share_frontier_plots
#' @export
print.share_frontier_plots <- function(x, ...) {
  if (requireNamespace("patchwork", quietly = TRUE)) {
    n_per_row <- attr(x, "n_per_row")
    if (is.null(n_per_row)) n_per_row <- min(length(x), 4L)
    print(patchwork::wrap_plots(x, ncol = n_per_row))
  } else {
    for (p in x) print(p)
  }
  invisible(x)
}

# ── autoplot / print methods ────────────────────────────────────────────────────
# autoplot() is the ggplot2 generic; energyRt registers its methods against it
# with the fully-qualified S3method(ggplot2::autoplot, <class>) form (delayed
# registration, no hard ggplot2 dependency). Users call it via library(ggplot2).

.levcost_comp_order  <- c("eac", "fixom", "varom", "supply", "import", "export")
.levcost_comp_labels <- c(eac    = "EAC (Annualised Inv.)",
                           fixom  = "Fixed O&M",
                           varom  = "Variable O&M",
                           supply = "Supply / Fuel",
                           import = "Import",
                           export = "Export (credit)")

#' @method print levcost
#' @export
print.levcost <- function(x, ...) {
  cat("levcost\n")
  cat("  Technology:  ", names(x$levcost_npv), "\n", sep = "")
  cat("  NPV LCOE:    ", round(x$levcost_npv, 4), "\n", sep = "")
  if (!is.null(x$cost_breakdown_npv) && nrow(x$cost_breakdown_npv) > 0) {
    cat("  Components:  ")
    cat(paste(x$cost_breakdown_npv$component, collapse = ", "), "\n")
  }
  yr <- x$levcost$year[!is.na(x$levcost$year)]
  if (length(yr) > 0)
    cat("  Years:       ", min(yr), "\u2013", max(yr), " (", length(yr), ")\n", sep = "")
  cat("  Discount:    ", x$discount * 100, "%\n", sep = "")
  cat("  Frontier:    ", if (!is.null(x$frontier)) "yes" else "no (run with frontier=TRUE)", "\n", sep = "")
  invisible(x)
}

#' @method print levcost_list
#' @export
print.levcost_list <- function(x, ...) {
  cat("levcost_list (", length(x), " processes)\n", sep = "")
  for (nm in names(x)) {
    npv <- tryCatch(x[[nm]]$levcost_npv, error = function(e) NA_real_)
    cat("  ", nm, ": ", round(npv, 4), "\n", sep = "")
  }
  invisible(x)
}

#' @exportS3Method ggplot2::autoplot
autoplot.levcost <- function(object,
                             type = c("components", "npv", "totals",
                                      "frontier", "input_frontier"),
                             year = NULL,
                             cost_unit = NULL,
                             cost_unit_comm = NULL,
                             ...) {
  check_package("ggplot2")
  type  <- match.arg(type)
  npv   <- as.numeric(object$levcost_npv)
  title <- paste0("Levelized Cost: ", names(object$levcost_npv))

  .parse_cu <- function(cu) {
    m <- regmatches(cu, regexec("^(.+)/\\((.+)\\)$", cu))[[1]]
    if (length(m) == 3) list(currency = m[2], denom = m[3])
    else list(currency = cu, denom = "")
  }
  .cost_axis_label <- function(cu, cu_comm = NULL) {
    p <- .parse_cu(cu)
    lbl <- if (nzchar(p$denom)) paste(p$currency, "per", p$denom) else p$currency
    if (!is.null(cu_comm) && nzchar(cu_comm)) {
      pc <- .parse_cu(cu_comm)
      if (nzchar(pc$denom)) lbl <- paste0(lbl, " or ", pc$denom)
    }
    lbl
  }
  if (!is.null(cost_unit) && nzchar(cost_unit)) {
    y_lbl_act  <- .cost_axis_label(cost_unit)
    y_lbl_both <- .cost_axis_label(cost_unit, cost_unit_comm)
  } else {
    cu <- if (!is.null(object$units$costs)    && nzchar(object$units$costs))    object$units$costs    else ""
    au <- if (!is.null(object$units$activity) && nzchar(object$units$activity)) object$units$activity else ""
    costs_lbl  <- if (nzchar(cu) && nzchar(au)) paste0(cu, " / ", au)
                  else if (nzchar(cu)) cu else ""
    # the output is not necessarily energy -- no hardwired "LCOE"
    y_lbl_act  <- if (nzchar(costs_lbl)) paste0("Levelized cost [", costs_lbl, "]") else "Levelized cost"
    y_lbl_both <- y_lbl_act
  }

  # ── frontier type ────────────────────────────────────────────────────────────
  if (type == "frontier") {
    df <- object$frontier
    if (is.null(df) || nrow(df) == 0) {
      message("No frontier data available. Run levcost() with frontier = TRUE ",
              "and a grouped technology with >= 2 output commodities with grp.share.up.")
      return(invisible(NULL))
    }
    yr_sel <- if (!is.null(year)) as.integer(year) else min(df$year, na.rm = TRUE)
    df_yr  <- df[df$year == yr_sel, , drop = FALSE]
    c1_lbl <- df_yr$comm1[1]; c2_lbl <- df_yr$comm2[1]
    su1    <- df_yr$share_up_comm1[1]; su2 <- df_yr$share_up_comm2[1]
    df_yr$label <- ifelse(
      df_yr$scenario == paste0("max_", c1_lbl),
      paste0("max ", c1_lbl, " (share \u2264 ", round(su1 * 100), "%)"),
      paste0("max ", c2_lbl, " (share \u2264 ", round(su2 * 100), "%)")
    )
    lca_df <- object$levcost_by_act
    df_yr$levcost_label <- sapply(df_yr$scenario, function(sc_nm) {
      if (is.null(lca_df)) return("")
      base_val  <- lca_df$npv_act[match(sc_nm, lca_df$scenario)]
      prim_comm <- sub("^max_", "", sc_nm)
      inp_rows  <- lca_df[!is.na(lca_df$primary_input) &
                          lca_df$primary_comm == prim_comm, , drop = FALSE]
      if (!is.finite(base_val)) return("")
      if (nrow(inp_rows) > 0) {
        all_vals <- c(base_val, inp_rows$npv_act[is.finite(inp_rows$npv_act)])
        lo <- min(all_vals, na.rm = TRUE); hi <- max(all_vals, na.rm = TRUE)
        if (abs(hi - lo) > 1e-6) paste0("LCOE = ", round(lo, 3), "\u2013", round(hi, 3))
        else                     paste0("levcost = ", round(base_val, 3))
      } else {
        paste0("levcost = ", round(base_val, 3))
      }
    })
    p <- ggplot2::ggplot(df_yr, ggplot2::aes(x = prod_comm1, y = prod_comm2, colour = label)) +
      ggplot2::geom_line(colour = "grey50", linewidth = 0.8,
                         data = df_yr[order(df_yr$prod_comm1), ]) +
      ggplot2::geom_point(size = 4) +
      ggplot2::geom_text(ggplot2::aes(label = levcost_label),
                         vjust = -1, size = 3, show.legend = FALSE) +
      ggplot2::scale_colour_brewer(palette = "Set1") +
      ggplot2::coord_cartesian(xlim = c(0, 1), ylim = c(0, 1)) +
      ggplot2::labs(
        title    = paste0("Production Frontier: ", names(object$levcost_npv)),
        subtitle = paste0("Year ", yr_sel),
        x        = paste0("Production share of ", c1_lbl),
        y        = paste0("Production share of ", c2_lbl),
        colour   = "Operating extreme"
      ) + theme_energyRt()
    return(p)
  }

  # ── input_frontier type ───────────────────────────────────────────────────────
  if (type == "input_frontier") {
    df <- object$input_frontier
    p  <- plot_share_frontier(df, title = paste0("Share Mix: ", names(object$levcost_npv)))
    if (is.null(p)) {
      message("No share constraint data available. The technology may have no ",
              "grouped inputs or outputs with grp.share.up / grp.share.lo constraints.")
      return(invisible(NULL))
    }
    return(p)
  }

  # ── totals type ───────────────────────────────────────────────────────────────
  if (type == "totals") {
    df <- object$levcost
    df <- df[!is.na(df$year) & !is.na(df$levcost), ]
    p <- ggplot2::ggplot(df, ggplot2::aes(x = factor(year), y = levcost)) +
      ggplot2::geom_col(fill = "#4E79A7") +
      ggplot2::geom_hline(yintercept = npv, linetype = "dashed", colour = "red") +
      ggplot2::annotate("text", x = Inf, y = npv,
                        label = paste0("NPV LCOE = ", round(npv, 3)),
                        hjust = 1.05, vjust = -0.4, size = 3, colour = "red") +
      ggplot2::labs(title = title, x = "Year", y = y_lbl_act) +
      theme_energyRt() +
      ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45, hjust = 1))
    return(p)
  }

  # ── npv type ──────────────────────────────────────────────────────────────────
  if (type == "npv") {
    has_frontier_data <- !is.null(object$levcost_by_comm) &&
                         nrow(object$levcost_by_comm) > 0
    if (has_frontier_data) {
      npv_rows <- list()
      if (!is.null(object$levcost_by_act) && nrow(object$levcost_by_act) > 0) {
        has_act_cbd <- !is.null(object$levcost_by_act_cbd) &&
                       nrow(object$levcost_by_act_cbd) > 0
        for (i in seq_len(nrow(object$levcost_by_act))) {
          row_i    <- object$levcost_by_act[i, ]
          prim     <- row_i$primary_comm
          sc_nm    <- row_i$scenario
          prim_inp <- if ("primary_input" %in% names(row_i) && !is.na(row_i$primary_input))
            row_i$primary_input else NA_character_
          lbl <- if (!is.na(prim_inp)) paste0("Activity\n(max ", prim, " + ", prim_inp, ")")
                 else paste0("Activity\n(max ", prim, ")")
          if (has_act_cbd) {
            cbd_i <- object$levcost_by_act_cbd[
              object$levcost_by_act_cbd$scenario == sc_nm, , drop = FALSE]
            if (nrow(cbd_i) > 0) {
              cbd_i$comm  <- "Activity"; cbd_i$label <- lbl
              npv_rows[[paste0("act_sc_", i)]] <- cbd_i[,
                c("tech", "group", "comm", "label", "component", "value"), drop = FALSE]
              next
            }
          }
          npv_rows[[paste0("act_sc_", i)]] <- data.frame(
            tech = row_i$tech, group = row_i$group,
            comm = "Activity", label = lbl,
            component = "total", value = row_i$npv_act, stringsAsFactors = FALSE
          )
        }
      }
      fr_df <- object$levcost_by_comm
      for (sc_nm in unique(fr_df$scenario)) {
        sub <- fr_df[fr_df$scenario == sc_nm, , drop = FALSE]
        prim_inp_c <- if ("primary_input" %in% names(sub) && !is.na(sub$primary_input[1]))
          sub$primary_input[1] else NA_character_
        sub$scenario      <- NULL
        sub$primary_input <- NULL
        lbl <- if (!is.na(prim_inp_c))
          paste0(sub$comm[1], "\n(max ", sub$comm[1], " + ", prim_inp_c, ")")
        else
          paste0(sub$comm[1], "\n(max ", sub$comm[1], ")")
        sub$label <- lbl
        npv_rows[[paste0("comm_sc_", sc_nm)]] <- sub[,
          c("tech", "group", "comm", "label", "component", "value"), drop = FALSE]
      }
      plot_df <- do.call(rbind, Filter(Negate(is.null), npv_rows))
      if (is.null(plot_df) || nrow(plot_df) == 0) {
        message("No NPV data to plot."); return(invisible(NULL))
      }
      rownames(plot_df) <- NULL
      comp_ord <- intersect(.levcost_comp_order, unique(plot_df$component))
      plot_df$component <- factor(plot_df$component,
                                  levels = c(comp_ord, setdiff(unique(plot_df$component), comp_ord)))
      plot_df$label <- factor(plot_df$label, levels = unique(plot_df$label))
      p <- ggplot2::ggplot(plot_df[plot_df$value > 0, ],
                           ggplot2::aes(x = label, y = value, fill = component)) +
        ggplot2::geom_col(position = "stack") +
        ggplot2::geom_col(data = plot_df[!is.na(plot_df$value) & plot_df$value < 0, ],
                          ggplot2::aes(x = label, y = value, fill = component),
                          position = "stack") +
        ggplot2::scale_fill_brewer(palette = "Set2",
                                   labels = .levcost_comp_labels[levels(plot_df$component)]) +
        ggplot2::labs(title = paste0("NPV LCOE breakdown: ", names(object$levcost_npv)),
                      x = "Metric", y = y_lbl_both, fill = "Component") +
        theme_energyRt() +
        ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 30, hjust = 1))
      return(p)
    }
    # No frontier data – use base NPV breakdown
    cbd_npv <- object$cost_breakdown_npv
    if (is.null(cbd_npv) || nrow(cbd_npv) == 0) {
      message("No NPV cost breakdown available.")
      return(invisible(NULL))
    }
    comp_ord <- intersect(.levcost_comp_order, unique(cbd_npv$component))
    cbd_npv$component <- factor(cbd_npv$component,
                                levels = c(comp_ord, setdiff(unique(cbd_npv$component), comp_ord)))
    p <- ggplot2::ggplot(cbd_npv, ggplot2::aes(x = "", y = value, fill = component)) +
      ggplot2::geom_col(position = "stack") +
      ggplot2::scale_fill_brewer(palette = "Set2",
                                 labels = .levcost_comp_labels[levels(cbd_npv$component)]) +
      ggplot2::labs(title = paste0("NPV LCOE: ", names(object$levcost_npv)),
                    x = NULL, y = y_lbl_act, fill = "Component") +
      theme_energyRt()
    return(p)
  }

  # ── components type (default) ────────────────────────────────────────────────
  cbd <- object$cost_breakdown
  if (is.null(cbd) || nrow(cbd) == 0) {
    message("No cost breakdown data available.")
    return(invisible(NULL))
  }
  cbd <- cbd[!is.na(cbd$year), ]
  comp_ord    <- intersect(.levcost_comp_order, unique(cbd$component))
  cbd$component <- factor(cbd$component,
                          levels = c(comp_ord, setdiff(unique(cbd$component), comp_ord)))
  total_yr <- stats::aggregate(value ~ year, cbd, sum, na.rm = TRUE)
  p <- ggplot2::ggplot(cbd[cbd$value > 0 | cbd$component == "export", ],
                       ggplot2::aes(x = factor(year), y = value, fill = component)) +
    ggplot2::geom_col(position = "stack") +
    ggplot2::geom_line(data = data.frame(year = factor(total_yr$year), value = total_yr$value),
                       ggplot2::aes(x = year, y = value, group = 1),
                       inherit.aes = FALSE, colour = "grey30", linewidth = 0.7) +
    ggplot2::geom_hline(yintercept = npv, linetype = "dashed", colour = "red") +
    ggplot2::annotate("text", x = Inf, y = npv,
                      label = paste0("NPV = ", round(npv, 3)),
                      hjust = 1.05, vjust = -0.4, size = 3, colour = "red") +
    ggplot2::scale_fill_brewer(palette = "Set2",
                               labels = .levcost_comp_labels[levels(cbd$component)]) +
    ggplot2::labs(title = title, x = "Year", y = y_lbl_act, fill = "Component") +
    theme_energyRt() +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45, hjust = 1))
  p
}

#' @exportS3Method ggplot2::autoplot
autoplot.levcost_list <- function(object,
                                  type = c("components", "npv", "totals",
                                           "frontier", "input_frontier"),
                                  year = NULL, cost_unit = NULL,
                                  cost_unit_comm = NULL,
                                  top_n = NULL, sort = !is.null(top_n),
                                  groups = NULL, ...) {
  check_package("ggplot2")
  type <- match.arg(type)

  # Collect NPV + component breakdowns across technologies. Breakdown frames
  # carry extra columns (tech/group/comm) while the no-breakdown fallback has
  # three, so reduce every piece to the plotted columns before binding --
  # mixing shapes is exactly what a vintage with an empty solution produces.
  npv_rows <- lapply(names(object), function(nm) {
    lc  <- object[[nm]]
    cbd <- lc$cost_breakdown_npv
    if (is.null(cbd) || nrow(cbd) == 0 ||
        !all(c("component", "value") %in% names(cbd))) {
      data.frame(tech = nm, component = "total",
                 value = as.numeric(lc$levcost_npv),
                 stringsAsFactors = FALSE)
    } else {
      cbd$tech <- nm
      cbd[, c("tech", "component", "value"), drop = FALSE]
    }
  })
  plot_df <- do.call(rbind, Filter(Negate(is.null), npv_rows))
  if (is.null(plot_df) || nrow(plot_df) == 0) {
    message("No NPV data available for any technology."); return(invisible(NULL))
  }
  comp_ord <- intersect(.levcost_comp_order, unique(plot_df$component))
  plot_df$component <- factor(plot_df$component,
                              levels = c(comp_ord, setdiff(unique(plot_df$component), comp_ord)))

  # Ordering and capping. The default keeps the list's own order (a variants
  # fan-out is in vintage order); `sort`/`top_n` are for cross-technology
  # comparisons: most expensive first, capped with a caption.
  caption <- NULL
  tot <- stats::aggregate(value ~ tech, plot_df, sum, na.rm = TRUE)
  if (isTRUE(sort)) {
    plot_df$tech <- factor(plot_df$tech,
                           levels = tot$tech[order(-tot$value)])
  } else {
    plot_df$tech <- factor(plot_df$tech, levels = unique(plot_df$tech))
  }
  if (!is.null(top_n) && is.finite(top_n) && top_n < nrow(tot)) {
    keep <- tot$tech[order(-tot$value)][seq_len(top_n)]
    plot_df <- plot_df[plot_df$tech %in% keep, , drop = FALSE]
    plot_df$tech <- droplevels(plot_df$tech)
    caption <- paste0("showing the ", top_n, " most expensive of ",
                      nrow(tot), " processes")
  }

  # `groups` (a .proc_groups() list) facets by topology group; strips carry
  # the short index, the index table maps it back to the structure
  if (!is.null(groups) && length(groups) > 0) {
    gmap <- unlist(lapply(groups, function(g)
      stats::setNames(rep(g$index %||% g$label, length(g$members)),
                      g$members)))
    plot_df$group <- unname(gmap[as.character(plot_df$tech)])
    plot_df$group[is.na(plot_df$group)] <- "other"
    plot_df <- .facet_cap(plot_df, "group")
  }

  # y-axis label: an explicit `cost_unit` wins; otherwise fall back to the
  # units the levcost results carry (same contract as autoplot.levcost) --
  # every element shares the source object's units, so the first one speaks
  # for the list
  y_lbl <- .levcost_cost_axis_label(cost_unit, object[[1]]$units)

  p <- ggplot2::ggplot(plot_df,
                       ggplot2::aes(x = tech, y = value, fill = component)) +
    ggplot2::geom_col(position = "stack") +
    ggplot2::scale_fill_brewer(palette = "Set2",
                               labels = .levcost_comp_labels[levels(plot_df$component)]) +
    ggplot2::labs(title = "NPV LCOE comparison", x = "Technology",
                  y = y_lbl, fill = "Component", caption = caption) +
    theme_energyRt() +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 30, hjust = 1))
  if (!is.null(plot_df$group))
    p <- p + ggplot2::facet_wrap(~group, scales = "free_x")
  .facet_caption(p, plot_df)
}

# ── Variant figures: comparing cells across vintage / cluster / region ───────
# A variant fan-out is a GRID, but `autoplot.levcost_list()` only knows `tech`,
# so it can only put raw cell names (`PWR_VIN2030_CLT3`) on one axis. These
# helpers recover the grid so one dimension can go on x and another into facets.
# The dimensions come from the fan-out's own provenance (the `variants`
# attribute), never from parsing a cell name.

# Shared with the `levcost_list` method: an explicit `cost_unit` wins, else the
# units the result carries.
#' @noRd
.levcost_cost_axis_label <- function(cost_unit = NULL, units = NULL) {
  if (!is.null(cost_unit) && nzchar(cost_unit))
    return(paste0("Levelized cost [", cost_unit, "]"))
  cu <- if (!is.null(units$costs) && nzchar(units$costs)) units$costs else ""
  au <- if (!is.null(units$activity) && nzchar(units$activity)) units$activity else ""
  if (nzchar(cu))
    return(paste0("Levelized cost [",
                  if (nzchar(au)) paste0(cu, " / ", au) else cu, "]"))
  "Levelized Cost"
}

#' @noRd
.levcost_dim_label <- function(d) {
  lbl <- c(variant = "Variant", vintage = "Vintage", cluster = "Cluster",
           region = "Region")[d]
  unname(ifelse(is.na(lbl), d, lbl))
}

# Long NPV-component frame for one fan-out, or for a `by_region = TRUE` list of
# them. One row per (cell, component).
#' @noRd
.levcost_variants_long <- function(object) {
  one <- function(obj, region_hint = NA_character_) {
    key <- attr(obj, "variants")
    if (is.null(key) || nrow(key) == 0) return(NULL)
    parts <- lapply(names(obj), function(nm) {
      lc <- obj[[nm]]
      if (is.null(lc)) return(NULL)
      k <- key[key$variant == nm, , drop = FALSE]
      if (nrow(k) == 0) return(NULL)
      cbd <- lc$cost_breakdown_npv
      cmp <- if (is.null(cbd) || nrow(cbd) == 0 ||
                 !all(c("component", "value") %in% names(cbd))) {
        data.frame(component = "total", value = as.numeric(lc$levcost_npv),
                   stringsAsFactors = FALSE)
      } else {
        cbd[, c("component", "value"), drop = FALSE]
      }
      # the REAL region, as extraction rewrote it -- never the artificial one
      reg <- region_hint
      if (!is.null(lc$levcost) && "region" %in% names(lc$levcost) &&
          nrow(lc$levcost) > 0) {
        r <- unique(as.character(lc$levcost$region))
        r <- r[!is.na(r)]
        if (length(r) == 1L) reg <- r
      }
      data.frame(variant = nm,
                 vintage = as.character(k$vintage[1]),
                 cluster = as.character(k$cluster[1]),
                 region  = as.character(reg),
                 cmp, stringsAsFactors = FALSE)
    })
    do.call(rbind, Filter(Negate(is.null), parts))
  }

  df <- if (inherits(object, "levcost_variants")) {
    one(object)
  } else if (is.list(object) &&
             any(vapply(object, inherits, logical(1), "levcost_variants"))) {
    # `by_region = TRUE` nests region -> fan-out; the list names are the regions
    nms <- names(object)
    do.call(rbind, Filter(Negate(is.null), lapply(seq_along(object), function(i) {
      o <- object[[i]]
      if (!inherits(o, "levcost_variants")) return(NULL)
      one(o, region_hint = if (!is.null(nms)) nms[i] else NA_character_)
    })))
  } else NULL

  if (is.null(df) || nrow(df) == 0) return(NULL)
  rownames(df) <- NULL
  df
}

# Which variant dimensions actually distinguish cells. A figure keyed on a
# constant dimension says nothing, so `report()` asks this before drawing.
#' @noRd
.levcost_variant_dims <- function(df) {
  if (is.null(df) || nrow(df) == 0) return(character())
  Filter(function(d) {
    v <- unique(df[[d]][!is.na(df[[d]]) & nzchar(df[[d]])])
    length(v) > 1L
  }, intersect(c("vintage", "cluster", "region"), names(df)))
}

# `x` carries one dimension, `facet` the others; anything left over is AVERAGED,
# never summed -- a levelized cost is a rate, so adding two cells is meaningless.
# The caption says when that happened, and when panels were capped.
#' @noRd
.levcost_variant_plot <- function(df, x = "variant", facet = NULL,
                                  cost_unit = NULL, units = NULL,
                                  title = NULL, angle = NULL) {
  check_package("ggplot2")
  keep <- unique(c(x, facet))
  dims <- intersect(c("vintage", "cluster", "region"), names(df))
  drop <- setdiff(dims, keep)
  grp  <- c(keep, "component")
  fml  <- stats::as.formula(paste("value ~", paste(grp, collapse = " + ")))
  sub  <- df[, c(grp, "value"), drop = FALSE]
  collapsed <- any(stats::aggregate(fml, sub, length)$value > 1)
  d <- stats::aggregate(fml, sub, mean, na.rm = TRUE)

  comp_ord <- intersect(.levcost_comp_order, unique(d$component))
  d$component <- factor(d$component,
                        levels = c(comp_ord,
                                   setdiff(unique(d$component), comp_ord)))
  # a plain column name keeps aes() out of rlang territory
  d$.xv <- factor(as.character(d[[x]]), levels = unique(as.character(df[[x]])))

  if (!is.null(facet)) d <- .facet_cap(d, facet)
  n_panel <- attr(d, "n_panels")
  n_total <- attr(d, "n_total")
  if (is.null(n_panel)) n_panel <- 1L
  if (is.null(n_total)) n_total <- 1L
  d$.xv <- droplevels(d$.xv)

  cap <- character()
  if (collapsed && length(drop) > 0)
    cap <- c(cap, paste0("averaged over ", paste(drop, collapse = ", ")))
  if (!is.null(facet) && n_total > n_panel)
    cap <- c(cap, paste0("showing ", n_panel, " of ", n_total, " panels"))

  # A cell label is long, so rotate once there are more than a handful and let
  # ggplot drop colliding labels rather than overprint them.
  n_x <- length(levels(d$.xv))
  ang <- if (!is.null(angle)) angle else
    if (identical(x, "variant") || n_x > 6L) 45 else 0

  p <- ggplot2::ggplot(d, ggplot2::aes(x = .xv, y = value, fill = component)) +
    ggplot2::geom_col(position = "stack") +
    ggplot2::scale_x_discrete(
      guide = ggplot2::guide_axis(angle = ang, check.overlap = n_x > 12L)) +
    ggplot2::scale_fill_brewer(
      palette = "Set2",
      labels = .levcost_comp_labels[levels(d$component)]) +
    ggplot2::labs(title = title,
                  caption = if (length(cap)) paste(cap, collapse = "; ") else NULL,
                  x = .levcost_dim_label(x),
                  y = .levcost_cost_axis_label(cost_unit, units),
                  fill = "Component") +
    theme_energyRt()
  if (!is.null(facet)) {
    p <- p + ggplot2::facet_wrap(facet) +
      ggplot2::labs(subtitle = paste0(
        "by ", paste(.levcost_dim_label(facet), collapse = " + ")))
  }
  attr(p, "n_panels") <- n_panel
  attr(p, "n_x") <- n_x
  p
}

#' Compare levelized cost across a technology's variant grid
#'
#' `autoplot()` for a variant fan-out -- the result of `levcost()` on a
#' technology declaring `@vintage` or `@cluster`. The fan-out is a grid, so `x`
#' and `facet` pick which dimension goes where; any dimension left out is
#' averaged, because a levelized cost is a rate and cells cannot be summed.
#'
#' @param object A `levcost_variants` object.
#' @param type `"npv"` (default) draws the variant comparison; any other value
#'   is passed to the `levcost_list` method.
#' @param x Dimension on the x axis: `"auto"` (the full cell label, same as
#'   `"variant"`), `"variant"`, `"vintage"`, `"cluster"` or `"region"`.
#' @param facet Dimensions to facet by, or `NULL`. The panel count is capped and
#'   the caption reports the cap.
#' @param cost_unit Cost unit for the y axis; defaults to the units carried by
#'   the result.
#' @param angle x-label angle. By default labels rotate once they would collide.
#' @param ... Passed to the `levcost_list` method for other `type`s.
#' @returns A `ggplot` object.
#' @exportS3Method ggplot2::autoplot
autoplot.levcost_variants <- function(object,
                                      type = c("npv", "components", "totals",
                                               "frontier", "input_frontier"),
                                      x = c("auto", "variant", "vintage",
                                            "cluster", "region"),
                                      facet = NULL, cost_unit = NULL,
                                      angle = NULL, ...) {
  type <- match.arg(type)
  x    <- match.arg(x)
  if (!identical(type, "npv"))
    return(autoplot.levcost_list(object, type = type, cost_unit = cost_unit, ...))

  # Without provenance the grid cannot be recovered -- an object built by hand,
  # or serialized before the `variants` attribute existed. Fall back to the
  # list method, which needs only the elements themselves.
  df <- .levcost_variants_long(object)
  if (is.null(df) || nrow(df) == 0)
    return(autoplot.levcost_list(object, type = "npv",
                                 cost_unit = cost_unit, ...))
  if (identical(x, "auto")) x <- "variant"
  facet <- intersect(facet, c("vintage", "cluster", "region"))
  if (length(facet) == 0) facet <- NULL
  .levcost_variant_plot(df, x = x, facet = facet, cost_unit = cost_unit,
                        units = object[[1]]$units,
                        title = attr(object, "base_tech"), angle = angle)
}

# -- plot() for the levcost S3 classes ----------------------------------------
# The S4 classes get `plot()` via `setMethod()` in R/plot.R; `levcost` and
# `levcost_list` are S3, so they need S3 methods to reach the same contract:
# whichever verb a user types works, and `autoplot()` stays the single
# implementation. The value is returned rather than printed, matching the S4
# methods -- R auto-prints a visible result at top level.

#' @exportS3Method base::plot
plot.levcost <- function(x, y, ...) {
  check_package("ggplot2")
  ggplot2::autoplot(x, ...)
}

#' @exportS3Method base::plot
plot.levcost_list <- function(x, y, ...) {
  check_package("ggplot2")
  ggplot2::autoplot(x, ...)
}


# ---------------------------------------------------------------------------
# (was R/levcost_cache.R, merged 2026-09-21)
# ---------------------------------------------------------------------------

# =============================================================================#
# levcost_cache.R — on-disk cache for levcost() results.
#
# A levcost result is a pure function of (object content, assumptions), so it
# is cached under a key that contains everything affecting the output and
# nothing else. Cached results live WITH the object they price when that
# object is saved (`<owner>/levcost/`); results for in-memory objects are
# temporary and land in the project-level `get_levcost_cache_path()` folder
# (default `levcosts/`). Artifacts: `<name-slug>@<key8>.rds` (the levcost list
# with `$scenario` stripped) plus a `.yml` sidecar carrying the FULL key — the
# 8-character filename is an address, the sidecar is the authority.
# =============================================================================#

# Arguments that select cache behavior; stripped from the compute call.
.levcost_cache_args <- c("cache", "force", "cache_dir")

# Arguments that never affect the result and are excluded from the key.
.levcost_key_drop <- c(.levcost_cache_args, "verbose", "max_failures",
                       "as_scenario", "full_output")

# The folder an object's derived artifacts belong to, or NULL when the object
# is in-memory / unsaved (reports and levcost caches are then temporary).
.object_store_dir <- function(x) {
  if (is(x, "scenario")) {
    p <- x@path
    if (length(p) == 1L && nzchar(p) && dir.exists(p)) return(p)
    return(NULL)
  }
  if (is(x, "model") || is(x, "repository")) {
    p <- x@misc[["path"]]
    if (!is.null(p) && dir.exists(p)) return(p)
    cand <- tryCatch(
      if (is(x, "model")) .model_store_resolve(x@name, NULL) else
        .repo_store_resolve(x@name, NULL),
      error = function(e) NULL)
    if (!is.null(cand) && dir.exists(cand)) return(cand)
  }
  NULL
}

# Resolution order: explicit cache_dir > owning folder (saved objects only) >
# the project-level temporary tier.
.levcost_cache_dir <- function(owner = NULL, cache_dir = NULL) {
  if (!is.null(cache_dir)) return(cache_dir)
  own <- if (!is.null(owner)) .object_store_dir(owner) else NULL
  if (!is.null(own)) return(fp(own, "levcost"))
  get_levcost_cache_path()
}

# The cache key: engine + object content + normalized assumptions. S4 values
# in the assumptions (repo, horizon, calendar, weather objects) enter as
# content hashes; a solver option list enters as its name/lang only (never
# paths); everything else is keyed as passed, sorted by name.
.levcost_cache_key <- function(class, object, args) {
  a <- args[setdiff(names(args), .levcost_key_drop)]
  a <- if (length(a)) a[order(names(a))] else list()
  norm_one <- function(v) {
    if (isS4(v)) return(object_hash(v))
    if (is.list(v) && !is.data.frame(v)) {
      if (!is.null(v[["lang"]])) {
        return(list(name = v[["name"]], lang = v[["lang"]]))
      }
      return(lapply(v, norm_one))   # e.g. repo = list of S4 objects
    }
    v
  }
  rlang::hash(list(engine = paste0("levcost/", class), ver = 1L,
                   object = object_hash(object), args = lapply(a, norm_one)))
}

.levcost_cache_base <- function(dir, name, key) {
  fp(dir, paste0(.path_slug(name), "@", substr(key, 1, 8)))
}

# Recursively drop the solved mini-scenario(s): they are working state, large,
# and reproducible; the cached artifact is the result tables only.
.levcost_strip_scenario <- function(result) {
  if (is.list(result) && !is.data.frame(result)) {
    at <- attributes(result)
    result$scenario <- NULL
    out <- lapply(result, function(el) {
      if (is.list(el) && !is.data.frame(el)) .levcost_strip_scenario(el) else el
    })
    at$names <- names(out)   # lapply drops class and co.; restore everything
    attributes(out) <- at
    return(out)
  }
  result
}

.levcost_cache_read <- function(dir, name, key, verbose = TRUE) {
  base <- .levcost_cache_base(dir, name, key)
  rds <- paste0(base, ".rds")
  yml <- paste0(base, ".yml")
  if (!file.exists(rds) || !file.exists(yml)) return(NULL)
  side <- tryCatch(yaml::read_yaml(yml), error = function(e) NULL)
  if (is.null(side) || !identical(side$key, key)) return(NULL)
  res <- tryCatch(readRDS(rds), error = function(e) NULL)
  if (is.null(res)) return(NULL)
  if (isTRUE(verbose)) {
    message("levcost: cached result is current: ", rds,
            " (force = TRUE to recompute)")
  }
  res
}

.levcost_cache_write <- function(dir, name, key, result, class, method = NULL) {
  ok <- tryCatch({
    if (!dir.exists(dir)) dir.create(dir, recursive = TRUE)
    base <- .levcost_cache_base(dir, name, key)
    saveRDS(.levcost_strip_scenario(result), paste0(base, ".rds"))
    yaml::write_yaml(list(
      kind = "levcost", version = 1L, key = key, class = class,
      process = name, method = method,
      created = format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
      energyRt_version = as.character(utils::packageVersion("energyRt"))
    ), paste0(base, ".yml"))
    TRUE
  }, error = function(e) {
    warning("levcost: could not write the cache entry: ",
            conditionMessage(e), call. = FALSE)
    FALSE
  })
  invisible(ok)
}

# The single integration point, called by the levcost() methods: split the
# cache arguments out of the dots, consult the cache, run the driver on a
# miss (`fun(object, <dots minus cache args>)`), and record the fresh result.
# `as_scenario` requests bypass the cache read (the cached artifact has no
# $scenario) but the computed result is still recorded.
.levcost_with_cache <- function(class, object, dots, fun) {
  cache <- dots[["cache"]] %||% TRUE
  force <- dots[["force"]] %||% FALSE
  verbose <- dots[["verbose"]] %||% TRUE
  name <- if (isS4(object) && .hasSlot(object, "name")) object@name else "levcost"
  dir <- .levcost_cache_dir(object, dots[["cache_dir"]])
  key <- .levcost_cache_key(class, object, dots)
  bypass <- isTRUE(dots[["as_scenario"]]) || isTRUE(dots[["full_output"]])
  if (isTRUE(cache) && !isTRUE(force) && !bypass) {
    hit <- .levcost_cache_read(dir, name, key, verbose = verbose)
    if (!is.null(hit)) return(hit)
  }
  res <- do.call(fun, c(list(object),
                        dots[setdiff(names(dots), .levcost_cache_args)]))
  if (isTRUE(cache) && !bypass && !is.null(res)) {
    .levcost_cache_write(dir, name, key, res, class = class,
                         method = res[["method"]] %||% dots[["method"]])
  }
  res
}

#' Clear cached levcost results
#'
#' Deletes the levcost cache entries belonging to an object (its owning
#' folder's `levcost/` for saved objects, the project-level
#' [get_levcost_cache_path()] folder otherwise), or a directory given
#' directly.
#'
#' @param x an energyRt object whose cache should be cleared, or a character
#'   path to a levcost cache directory.
#' @return the deleted directory, invisibly.
#' @export
#' @examples
#' # drop every memoized levelised cost (they are keyed on the inputs that
#' # produced them, so this is only needed after editing a scenario in place)
#' clear_levcost_cache()
clear_levcost_cache <- function(x = NULL) {
  dir <- if (is.character(x)) x else .levcost_cache_dir(x)
  if (!is.null(dir) && dir.exists(dir)) unlink(dir, recursive = TRUE)
  invisible(dir)
}
