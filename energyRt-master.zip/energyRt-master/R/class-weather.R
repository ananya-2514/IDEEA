#' S4 class to represent weather factors
#' 
#' @name class-weather
#'
#' @inherit newWeather description
#' @inherit newWeather details
#'
#' @md
#' @slot name `r get_slot_doc("weather", "name")`
#' @slot desc `r get_slot_doc("weather", "desc")`
#' @slot unit `r get_slot_doc("weather", "unit")`
#' @slot geoframe `r get_slot_doc("weather", "geoframe")`
#' @slot region `r get_slot_doc("weather", "region")`
#' @slot timeframe `r get_slot_doc("weather", "timeframe")`
#' @slot defVal `r get_slot_doc("weather", "defVal")`
#' @slot cluster `r get_slot_doc("weather", "cluster")`
#' @slot weather `r get_slot_doc("weather", "weather")`
#' @slot misc `r get_slot_doc("weather", "misc")`
#'
#' @include class-export.R
#' @family class weather data
#' @rdname class-weather
#'
#' @export
#'
setClass("weather",
  representation(
    name = "character",
    desc = "character",
    unit = "character",
    geoframe = "character",
    region = "character",
    timeframe = "character",
    defVal = "numeric",
    cluster = "data.frame",
    weather = "data.frame",
    misc = "list"
  ),
  prototype(
    name = "",
    desc = "",
    unit = as.character(NA),
    geoframe = character(),
    region = character(),
    timeframe = character(),
    defVal = 0.,
    # Resource tiers: one series per grade in one object. No share columns --
    # a capacity-factor series has no capacity or activity to tie.
    cluster = data.frame(
      cluster = character(),
      desc = character(),
      region = character(),
      order = integer(),
      stringsAsFactors = FALSE
    ),
    weather = data.frame(
      cluster = character(),
      region = character(), #
      year = integer(),
      timeslice = character(),
      wval = numeric(),
      stringsAsFactors = FALSE
    ),
    misc = list()
  ),
  S3methods = FALSE
)
setMethod("initialize", "weather", function(.Object, ...) {
  .Object
})


#' Create new weather object
#'
#' @description
#' `weather` is a data-carrying class with exogenous shocks
#' used to influence operation of processes in the model.
#'
#' @details
#' Weather factors are separated from the model parameters
#' and can be added or replaced for different scenarios.
#' !!!Additional details...
#'
#' @md
#' @param name `r get_slot_doc("weather", "name")`
#' @param desc `r get_slot_doc("weather", "desc")`
#' @param unit `r get_slot_doc("weather", "unit")`
#' @param geoframe `r get_slot_doc("weather", "geoframe")`
#' @param region `r get_slot_doc("weather", "region")`
#' @param timeframe `r get_slot_doc("weather", "timeframe")`
#' @param defVal `r get_slot_doc("weather", "defVal")`
#' @param cluster `r get_slot_doc("weather", "cluster")`
#' @param weather `r get_slot_doc("weather", "weather")`
#' @param misc `r get_slot_doc("weather", "misc")`
#'
#' @return weather object with given specifications.
#' @export
#' @rdname newWeather
#' @family weather
#'
#' @examples
#' \dontrun{
#' 
#' # use/make time resolution of the model: timetalbe
#' ttbl <- make_timetable(tsl_levels$d365_h24)
#' ttbl
#' 
#' WSOL <- newWeather(
#'   name = "WSOL",
#'   desc = "Horiontal solar PV capacity factor",
#'   timeframe = "HOUR",
#'   defVal = 0.,
#'   weather = data.frame(
#'     region = "R1",
#'     year = 2015, # 
#'     timeslice = ttbl$timeslice,
#'     wval = runif(length(ttbl$timeslice), 0., 1) # use your data
#'   )
#' )
#' }
newWeather <- function(
    name = "",
    desc = "",
    unit = as.character(NA),
    geoframe = character(),
    region = character(),
    timeframe = character(),
    defVal = 0.,
    cluster = data.frame(),
    weather = data.frame(),
    misc = list(),
    ...) {
  .data2slots(
    "weather",
    name,
    desc = desc,
    unit = unit,
    geoframe = geoframe,
    region = region,
    timeframe = timeframe,
    defVal = defVal,
    cluster = cluster,
    weather = weather,
    misc = misc,
    ...
    )
  }

#' @param object object of class weather
#'
#' @param ... slot-names with data to update (see `newWeather`)
#'
#' @rdname newWeather
#' @family update weather
#' @method update weather
#' @export
setMethod("update", "weather", function(object, ...) {
  .data2slots("weather", object, ...)
})



# ---------------------------------------------------------------------------
# (was R/weather_transform.R, merged 2026-09-20)
# ---------------------------------------------------------------------------

# ========================================================================== #
# Weather transforms: one data stream -> many derived series.
#
# A weather object may carry named functions in `@misc$transform`; a consumer
# link (technology/storage/supply `@weather` row) selects one by name in its
# `transform` column. At interpolation, each referenced (weather, transform)
# pair is materialized ONCE into an ordinary derived weather object named
# `<WEATHER>_<TRANSFORM>`, and the link is repointed to it -- the backends
# only ever see plain `pWeather` series, so all four templates are untouched.
#
# The transform contract is `function(weather, ...) -> numeric`: the first
# argument is the stream's `wval` series; `...` receives every non-structural
# column of the SAME link row as a named scalar (NA cells are not forwarded).
# Parameter columns are user-invented -- the weather link slots accept
# undeclared columns (see `.open_slots` in R/data2slots.R).
#
# One name = one series: rows that share a (weather, transform) pair must
# forward identical arguments; differing parameterizations need their own
# names. Functions resolve misc -> session registry -> built-ins, so a model
# whose transforms all live in `@misc` is self-contained when serialized.
# ========================================================================== #

.weather_transform_registry <- new.env(parent = emptyenv())

# Fallbacks when a name is absent from the object's misc and the registry.
# Deliberately assumption-free: anything resource-specific (a power curve, a
# COP curve) belongs to the modeller, in `@misc$transform`.
.builtin_weather_transforms <- list(
  identity = function(weather, ...) weather,
  scale = function(weather, wscale = 1, ...) weather * wscale
)

# Link-table columns that are NOT transform arguments: identifiers and the
# declared multiplier bounds of each class's weather slot.
.weather_link_structural <- list(
  technology = c("vintage", "cluster", "weather", "transform", "comm",
                 "wafc.lo", "wafc.up", "wafc.fx",
                 "waf.lo", "waf.up", "waf.fx",
                 "wafs.lo", "wafs.up", "wafs.fx"),
  storage = c("vintage", "cluster", "weather", "transform",
              "waf.lo", "waf.up", "waf.fx",
              "inp.waf.lo", "inp.waf.up", "inp.waf.fx",
              "out.waf.lo", "out.waf.up", "out.waf.fx"),
  supply = c("cluster", "weather", "transform",
             "wava.lo", "wava.up", "wava.fx")
)

#' Register a weather transform for the session
#'
#' Adds a named transform to the session registry, the middle tier of the
#' lookup chain `weather@misc$transform` -> registry -> built-ins. Transforms
#' stored in a weather object's `misc$transform` list travel with the model
#' and take precedence; the registry serves interactive work and shared
#' helpers. Built-ins `identity` and `scale` (`weather * wscale`) are always
#' available.
#'
#' @param name single character, a valid object-name suffix (letters, digits,
#'   underscore, starting with a letter). The derived weather object is named
#'   `<WEATHER>_<name>`.
#' @param fun `function(weather, ...) -> numeric`: `weather` receives the
#'   stream's `wval` series; `...` receives the non-structural columns of the
#'   selecting link row as named scalars. Must return a numeric vector of the
#'   input's length.
#'
#' @return `fun`, invisibly.
#' @seealso [materialize_weather()]
#' @export
#'
#' @examples
#' register_weather_transform("power_v112",
#'   function(weather, wscale = 1, ...) {
#'     v <- data.frame(speed = c(0, 3, 7, 12, 25, 25.01),
#'                     af = c(0, 0, 0.4, 1, 1, 0))
#'     approx(v$speed, v$af, pmax(wscale * weather, 0),
#'            yleft = 0, yright = 0)$y
#'   })
register_weather_transform <- function(name, fun) {
  if (!check_name(name)) {
    stop("Transform name must be a valid object-name suffix ",
         "(letters, digits, underscore, starting with a letter): ", name)
  }
  if (!is.function(fun)) stop("`fun` must be a function")
  assign(name, fun, envir = .weather_transform_registry)
  invisible(fun)
}

# misc -> registry -> built-ins; loud miss.
.resolve_weather_transform <- function(wobj, tname) {
  tf <- wobj@misc$transform
  if (is.list(tf) && is.function(tf[[tname]])) return(tf[[tname]])
  if (exists(tname, envir = .weather_transform_registry, inherits = FALSE)) {
    return(get(tname, envir = .weather_transform_registry))
  }
  fun <- .builtin_weather_transforms[[tname]]
  if (is.function(fun)) return(fun)
  stop("Unknown weather transform \"", tname, "\" on weather object \"",
       wobj@name, "\". Store it in the object's misc$transform list, ",
       "register_weather_transform(\"", tname, "\", ...), or use a ",
       "built-in (", paste(names(.builtin_weather_transforms),
                           collapse = ", "), ").")
}

#' Materialize one weather transform
#'
#' Applies a named transform to a weather object and returns the DERIVED
#' weather object -- the same clone interpolation creates when a link selects
#' that transform. For inspection and reporting; the input object is not
#' modified.
#'
#' @param weather a `weather` object.
#' @param transform single character, the transform name; resolved
#'   `weather@misc$transform` -> session registry -> built-ins.
#' @param ... arguments forwarded to the transform function (what a link row's
#'   parameter columns would carry).
#'
#' @return a `weather` object named `<WEATHER>_<transform>` whose `wval` (and
#'   `defVal`) carry the transformed series; `misc$transform_source` records
#'   the provenance.
#' @seealso [register_weather_transform()]
#' @export
#'
#' @examples
#' w <- newWeather("W_SPEED", weather = data.frame(
#'   timeslice = c("s1", "s2"), wval = c(4, 12)))
#' w@misc$transform <- list(AF = function(weather, ...) pmin(weather / 10, 1))
#' materialize_weather(w, "AF")@weather
materialize_weather <- function(weather, transform, ...) {
  stopifnot(methods::is(weather, "weather"))
  .materialize_weather_clone(weather, transform, args = list(...))
}

.materialize_weather_clone <- function(wobj, tname, args) {
  if (!check_name(tname)) {
    stop("Weather transform name \"", tname, "\" on \"", wobj@name,
         "\" is not a valid object-name suffix (letters, digits, ",
         "underscore, starting with a letter).")
  }
  fun <- .resolve_weather_transform(wobj, tname)
  vals <- do.call(fun, c(list(wobj@weather$wval), args))
  if (!is.numeric(vals) || length(vals) != nrow(wobj@weather)) {
    stop("Weather transform \"", tname, "\" on \"", wobj@name, "\" must ",
         "return a numeric vector of the series length (",
         nrow(wobj@weather), "), got ", class(vals)[1], " of length ",
         length(vals), ".")
  }
  cl <- wobj
  # single-underscore join, the same convention as the _VIN / _CL variant
  # suffixes; collisions with declared names are checked by the caller
  cl@name <- paste0(wobj@name, "_", tname)
  cl@weather$wval <- as.numeric(vals)
  # the default fills absent slices; it must pass through the same lens
  cl@defVal <- as.numeric(do.call(fun, c(list(wobj@defVal), args)))[1]
  cl@misc$transform <- NULL
  cl@misc$transform_source <- list(weather = wobj@name, transform = tname,
                                   args = args)
  cl
}

# Harvest one process object's weather links: validate, register the pending
# (weather, transform, args) tuples in `state`, repoint the rows. Returns the
# modified object, or NULL when it declares no transform.
.harvest_weather_links <- function(el, state) {
  wt <- el@weather
  if (is.null(wt) || !nrow(wt) || !"transform" %in% names(wt)) return(NULL)
  act <- which(!is.na(wt$transform) & wt$transform != "")
  if (!length(act)) return(NULL)
  structural <- .weather_link_structural[[class(el)[1]]]
  for (i in act) {
    wname <- wt$weather[i]
    tname <- wt$transform[i]
    wobj <- state$wobjs[[wname]]
    if (is.null(wobj)) {
      stop(class(el)[1], " \"", el@name, "\" declares transform \"", tname,
           "\" on unknown weather object \"", wname, "\".")
    }
    args <- as.list(wt[i, setdiff(names(wt), structural), drop = FALSE])
    args <- args[!vapply(args, function(v) is.na(v), logical(1))]
    key <- paste0(wname, "_", tname)
    prior <- state$pending[[key]]
    if (is.null(prior)) {
      if (key %in% state$taken) {
        stop("Materialized weather name \"", key, "\" collides with a ",
             "declared object. Rename the transform or the object.")
      }
      state$pending[[key]] <- list(weather = wname, transform = tname,
                                   args = args)
    } else if (!identical(prior$args, args)) {
      stop("Weather transform \"", tname, "\" on \"", wname, "\" is used ",
           "with differing arguments across links. One name = one series: ",
           "give each parameterization its own transform name.")
    }
    wt$weather[i] <- key
    wt$transform[i] <- NA_character_
  }
  el@weather <- wt
  el
}

# The interpolation stage. Runs on the internal build copy of the model,
# after `expand_variants()` (each variant owns its link rows) and before
# `sets$weather` is collected, so the derived objects join the set like any
# declared weather. Non-destructive: the caller's model is untouched.
materialize_weather_transforms <- function(mod, verbose = FALSE) {
  state <- new.env(parent = emptyenv())
  state$wobjs <- list()
  state$pending <- list()

  state$taken <- character()
  collect <- function(r) {
    for (nm in names(r@data)) {
      el <- r@data[[nm]]
      if (methods::is(el, "repository")) {
        collect(el)
      } else {
        if (.hasSlot(el, "name")) state$taken <- c(state$taken, el@name)
        if (methods::is(el, "weather")) state$wobjs[[el@name]] <- el
      }
    }
  }
  for (r in mod@data) if (methods::is(r, "repository")) collect(r)

  rewrite <- function(r) {
    for (nm in names(r@data)) {
      el <- r@data[[nm]]
      if (methods::is(el, "repository")) {
        r@data[[nm]] <- rewrite(el)
      } else if (class(el)[1] %in% names(.weather_link_structural)) {
        res <- .harvest_weather_links(el, state)
        if (!is.null(res)) r@data[[nm]] <- res
      }
    }
    r
  }
  for (i in seq_along(mod@data)) {
    if (methods::is(mod@data[[i]], "repository")) {
      mod@data[[i]] <- rewrite(mod@data[[i]])
    }
  }

  if (!length(state$pending)) return(mod)
  clones <- .weather_transform_build_clones(state, verbose)
  do.call(add, c(list(mod), unname(clones)))
}

.weather_transform_build_clones <- function(state, verbose) {
  clones <- lapply(state$pending, function(p) {
    .materialize_weather_clone(state$wobjs[[p$weather]], p$transform, p$args)
  })
  if (verbose) {
    message("Materialized ", length(clones), " weather transform(s): ",
            paste(vapply(clones, slot, "", "name"), collapse = ", "))
  }
  clones
}

# Resource tiers. A `weather` object declaring `@cluster` holds one series per
# tier; each tier a process actually references is cloned into an ordinary
# weather object (`WWIN` tier `T3` -> `WWIN_CLT3`) and the link is repointed, so
# everything downstream -- `pWeather`, `mWeatherRegion(At)`, the four templates
# -- sees only plain single-series objects. Same shape as the transform pass
# above, and it runs just before it so the two compose: the cluster picks the
# series, a transform then derives from that.
#
# Readable post-expansion because `.variant_timeslice()` STAMPS each variant's
# cluster into its filtered link rows (R/variants.R) rather than blanking them,
# so `EWIN_CLT3@weather` arrives carrying `cluster = "T3"`.
materialize_weather_clusters <- function(mod, verbose = FALSE,
                                         prefix = .variant_prefix_default()) {
  wobjs <- list()
  taken <- character()
  collect <- function(r) {
    for (nm in names(r@data)) {
      el <- r@data[[nm]]
      if (methods::is(el, "repository")) {
        collect(el)
      } else {
        if (.hasSlot(el, "name")) taken <<- c(taken, el@name)
        if (methods::is(el, "weather")) wobjs[[el@name]] <<- el
      }
    }
  }
  for (r in mod@data) if (methods::is(r, "repository")) collect(r)

  rosters <- lapply(wobjs, function(w) {
    dc <- .declared_clusters(w)
    if (is.null(dc)) {
      # No roster: the labels in `@weather` are not a declaration. Harvesting
      # them would make a misspelled tier a series nobody asked for.
      rows <- as.data.frame(w@weather)
      used <- if (nrow(rows) == 0L || !"cluster" %in% names(rows)) {
        character(0)
      } else {
        as.character(rows$cluster)
      }
      .assert_roster_declared(w, "cluster", used, list(weather = used))
      return(character(0))
    }
    # `unique()`: a REGION-SCOPED roster carries one row per (cluster, region),
    # so the declared labels repeat. Without it a tier would be cloned once per
    # region it exists in and the error messages would list it that many times.
    unique(as.character(dc$cluster))
  })
  if (!any(vapply(rosters, length, integer(1)) > 0L)) return(mod)

  # EVERY declared tier is materialized, not only the referenced ones: the
  # bundle itself is dropped below (it is not a series -- its rows would
  # collapse into duplicate (weather, region, year, timeslice) keys), so a tier
  # left unmaterialized would silently take its data with it.
  clustered <- names(rosters)[vapply(rosters, length, integer(1)) > 0L]
  pending <- list()                   # name -> list(weather, cluster)
  for (wn in clustered) {
    for (clu in rosters[[wn]]) {
      nm <- .variant_name(wn, NA, clu, prefix)
      if (nm %in% taken) {
        stop('Weather "', wn, '" cluster "', clu, '" would be materialized as "',
             nm, '", which the model already declares. Rename the cluster or ',
             'the existing object.', call. = FALSE)
      }
      pending[[nm]] <- list(weather = wn, cluster = clu)
    }
  }

  rewrite_el <- function(el) {
    wt <- as.data.frame(el@weather)
    if (nrow(wt) == 0L || !"weather" %in% names(wt)) return(NULL)
    clu <- if ("cluster" %in% names(wt)) as.character(wt$cluster) else
      rep(NA_character_, nrow(wt))
    changed <- FALSE
    for (i in seq_len(nrow(wt))) {
      wname <- wt$weather[i]
      if (is.na(wname) || !nzchar(wname)) next
      roster <- rosters[[wname]] %||% character(0)
      if (length(roster) == 0L) next            # unclustered: leave alone
      new <- .resolve_cluster_ref(wname, clu[i], roster, "weather",
                                  el@name, class(el)[1], prefix)
      if (identical(new, wname)) next
      wt$weather[i] <- new
      changed <- TRUE
    }
    if (!changed) return(NULL)
    el@weather <- wt
    el
  }

  # One walk: repoint the links, and drop the bundles they pointed at.
  rewrite <- function(r) {
    drop <- character()
    for (nm in names(r@data)) {
      el <- r@data[[nm]]
      if (methods::is(el, "repository")) {
        r@data[[nm]] <- rewrite(el)
      } else if (class(el)[1] %in% names(.weather_link_structural)) {
        res <- rewrite_el(el)
        if (!is.null(res)) r@data[[nm]] <- res
      } else if (methods::is(el, "weather") && el@name %in% clustered) {
        drop <- c(drop, nm)
      }
    }
    for (nm in drop) r@data[[nm]] <- NULL
    r
  }
  for (i in seq_along(mod@data)) {
    if (methods::is(mod@data[[i]], "repository")) {
      mod@data[[i]] <- rewrite(mod@data[[i]])
    }
  }

  if (!length(pending)) return(mod)
  clones <- lapply(names(pending), function(nm) {
    p <- pending[[nm]]
    .weather_cluster_clone(wobjs[[p$weather]], p$cluster, nm)
  })
  if (verbose) {
    message("Materialized ", length(clones), " weather cluster(s): ",
            paste(names(pending), collapse = ", "))
  }
  do.call(add, c(list(mod), unname(clones)))
}

# One tier as an ordinary weather object. Rows with NO cluster are shared by
# every tier (`NA` = "every tier", as the slot documents), so a tier is its own
# rows plus the shared ones.
#' @noRd
.weather_cluster_clone <- function(w, cluster, name) {
  wt <- as.data.frame(w@weather)
  keep <- if ("cluster" %in% names(wt)) {
    cv <- as.character(wt$cluster)
    is.na(cv) | !nzchar(cv) | cv == cluster
  } else {
    rep(TRUE, nrow(wt))
  }
  wt <- wt[keep, setdiff(names(wt), "cluster"), drop = FALSE]
  rownames(wt) <- NULL
  if (nrow(wt) == 0L) {
    stop('Weather "', w@name, '" declares cluster "', cluster,
         '" but carries no rows for it.', call. = FALSE)
  }
  out <- w
  out@name <- name
  out@weather <- wt
  out@cluster <- .cluster_table(w)[0, , drop = FALSE]
  out@desc <- if (length(w@desc) && nzchar(w@desc[1]))
    paste0(w@desc[1], " [", cluster, "]") else w@desc
  out
}

# Guard used by aggregate_model_regions(): any process link naming a transform
# means the model carries streams meant for a nonlinear lens.
.assert_no_weather_transforms <- function(mod) {
  offender <- NULL
  scan <- function(r) {
    for (nm in names(r@data)) {
      el <- r@data[[nm]]
      if (methods::is(el, "repository")) {
        scan(el)
      } else if (class(el)[1] %in% names(.weather_link_structural)) {
        wt <- el@weather
        if (!is.null(wt) && nrow(wt) && "transform" %in% names(wt) &&
            any(!is.na(wt$transform) & wt$transform != "")) {
          offender <<- c(offender, el@name)
        }
      }
    }
  }
  for (r in mod@data) if (methods::is(r, "repository")) scan(r)
  if (!is.null(offender)) {
    stop("The model declares weather transforms (",
         paste(unique(offender), collapse = ", "), "): a regional mean of ",
         "the stream does not commute with a nonlinear transform. ",
         "Interpolate/materialize the transforms first, or aggregate the ",
         "derived model.", call. = FALSE)
  }
  invisible(TRUE)
}
