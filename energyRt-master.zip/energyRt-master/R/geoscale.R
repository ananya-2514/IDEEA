# geoscale ####################################################################
# Attaching spatial information to a model's regions.
#
# `config@region` stays authoritative: it is the set of region labels the model
# is built on, and it is always the FINEST level. A geoscale adds structure
# above those labels -- how they nest into coarser levels, what they weigh, and
# where they are on a map.
#
# Two things use it, and they are independent:
#
#  * PRESENTATION (plot_map.R, plot.R, reporting, subsetting). Needs nothing
#    from the optimisation model and never did.
#    NOTE: this is the PRESENTATION half only -- see MODEL STRUCTURE below,
#    which is emphatically not inert once a commodity names a `@geoframe`.
#
#  * MODEL STRUCTURE. `sets$region` becomes the union of every level, so a
#    coarse region such as a nation is a member alongside the states, and a
#    commodity may declare `@geoframe` to be balanced there instead
#    (`mCommRegion`, `mRegionFamily` -- see map_region.R). Attaching a geoscale
#    alone changes nothing observable: the extra members are inert until some
#    commodity names a coarser level, which is what Verification 2 pins.
#
# The hierarchy is pruned to the model: a geoscale covering more ground than
# the model uses (a world map for a two-region model) is normal and supported,
# and only the ancestors of declared regions enter `sets$region`.
#
# `geoscales` is an optional (Suggests) dependency, so every entry point that
# needs the package guards with `check_package("geoscales")`, and the type test
# `is_geoscale()` works whether or not it is installed.

#' @include class-model.R class-scenario.R class-settings.R
NULL

#' Attach or read a model's geoscale
#'
#' A geoscale describes the model's regions -- their nesting into coarser
#' levels, their weights, and optionally their geometry. It is built with the
#' [geoscales](https://github.com/optimal2050/geoscales) package.
#'
#' Attaching one is inert by itself: it widens the model's region set with the
#' coarser codes and enables level-aware plotting, reporting and subsetting
#' (`getData(geoframe = )`), but the extra members stay unused and the model
#' solves exactly as before. It is also the prerequisite for
#' `newCommodity(geoframe = )`, which balances a commodity at a coarser level
#' and does change the optimisation model -- see
#' `vignette("space-resolution")`. The geoframes must NEST: adjacent levels
#' have to refine one another, or a region would be aggregated into two
#' parents.
#'
#' `setGeoscale()` stores it on a `config` (and therefore on a `settings`, which
#' inherits from `config`) or on a `model`. `getGeoscale()` reads it back;
#' for a `scenario` it reads `@settings` first and falls back to the model's
#' `@config`, matching how `@calendar` is resolved.
#'
#' @param obj A `config`, `settings`, `model` or `scenario`.
#' @param geoscale A `geoscales::GeoScale`, or `NULL` to clear it.
#' @param ... Unused.
#'
#' @return `setGeoscale()` returns the modified object; `getGeoscale()` returns
#'   a `geoscales::GeoScale` or `NULL`.
#'
#' @examples
#' \dontrun{
#' gs <- geoscales::geoscale_from_leaftable(
#'   data.frame(zone = c("N", "N", "S"), region = c("R1", "R2", "R3")),
#'   geoframes = c("zone", "region")
#' )
#' mod <- newModel("demo", region = c("R1", "R2", "R3"), geoscale = gs)
#' getGeoscale(mod)
#' }
#'
#' @family geoscale
#' @name setGeoscale
#' @aliases setGeoscale getGeoscale getCalendar setCalendar
NULL

#' @rdname setGeoscale
#' @export
setMethod("setGeoscale", signature(obj = "model"), function(obj, geoscale,
                                                            ...) {
  obj@config <- setGeoscale(obj@config, geoscale)
  obj
})

#' @rdname setGeoscale
#' @export
setMethod("getGeoscale", signature(obj = "model"), function(obj, ...) {
  getGeoscale(obj@config)
})

#' @rdname setGeoscale
#' @export
setMethod("setGeoscale", signature(obj = "scenario"), function(obj, geoscale,
                                                               ...) {
  obj@settings <- setGeoscale(obj@settings, geoscale)
  obj
})

#' @rdname setGeoscale
#' @export
setMethod("getGeoscale", signature(obj = "scenario"), function(obj, ...) {
  # Settings is the read path for everything model-wide (see `@calendar`), but
  # a scenario built before the slot existed, or one never interpolated, may
  # only carry it on the model.
  gs <- getGeoscale(obj@settings)
  if (is.null(gs)) gs <- getGeoscale(obj@model)
  gs
})

# `getCalendar` was declared as a generic in generics.R but never given a
# method, so `getCalendar(mod)` failed. Added here alongside its spatial twin.

#' @rdname setGeoscale
#' @export
setMethod("getCalendar", signature(obj = "config"), function(obj) obj@calendar)

#' @rdname setGeoscale
#' @export
setMethod("getCalendar", signature(obj = "model"), function(obj) {
  obj@config@calendar
})

#' @rdname setGeoscale
#' @export
setMethod("getCalendar", signature(obj = "scenario"), function(obj) {
  obj@settings@calendar
})

# Diagnostics -----------------------------------------------------------------

#' Check a geoscale against the model's declared regions
#'
#' Warns when the two disagree. This is deliberately a warning, not an error:
#' `config@region` remains authoritative, and a geoscale covering more ground
#' than the model uses (a world map for a two-country model) is normal and
#' useful.
#'
#' @param geoscale A `geoscales::GeoScale`.
#' @param region Character vector of declared model regions.
#' @param level Level of the geoscale to match against. Defaults to the finest.
#'
#' @return Invisibly, the regions that are declared but absent from `geoscale`.
#'
#' @family geoscale
#' @export
#' @examples
#' # returns the declared regions the geoscale cannot place, and warns about them
#' gs <- topia$geoscales$squares
#' check_geoscale_regions(gs, c("W1", "W2", "C1"))        # all placed: character(0)
#' suppressWarnings(check_geoscale_regions(gs, c("W1", "NOWHERE")))
check_geoscale_regions <- function(geoscale, region, level = NULL) {
  if (is.null(geoscale)) return(invisible(character()))
  check_package("geoscales")
  level <- level %||% .geo_default_level(geoscale)
  known <- geoscales::geoscale_regions(geoscale, level)

  region <- as.character(region)
  region <- region[!is.na(region) & nzchar(region)]
  missing <- setdiff(region, known)
  if (length(missing) > 0) {
    warning(
      "The geoscale has no code at level '", level, "' for ",
      length(missing), " declared region(s): ",
      paste(utils::head(sort(missing), 5), collapse = ", "),
      if (length(missing) > 5) ", ..." else "",
      ". Maps and region-level reporting will omit them.",
      call. = FALSE
    )
  }
  invisible(missing)
}

# The level whose codes are the model's regions: the finest, i.e. the atom
# layer. Everything coarser is a grouping of it.
#
# Read through the geoscales API rather than `S7::prop()`: reaching into the
# object's properties would put S7 in energyRt's Imports to read one field, and
# leak geoscales' class system across the package boundary. Everything crosses
# as plain data or through exported accessors.
#' @noRd
.geo_default_level <- function(geoscale) {
  check_package("geoscales")
  geoscales::geoscale_geoframes(geoscale, finest = TRUE)
}

# Region hierarchy -------------------------------------------------------------

# The part of a geoscale that sits above the model's own regions.
#
# Declared regions are the atoms (the finest level). Walking up level by level
# and keeping only parents that still have a kept child prunes a geoscale that
# covers more ground than the model -- a world map on a two-region model must
# not put 200 countries into `sets$region`.
#
# Returns NULL when there is no geoscale or no structure above the atoms, which
# is the signal to leave everything exactly as it was.
#
#' @noRd
.geo_hierarchy <- function(geoscale, region) {
  if (is.null(geoscale)) return(NULL)
  check_package("geoscales")

  levels <- geoscales::geoscale_geoframes(geoscale)
  if (length(levels) < 2L) return(NULL)
  finest <- levels[length(levels)]

  declared <- unique(as.character(region))
  declared <- declared[!is.na(declared) & nzchar(declared)]
  if (length(declared) == 0L) return(NULL)

  fam <- as.data.frame(geoscales::geoscale_family(geoscale))

  # geoscales renamed the family table's level columns to `*_geoframe` (the
  # lattice rename). Reading the OLD names silently yields `logical(0)` from the
  # filter below, so every geoscale collapses to a one-level hierarchy and the
  # whole multi-level region feature goes dark without an error. Accept either
  # spelling, and say so loudly if neither is present rather than degrading.
  .fam_col <- function(which) {
    for (nm in paste0(which, c("_geoframe", "_level"))) {
      if (nm %in% names(fam)) return(fam[[nm]])
    }
    stop("geoscale_family() has neither `", which, "_geoframe` nor `", which,
         "_level`; energyRt cannot read the region hierarchy. Columns: ",
         paste(names(fam), collapse = ", "), call. = FALSE)
  }
  fam_parent_level <- .fam_col("parent")
  fam_child_level  <- .fam_col("child")

  # level -> the codes of that level that survive pruning.
  keep <- list()
  keep[[finest]] <- intersect(geoscales::geoscale_regions(geoscale, finest),
                              declared)
  pairs <- list()
  selfish <- character()
  for (i in rev(seq_len(length(levels) - 1L))) {
    pl <- levels[i]
    cl <- levels[i + 1L]
    f <- fam[fam_parent_level == pl & fam_child_level == cl &
               fam$child %in% keep[[cl]], , drop = FALSE]
    # `keep` is taken BEFORE self-pairs are dropped: a code repeated across two
    # geoframes is still a legitimate child for the level above it.
    keep[[pl]] <- unique(f$parent)
    # A code repeated across adjacent geoframes parents ITSELF (`LU` under `LU`,
    # the shape Eurostat pads away as LU -> LU0 -> LU00). The pair needs no
    # roll-up -- the coarse cell IS the atom -- and emitting it would make
    # eqOutTot read `vOutTot[c,r] = <real terms> + vOutTot[c,r]`, which cancels
    # the cell out of its own equation: the real terms are forced to zero and
    # the cell is left free and costless. Silent, feasible, and wrong.
    self <- as.character(f$parent) == as.character(f$child)
    if (any(self)) {
      selfish <- c(selfish, unique(as.character(f$parent)[self]))
      f <- f[!self, , drop = FALSE]
    }
    if (nrow(f) > 0L) {
      pairs[[length(pairs) + 1L]] <-
        data.frame(region = as.character(f$parent),
                   regionp = as.character(f$child),
                   stringsAsFactors = FALSE)
    }
  }
  if (length(selfish)) {
    selfish <- unique(selfish)
    message("Geoscale: ", length(selfish), " region(s) carry the same code at ",
            "two adjacent geoframes (", paste(utils::head(selfish, 5),
                                              collapse = ", "),
            if (length(selfish) > 5) ", ..." else "",
            "). No aggregation is needed for them; the self-pairs are dropped.")
  }

  # Every child must have exactly ONE parent. More than one means two adjacent
  # geoframes CROSS-CUT -- parallel groupings of the same atoms, which geoscales
  # permits by design but this roll-up cannot represent: the up-aggregation term
  # in eqOutTot/eqInpTot is a plain unweighted sum, so a child with two parents
  # is added into both. Where a commodity is balanced at or above the cut that
  # silently widens the balance into a copperplate; below it, the coarse totals
  # overlap and no longer sum to the system total. Refuse rather than solve a
  # different problem.
  .fam_all <- if (length(pairs)) do.call(rbind, pairs) else NULL
  if (!is.null(.fam_all) && nrow(.fam_all) > 0L) {
    np <- tapply(.fam_all$region, .fam_all$regionp,
                 function(z) length(unique(z)))
    bad <- names(np)[np > 1L]
    if (length(bad)) {
      shown <- utils::head(bad, 5)
      det <- vapply(shown, function(b) paste0(
        b, " <- ", paste(sort(unique(.fam_all$region[.fam_all$regionp == b])),
                         collapse = " + ")), character(1))
      stop("The geoscale's `geoframes` do not nest: ", length(bad),
           " region(s) have more than one parent.\n   ",
           paste(det, collapse = "\n   "),
           if (length(bad) > 5) "\n   ..." else "",
           "\nAdjacent geoframes must refine one another. Parallel groupings ",
           "of the same regions (e.g. trade blocs alongside national borders) ",
           "are not supported in one chain: keep a single hierarchy in ",
           "`geoframes`. Diagnose with `geoscales::geoscale_nests()`.",
           call. = FALSE)
    }
  }

  coarser <- levels[-length(levels)]
  extra <- unlist(keep[coarser], use.names = FALSE)
  extra <- setdiff(unique(extra), declared)
  if (length(extra) == 0L) return(NULL)

  # Declared regions keep their original order and stay at the head of the set,
  # so adding a hierarchy appends members rather than reshuffling existing ones.
  family <- if (length(pairs)) do.call(rbind, pairs) else
    data.frame(region = character(), regionp = character(),
               stringsAsFactors = FALSE)

  list(
    levels  = levels,
    finest  = finest,
    region  = c(declared, extra),
    family  = unique(family),
    members = keep
  )
}

# The regions a process, supply or cost can actually occupy: the model's
# DECLARED regions, i.e. the finest level.
#
# `modInp@sets$region` is the union of every level once a geoscale is attached,
# so any site that means "somewhere a thing can be" must ask for this instead --
# otherwise supplies, spans and cost grids silently broadcast onto nations and
# zones. `settings@region` is authoritative and is never widened.
#' @noRd
.model_regions <- function(scen) {
  r <- as.character(scen@settings@region)
  r <- r[!is.na(r) & nzchar(r)]
  if (length(r) > 0L) r else as.character(scen@modInp@sets[["region"]])
}

# Every region name the model recognises: the declared ones plus the geoscale's
# coarser levels.
#
# The counterpart of `.model_regions()`, and the distinction matters. Use THIS
# for VALIDATION ("is this a region at all?"), because a national demand for a
# nationally-balanced commodity legitimately names the nation. Use
# `.model_regions()` for BROADCAST ("where does an unqualified thing exist?"),
# which is always the finest level.
#' @noRd
.known_regions <- function(scen) {
  r <- .model_regions(scen)
  h <- .geo_hierarchy(tryCatch(getGeoscale(scen@settings),
                               error = function(e) NULL), r)
  if (is.null(h)) r else h$region
}

# Regions at a named level, pruned to the model. `level = NULL` (a commodity
# with no `@geoframe`) means the finest level, i.e. today's flat behaviour.
#' @noRd
.geo_level_regions <- function(hier, level = NULL) {
  if (is.null(hier)) return(NULL)
  if (is.null(level) || length(level) == 0L || is.na(level[1]) ||
      !nzchar(level[1])) {
    level <- hier$finest
  }
  level <- level[1]
  if (!level %in% hier$levels) {
    stop("Unknown geo-level '", level, "'. The model's geoscale has: ",
         paste(hier$levels, collapse = ", "), ".", call. = FALSE)
  }
  hier$members[[level]]
}

# The geoscale level an object DECLARES its regions at, or NA when it declares
# none. `@geoframe` is optional on every region-carrying class: left unset, the
# level is DERIVED from the region codes themselves (`.flow_levels()` takes the
# finest level any of them belongs to), which is what every model written
# before the slot existed relies on.
#
# Distinct from `commodity@geoframe` (the level a commodity is BALANCED at) and
# `summand@geoframe` (a restriction of the summed region dimension), which read
# their own slot directly.
#' @noRd
.obj_geoframe <- function(obj) {
  if (!isS4(obj) || !methods::.hasSlot(obj, "geoframe")) {
    return(NA_character_)
  }
  g <- as.character(methods::slot(obj, "geoframe"))
  g <- g[!is.na(g) & nzchar(g)]
  if (length(g) == 0) NA_character_ else g[1]
}

# The regions a declared level covers, or `default` when no level is declared.
#
# This is the ONE default `@geoframe` sets: an object that names no regions of
# its own spans its LEVEL instead of every region in the model. Everything else
# the slot does is a check. For a weather series that is the difference between
# one stored row and one per region of every level.
#' @noRd
.obj_level_members <- function(obj, hier, default) {
  lv <- .obj_geoframe(obj)
  if (is.na(lv) || is.null(hier)) {
    return(default)
  }
  .geo_level_regions(hier, lv)
}

# Resolve a geoscale from an explicit argument, else from the object.
#' @noRd
.resolve_geoscale <- function(x, geoscale = NULL, required = TRUE) {
  gs <- geoscale
  if (is.null(gs) && !is.null(x)) {
    gs <- tryCatch(getGeoscale(x), error = function(e) NULL)
  }
  if (is.null(gs) && required) {
    stop("No geoscale found. Attach one with `setGeoscale()`, or pass ",
         "`geoscale = `.", call. = FALSE)
  }
  if (!is.null(gs)) {
    if (!is_geoscale(gs)) {
      stop("`geoscale` must be a `geoscales::GeoScale` object.", call. = FALSE)
    }
    check_package("geoscales")
  }
  gs
}
