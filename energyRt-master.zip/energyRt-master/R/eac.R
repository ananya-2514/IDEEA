# =========================================================================== #
# eac.R  —  Equivalent Annual Cost (EAC) of investment.
#
# pXEac(key, region, year) = pXInvcost annuitised by the capital-recovery factor
# of the cost of capital over the cost-recovery period:
#   eac = invcost / n                          (rate 0, finite n)
#   eac = invcost * d(1+d)^n / ((1+d)^n - 1)   (rate d>0, finite n)
#   eac = invcost * d                          (rate d>0, infinite n)
#
# The rate is the WACC — `@invcost$wacc` for this process if given, else the
# model-wide `pWacc`. The social discount rate never appears here; it discounts
# the cost stream in the objective (pDiscountFactor) and nothing else.
#
# The period `n` is `@invcost$payback` if given, else `@vintage$olife`. Payback
# is the COST-RECOVERY life: the same value also narrows the eqXEac charging
# window in the solver, so the annuity is paid over `payback` years and not one
# year more, while the technical life still governs when capacity operates.
#
# A user-supplied `@invcost$eac` bypasses all of it: the slot loop seeds pXEac
# from that column (modInp.yml binds `colName: eac`), and the rows it supplies
# survive the computed values below.
#
# Runs after interpolate_parameters (reads the interpolated pXInvcost / pWacc /
# pXOlife / pXPayback) and before the value recipe (mTradeEac reads pTradeEac's
# value domain). At this stage tech/storage cost params are still region-FOLDED
# (region = NA wildcard) while pWacc is region-explicit, so joins must be
# wildcard-aware.
# =========================================================================== #

# Wildcard-aware left join: join `df` to `src` (which carries `val_cols`) on
# `keys`, but a key that is fully-NA on one side (a folded wildcard) is not used
# to match; instead the side that holds explicit values supplies that column.
.eac_merge <- function(df, src, val_cols, keys) {
  src <- as.data.frame(src)
  has <- function(d, k) k %in% names(d) && !all(is.na(d[[k]]))
  use <- keys[vapply(keys, function(k) has(df, k) && has(src, k), logical(1))]
  src_keep <- c(use, val_cols)
  for (k in setdiff(keys, use)) {
    # src holds explicit values for a key df cannot match on -> let src supply it.
    if (has(src, k) && (!k %in% names(df) || all(is.na(df[[k]])))) {
      src_keep <- c(src_keep, k)
      if (k %in% names(df)) df <- df[, setdiff(names(df), k), drop = FALSE]
    }
  }
  src <- src[, unique(src_keep), drop = FALSE]
  # A key can be PARTLY wild: one process's cost explicit at a region, another's
  # folded to NA ("every region"). An exact join on that key silently drops the
  # wildcard rows -- measured: a technology with a region-less invcost beside
  # one at a coarse region got no EAC at all, i.e. free capital. Join each row
  # pattern on the keys it actually holds, most specific first, so an explicit
  # row wins and a wildcard fills what is left.
  wild <- if (length(use)) vapply(use, function(k) any(is.na(src[[k]])), logical(1)) else logical(0)
  if (!any(wild)) {
    return(dplyr::left_join(df, src, by = use))
  }
  pat <- do.call(paste, c(lapply(use, function(k) ifelse(is.na(src[[k]]), "0", "1")), sep = ""))
  pats <- unique(pat)
  pats <- pats[order(-nchar(gsub("0", "", pats)))]          # most explicit keys first
  df$.eac_row <- seq_len(nrow(df))
  done <- integer(0)
  parts <- list()
  for (p in pats) {
    ek <- use[strsplit(p, "")[[1]] == "1"]
    sp <- src[pat == p, setdiff(names(src), setdiff(use, ek)), drop = FALSE]
    rest <- df[!df$.eac_row %in% done, , drop = FALSE]
    if (!nrow(rest)) break
    j <- if (length(ek)) dplyr::inner_join(rest, sp, by = ek) else
      dplyr::cross_join(rest, sp)
    if (nrow(j)) {
      parts[[length(parts) + 1L]] <- j
      done <- c(done, unique(j$.eac_row))
    }
  }
  rest <- df[!df$.eac_row %in% done, , drop = FALSE]
  if (nrow(rest)) {
    for (v in setdiff(names(src), names(rest))) rest[[v]] <- NA
    parts[[length(parts) + 1L]] <- rest
  }
  out <- dplyr::bind_rows(parts)
  out <- out[order(out$.eac_row), setdiff(names(out), ".eac_row"), drop = FALSE]
  rownames(out) <- NULL
  out
}

# Join one parameter's values onto `df` under `nm`, or fill NA if it is absent.
.eac_join <- function(scen, df, par, nm, keys) {
  P <- scen@modInp@parameters
  src <- if (is.null(P[[par]])) NULL else as.data.frame(get_data_slot(P[[par]]))
  if (is.null(src) || nrow(src) == 0) {
    df[[nm]] <- NA_real_
    return(df)
  }
  names(src)[names(src) == "value"] <- nm
  .eac_merge(df, src, nm, keys)
}

# Capital-recovery factor: the annual payment that repays 1 unit of capital over
# `n` years at rate `d`. Vectorised, and safe at d == 0 and n == Inf.
.crf <- function(d, n) {
  out <- 1 / n
  fl <- d != 0 & is.finite(n)
  out[fl] <- d[fl] * (1 + d[fl])^n[fl] / ((1 + d[fl])^n[fl] - 1)
  fl <- d != 0 & is.infinite(n)
  out[fl] <- d[fl]
  out
}

# `payback` must be a positive number of years no longer than the technical
# life. Beyond `olife` the charge would fall outside the eqXEac window map (a
# "span" window that olife does not extend), so it would be silently truncated
# rather than paid.
.check_payback <- function(df, key) {
  bad <- !is.na(df$payback) & df$payback <= 0
  if (any(bad)) {
    stop("`payback` must be positive (", key, " ",
         paste(unique(df[[key]][bad]), collapse = ", "), ").")
  }
  bad <- !is.na(df$payback) & is.finite(df$olife) & df$payback > df$olife
  if (any(bad)) {
    stop("`payback` cannot exceed `olife` (", key, " ",
         paste(unique(df[[key]][bad]), collapse = ", "),
         "): the annuity would outlive the capacity paying it.\n",
         "  `payback` is the cost-recovery period; leave it unset to recover ",
         "the investment over the full operational life.")
  }
  invisible(NULL)
}

# A perpetual annuity at a zero rate is undefined, not zero. `.crf()` computes
# it as 1/Inf, so an `invcost` with no rate and no life would silently become
# free capital -- the charge simply leaves the objective. Checked after the
# user-supplied EAC is coalesced in, so a row that carries its own `eac` (the
# annuitised-upstream case) is not refused for a figure it never uses.
.check_perpetual_annuity <- function(df, key) {
  bad <- df$rate == 0 & !is.finite(df$life) &
    !is.na(df$invcost) & df$invcost != 0 & is.na(df$ueac)
  if (!any(bad)) return(invisible(NULL))
  stop("zero discount rate and no operational life leave the annualised ",
       "capital cost undefined, and it would be charged as 0 (", key, " ",
       paste(unique(df[[key]][bad]), collapse = ", "), ").\n",
       "  Set `@vintage$olife` (technical life), `@invcost$payback` ",
       "(cost-recovery period), or a non-zero `@invcost$wacc` / model ",
       "discount rate.", call. = FALSE)
}

# Compute one family's EAC param from its invcost / wacc / olife / payback.
# `wacc_par` / `payback_par` may be character VECTORS tried in order (a
# storage part passes c(part-specific, storage-wide)): the first non-NA value
# wins, then the model-wide `pWacc` (rate) or `olife` (life).
.eac_one <- function(scen, key, inv_par, olife_par, new_par, eac_par,
                     wacc_par, payback_par) {
  P <- scen@modInp@parameters
  if (is.null(P[[eac_par]]) || is.null(P[[inv_par]])) return(scen)
  inv <- as.data.frame(get_data_slot(P[[inv_par]]))
  if (is.null(inv) || nrow(inv) == 0) return(scen)
  names(inv)[names(inv) == "value"] <- "invcost"

  # Domain = the investment-window map (scope-restricted (key, region, year));
  # invcost is broadcast onto it (it is region-folded at this stage). Falls back
  # to the raw invcost domain when the New map is unavailable.
  new <- if (is.null(P[[new_par]])) NULL else
    as.data.frame(get_data_slot(P[[new_par]]))
  if (!is.null(new) && nrow(new) > 0) {
    df <- .eac_merge(new, inv, "invcost", c(key, "region", "year"))
    df <- df[!is.na(df$invcost), , drop = FALSE]
  } else {
    df <- inv
  }
  if (nrow(df) == 0) return(scen)

  # A cost with no region means "each place this process touches bears this
  # rate" -- which is what lets a sampled sub-model stay consistent with the
  # full one: declare 1/3 on a three-node corridor, sample two nodes, and the
  # charge follows the endpoints that survive.
  #
  # A technology's window carries its regions, so the merge above already
  # landed them. A TRADE's window is `(trade, year)` with no region at all, so
  # an unregioned rate arrives here with nothing to carry it, and the dense
  # `pTradeEac{trade, region, year}` would then materialise one row per region
  # OF THE MODEL -- six charges on a six-region model for a two-ended corridor,
  # growing with the model rather than with the route. Expand over the
  # process's own regions instead: for a trade those are its route endpoints.
  if (!"region" %in% names(df) || all(is.na(df$region))) {
    preg <- tryCatch(get_process_region(scen, return_list = TRUE),
                     error = function(e) NULL)
    ends <- if (is.null(preg)) NULL else
      do.call(rbind, lapply(unique(as.character(df[[key]])), function(k) {
        rg <- preg[[k]]
        rg <- rg[!is.na(rg) & nzchar(rg)]
        if (!length(rg)) return(NULL)
        data.frame(.proc = k, region = as.character(rg),
                   stringsAsFactors = FALSE)
      }))
    if (!is.null(ends) && nrow(ends) > 0) {
      names(ends)[1] <- key
      df <- df[, setdiff(names(df), "region"), drop = FALSE]
      df <- dplyr::inner_join(df, ends, by = key)
    }
  }
  if (nrow(df) == 0) return(scen)

  # Rate: process-specific cost of capital (first supplied of the given
  # parameters, in order), else the model-wide one. NA means "not supplied" --
  # an explicit 0 is a legitimate zero-interest rate and is kept (hence
  # `dropIfEmpty: false` on both parameters in modInp.yml).
  wacc_cols <- paste0("pwacc", seq_along(wacc_par))
  for (i in seq_along(wacc_par)) {
    df <- .eac_join(scen, df, wacc_par[i], wacc_cols[i], c(key, "region", "year"))
  }
  df <- .eac_join(scen, df, "pWacc", "mwacc", c("region", "year"))
  # A process at a coarse geoscale cell whose children declare different rates,
  # with no rate declared for the cell itself and none of its own, has no
  # defensible rate: refuse rather than annuitise at 0.
  atoms <- as.character(scen@settings@region)
  no_rate <- is.na(df$mwacc) & !is.na(df$region) & !(as.character(df$region) %in% atoms)
  for (wc in wacc_cols) no_rate <- no_rate & is.na(df[[wc]])
  if (any(no_rate)) {
    bad <- unique(df[no_rate, c(key, "region"), drop = FALSE])
    stop("No investment rate for ", paste(sprintf("'%s' at '%s'", bad[[key]], bad$region),
                                          collapse = ", "),
         ": the coarse region declares no `wacc` and its child regions do not ",
         "share one.
  Declare a rate for the coarse region in `discount` ",
         "(a row with `region` = it), give the process its own `wacc` in ",
         "`@invcost`, or give the child regions a common rate.", call. = FALSE)
  }
  df$rate <- dplyr::coalesce(!!!df[c(wacc_cols, "mwacc")], 0)

  # Period: cost-recovery life if given (first supplied, in order), else
  # operational life (absent -> Inf, i.e. a perpetual annuity).
  df <- .eac_join(scen, df, olife_par, "olife", c(key, "region"))
  pb_cols <- paste0("payback", seq_along(payback_par))
  for (i in seq_along(payback_par)) {
    df <- .eac_join(scen, df, payback_par[i], pb_cols[i], c(key, "region", "year"))
  }
  df$payback <- dplyr::coalesce(!!!df[pb_cols])
  df$payback[!is.na(df$payback) & df$payback == 0] <- NA_real_
  .check_payback(df, key)
  df$olife[is.na(df$olife)] <- Inf
  df$life <- dplyr::coalesce(df$payback, df$olife)

  df$eac <- df$invcost * .crf(df$rate, df$life)

  # A user-supplied EAC wins, row for row. pXEac is seeded from `@invcost$eac`
  # by the slot loop, so anything already in it is user input. Joined the same
  # wildcard-aware way as everything else: the seed is region-FOLDED at this
  # stage while `df` is region-explicit, so an exact join would match nothing.
  df <- .eac_join(scen, df, eac_par, "ueac", c(key, "region", "year"))
  .check_perpetual_annuity(df, key)
  df$eac <- dplyr::coalesce(df$ueac, df$eac)

  dims <- P[[eac_par]]@dimSets
  out <- unique(df[, c(dims, "eac"), drop = FALSE])
  names(out)[names(out) == "eac"] <- "value"

  # Keep a supplied `eac` for processes that have NO invcost.
  #
  # `df` was filtered to invcost-bearing rows above, so `out` covers only those
  # processes. Writing it back wholesale ERASED every process whose capital cost
  # came from `@invcost$eac` alone -- the charge simply left the objective, with
  # no warning, and the capacity became free. The early return at the top of this
  # function is what hid it: when NO process in the class has an invcost we never
  # reach here, so it only bit MIXED models (some annuitised, some overnight),
  # which is the ordinary case for a converted model.
  #
  # Matched on the process key alone, not the full dims: at this stage the seed
  # is region-FOLDED while `out` is region-explicit (same reason the `ueac` join
  # above goes through .eac_merge), so a full-key anti-join would match nothing
  # and duplicate every row. Within a process that supplies both, the `ueac`
  # coalesce above already gives the supplied value precedence row by row.
  seed <- as.data.frame(get_data_slot(P[[eac_par]]))
  if (!is.null(seed) && nrow(seed) > 0 && key %in% names(seed)) {
    keep <- seed[!seed[[key]] %in% unique(df[[key]]), , drop = FALSE]
    if (nrow(keep) > 0) {
      for (cl in setdiff(names(out), names(keep))) keep[[cl]] <- NA
      out <- rbind(out, keep[, names(out), drop = FALSE])
    }
  }

  scen@modInp@parameters[[eac_par]] <- .fold_write_back(P[[eac_par]], out)
  scen
}

# Warn when a payback period cannot be represented on the milestone grid. The
# eqXEac window admits a milestone whole or not at all, so a payback that does
# not land on a period boundary is charged over the enclosing whole periods --
# e.g. 10 years on a 1 + 10 + 10 ... grid is charged over 11. Silent otherwise it
# would look like an exact cost recovery when it is not.
#
# Only vintages whose full window fits inside the horizon are checked; a late
# vintage always has its window truncated by the end of the horizon, which is
# inherent (olife behaves the same way) and not a grid mismatch.
.check_payback_grid <- function(scen) {
  yrs <- sort(as.integer(scen@modInp@sets$year))
  if (length(yrs) < 2) return(invisible(NULL))
  plen <- tryCatch(
    as.data.frame(get_data_slot(scen@modInp@parameters[["pPeriodLen"]])),
    error = function(e) NULL)
  if (is.null(plen) || nrow(plen) == 0) return(invisible(NULL))
  len <- plen$value[match(yrs, as.integer(plen$year))]
  len[is.na(len)] <- 1
  ord <- yrs - min(yrs) + 1L
  span <- sum(len)

  for (pn in c("pTechPayback", "pStorageOutPayback", "pTradePayback")) {
    p <- scen@modInp@parameters[[pn]]
    if (is.null(p)) next
    d <- tryCatch(as.data.frame(get_data_slot(p)), error = function(e) NULL)
    if (is.null(d) || nrow(d) == 0) next
    for (v in sort(unique(d$value[!is.na(d$value) & d$value > 0]))) {
      fits <- ord + v - 1 <= span
      if (!any(fits)) next
      tot <- vapply(which(fits), function(i) {
        sum(len[ord >= ord[i] & ord < ord[i] + v])
      }, numeric(1))
      off <- sort(unique(tot[!vapply(tot, function(x) isTRUE(all.equal(x, v)),
                                     logical(1))]))
      if (length(off)) {
        message("payback = ", v, " does not land on a milestone boundary; ",
                "the annuity is charged over ", paste(off, collapse = "/"),
                " years depending on the vintage.")
      }
    }
  }
  invisible(NULL)
}

# `pXPayback` narrows the eqXEac charging window. GLPK, GAMS, JuMP/Julia and
# Pyomo-Concrete all implement it.
#
# Pyomo-ABSTRACT does not, and cannot without a bigger change: its eqXEac is
# still the pre-vintaging `pXEac * vXCap` form, which charges the annuity on
# TOTAL capacity -- pre-existing stock included -- rather than summing over
# still-alive vintages. Adding a payback window to that would be meaningless.
# An engine left on the olife window would quietly annuitise over the payback
# period while charging for the full operational life, over-recovering the
# investment, so it is refused instead.
.assert_payback_supported <- function(scen, engine) {
  used <- character()
  for (pn in c("pTechPayback", "pStorageOutPayback", "pTradePayback")) {
    p <- scen@modInp@parameters[[pn]]
    if (is.null(p)) next
    d <- as.data.frame(get_data_slot(p))
    if (!is.null(d) && nrow(d) > 0 && any(!is.na(d$value) & d$value > 0)) {
      used <- c(used, pn)
    }
  }
  if (length(used) == 0) return(invisible(NULL))
  stop("`payback` is not implemented for ", engine, " (set in ",
       paste(used, collapse = ", "), ").\n",
       "  It is available on GLPK, GAMS, JuMP/Julia and Pyomo-Concrete. ",
       "Pyomo-Abstract still uses the pre-vintaging `pXEac * vXCap` form.\n",
       "  Use one of those engines, or drop `@invcost$payback` and use ",
       "`@vintage$olife` for the cost-recovery period.")
}

compute_eac_parameters <- function(scen) {
  scen <- .eac_one(scen, "tech", "pTechInvcost", "pTechOlife", "mTechNew",
                   "pTechEac", "pTechWacc", "pTechPayback")
  scen <- .eac_one(scen, "stg", "pStorageOutInvcost", "pStorageOlife",
                   "mStorageNew", "pStorageOutEac", "pStorageOutWacc",
                   "pStorageOutPayback")
  # Each part's capital cost annuitises separately on the shared @vintage
  # lifetime. The `out.*` wacc/payback columns are the STORAGE-WIDE carrier
  # (a storage that says nothing per part gets one rate); a part-specific
  # `inp.` / `stg.` wacc or payback OVERRIDES it for that part.
  scen <- .eac_one(scen, "stg", "pStorageStgInvcost", "pStorageOlife",
                   "mStorageStgNew", "pStorageStgEac",
                   c("pStorageStgWacc", "pStorageOutWacc"),
                   c("pStorageStgPayback", "pStorageOutPayback"))
  scen <- .eac_one(scen, "stg", "pStorageInpInvcost", "pStorageOlife",
                   "mStorageInpNew", "pStorageInpEac",
                   c("pStorageInpWacc", "pStorageOutWacc"),
                   c("pStorageInpPayback", "pStorageOutPayback"))
  scen <- .eac_one(scen, "trade", "pTradeInvcost", "pTradeOlife", "mTradeNew",
                   "pTradeEac", "pTradeWacc", "pTradePayback")
  .check_payback_grid(scen)
  scen
}
