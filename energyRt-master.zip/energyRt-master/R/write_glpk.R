
#' @title Set the path to the GLPK library
#'
#' @param path character. Path to the GLPK library with `glpsol.*` executable.
#'
#' @return sets the path to the GLPK library in R options and returns NULL.
#'
#' @details By default energyRt uses the GLPK binary bundled by the glpsol R
#'   package when it is installed, and otherwise auto-detects the `glpsol`
#'   executable on the session `PATH` (via [base::Sys.which()]). On Windows the
#'   latter picks up the copy **bundled with Rtools** (Rtools ships the GLPK dev
#'   kit), so an Rtools user needs no separate install. Use `set_glpk_path()` only to point at a
#'   standalone GLPK installation, which then takes precedence over auto-detection.
#'
#' @rdname solver
#' @family solver glpk
#'
#' @export
#'
#' @examples
#' \dontrun{
#' set_glpk_path("/usr/local/bin/glpk") # Linux & Mac
#' set_glpk_path("C:/Program Files/glpk/bin") # Windows
#' get_glpk_path()
#' }
set_glpk_path <- function(path = NULL) {
  set_solver_path("glpk", path)
}

#' @export
#' @rdname solver
#' @family solver glpk
#' @return returns the path to the GLPK library.
get_glpk_path <- function() {
  get_solver_path("glpk")
}

# Resolve the `glpsol` executable for the built-in GLPK backend.
#
# Priority:
#   1. a directory configured via `set_glpk_path()` (standalone GLPK install);
#   2. the `glpsol` PACKAGE, which ships the executable - its version is known
#      and it needs no separate GLPK install, so it is preferred over whatever
#      happens to be on the machine;
#   3. `glpsol` on the session PATH via `Sys.which()` - on Windows this picks up
#      the copy BUNDLED WITH RTOOLS (rtools bundles the full GLPK dev kit), so an
#      Rtools user needs no separate GLPK install;
#   4. known Rtools toolchain locations (in case Rtools is installed but not on
#      the session PATH);
#   5. a bare `"glpsol"` resolved by the OS at run time (last resort).
#
# Returns the executable path (or bare command) as a length-1 character.
.find_glpsol <- function() {
  gp <- get_glpk_path()
  if (!is.null(gp) && nzchar(gp)) return(file.path(gp, "glpsol"))

  if (requireNamespace("glpsol", quietly = TRUE)) {
    hit <- tryCatch(glpsol::glpsol_path(), error = function(e) NULL)
    if (!is.null(hit) && nzchar(hit) && file.exists(hit)) return(hit)
  }

  found <- Sys.which("glpsol")
  if (nzchar(found)) return(unname(found))

  if (.Platform$OS.type == "windows") {
    cand <- Sys.glob(c(
      file.path(Sys.getenv("RTOOLS45_HOME"), "*", "bin", "glpsol.exe"),
      file.path(Sys.getenv("RTOOLS44_HOME"), "*", "bin", "glpsol.exe"),
      "C:/rtools4*/x86_64-w64-mingw32.static.posix/bin/glpsol.exe"))
    cand <- cand[file.exists(cand)]
    if (length(cand)) return(normalizePath(cand[1], winslash = "/"))
  }
  "glpsol"
}

# Build a `glpsol` command line, quoting the executable if its path has spaces.
# `--log` keeps a copy of glpsol's terminal output in the run directory.
# MathProg aborts the whole script when `solve` fails, so nothing after `solve;`
# runs -- not even the "solution status" row the other backends write. glpsol
# also exits 0 on an infeasible model, so its own log is the only place its
# verdict survives. `.solver_verdict()` reads it.
.glpsol_cmdline <- function(exe = .find_glpsol(),
                            args = paste("-m energyRt.mod -d energyRt.dat",
                                         "--log output/solver.log")) {
  if (grepl(" ", exe, fixed = TRUE)) exe <- shQuote(exe)
  paste(exe, args)
}

# MathProg GLPK (& MathProg with CBC) ####
# `sm_fun` selects the parameter -> GMPL data converter (`.sm_to_glpk`, which
# writes each parameter's full `@data` slot).
.write_model_GLPK_CBC <- function(arg, scen, sm_fun = .sm_to_glpk) {
  run_code <- scen@settings@sourceCode[["GLPK"]]
  dir.create(paste(arg$solver.dir, "/output", sep = ""), showWarnings = FALSE)
  file_w <- c()
  for (j in c("set", "map", "numpar", "bounds")) {
    for (i in names(scen@modInp@parameters)) {
      if (scen@modInp@parameters[[i]]@type == j) {
        file_w <- c(file_w, sm_fun(scen@modInp@parameters[[i]]))
      }
    }
  }
  # For downsize
  fdownsize <- names(scen@modInp@parameters)[
    sapply(scen@modInp@parameters, function(x) length(x@misc$rem_col) != 0)]
  for (nn in fdownsize) {
    rmm <- scen@modInp@parameters[[nn]]@misc$rem_col
    if (scen@modInp@parameters[[nn]]@type == "bounds") {
      uuu <- paste0(nn, c("Lo", "Up"))
    } else {
      uuu <- nn
    }
    for (yy in uuu) {
      templ <- paste0("(^|[^[:alnum:]])", yy, "[[]")
      templ2 <- paste0("(^|[^[:alnum:]])", yy, "[{]")
      if (any(grep("^pCns", nn))) {
        for (www in seq_along(scen@modInp@user_constraints)) {
          mmm <- grep(templ, scen@modInp@user_constraints[[www]]$equation)
          if (any(mmm)) {
            scen@modInp@user_constraints[[www]]$equation[mmm] <-
              sapply(strsplit(scen@modInp@user_constraints[[www]]$equation[mmm], yy),
                     .rem_col_sq, yy, rmm)
          }
        }
      } else {
        mmm <- grep(templ, run_code)
        if (any(mmm)) run_code[mmm] <- sapply(strsplit(run_code[mmm], yy),
                                              .rem_col_sq, yy, rmm)
        mmm <- grep(templ2, run_code)
        if (any(mmm)) run_code[mmm] <- sapply(strsplit(run_code[mmm], yy),
                                              .rem_col_fg, yy, rmm)
      }
    }
  }

  # Add constraint
  if (length(scen@modInp@user_constraints) > 0) {
    add_eq <- sapply(scen@modInp@user_constraints,
                     function(x) .equation.from.gams.to.glpk(x$equation))
    # Add additional maps
    mps_name <- grep("^[m]Cns", names(scen@modInp@parameters), value = TRUE)
    mps_name_def <- paste0("set ", mps_name, " dimen ",
                           sapply(scen@modInp@parameters[mps_name],
                                  function(x) length(x@dimSets)), ";")
    pps_name <- grep("^[p]Cns", names(scen@modInp@parameters), value = TRUE)
    pps_name_def <- paste0("param ", pps_name, " {",
                           sapply(scen@modInp@parameters[pps_name],
                                  function(x) paste0(x@dimSets, collapse = ", ")),
                           "};")
    if (length(pps_name) == 0) pps_name_def <- character()
  }


  ### Costs
  {
    add_eq_costs <- .equation.from.gams.to.glpk(scen@modInp@user_costs)
    # Add additional maps
    mps_name_costs <- grep("^[m]Costs", names(scen@modInp@parameters),
                           value = TRUE)
    mps_name_def_costs <- paste0("set ", mps_name_costs, " dimen ",
                                 sapply(scen@modInp@parameters[mps_name_costs],
                                        function(x) length(x@dimSets)), ";")
    pps_name_costs <- grep("^[p]Costs", names(scen@modInp@parameters),
                           value = TRUE)
    pps_name_def_costs <- paste0("param ", pps_name_costs, " {",
                                 sapply(scen@modInp@parameters[pps_name_costs],
                                        function(x)
                                          paste0(x@dimSets, collapse = ", ")),
                                 "};")
    pps_name_def_costs <- gsub("[{][ ]*[}]", "", pps_name_def_costs)
    if (length(mps_name_def_costs) == 0) mps_name_def_costs <- character()
    if (length(pps_name_costs) == 0) pps_name_def_costs <- character()
  }

  ### FUNC GLPK
  fn <- file(paste(arg$solver.dir, "/energyRt.mod", sep = ""), "w")
  if (length(grep("^minimize", run_code)) != 1) stop("Errors in GLPK model")

  cat(run_code[1:(grep("22b584bd-a17a-4fa0-9cd9-f603ab684e47", run_code) - 1)],
      sep = "\n", file = fn)
  if (length(scen@modInp@user_constraints) > 0) {
    cat(mps_name_def, sep = "\n", file = fn)
    cat(pps_name_def, sep = "\n", file = fn)
    cat(add_eq, sep = "\n", file = fn)
  }
  ### Costs
  cat(mps_name_def_costs, sep = "\n", file = fn)
  cat(pps_name_def_costs, sep = "\n", file = fn)
  cat(add_eq_costs, sep = "\n", file = fn)


  cat(run_code[grep(
    "22b584bd-a17a-4fa0-9cd9-f603ab684e47", run_code):(
      grep("^minimize", run_code) - 1)], sep = "\n", file = fn)
  cat(run_code[grep("^minimize", run_code):(grep("^end[;]", run_code) - 1)],
    sep = "\n", file = fn
  )
  cat(run_code[grep("^end[;]", run_code):length(run_code)], sep = "\n",
      file = fn)
  close(fn)
  fn <- file(paste(arg$solver.dir, "/energyRt.dat", sep = ""), "w")
  cat("set FORIF := FORIFSET;\n", sep = "\n", file = fn)
  cat(file_w, sep = "\n", file = fn)
  cat("end;", "", sep = "\n", file = fn)
  close(fn)
  .write_inc_files(arg, scen, NULL)

  if (is.null(scen@settings@solver$cmdline) || scen@settings@solver$cmdline == "") {
    if (toupper(scen@settings@solver$lang) == "GLPK") {
      # Default to an auto-detected glpsol (bundled with Rtools on Windows);
      # `set_glpk_path()` overrides to a standalone GLPK install. See .find_glpsol().
      scen@settings@solver$cmdline <- .glpsol_cmdline()
    } else {
      scen@settings@solver$cmdline <- "cbc energyRt.mod%energyRt.dat -solve"
    }
  }
  scen@settings@solver$code <- c("energyRt.mod")
  scen
}


# MathProg has no infinity literal, so a parameter whose declared default is
# `Inf` ("no bound") cannot be written as one -- and no substitute is correct:
# 0 pins the flow, a large number silently relaxes it, and a negative one turns
# `pDummyImportCost` into a subsidy. The clause is therefore OMITTED. The 29
# such parameters (`pTechAfc`, `pTechCap`, `pTechRampUp`, `pDummyImportCost`,
# ...) are read only inside equations whose domain is the parameter's own
# `meq*`/`m*` map, built as the domain intersected with the parameter's
# support, so no reference resolves to the default. Where that invariant breaks
# -- a map widened past its parameter, as a coarse process did to
# `meqTechAfcInpUp` -- GLPK refuses to translate and names the tuple
# (`no value for pTechAfcUp[PP,ELC,R1,2025,WIN]`) instead of solving a model
# with a fabricated bound. Finite defaults are kept: `pTechAfUp default 1` is
# the capacity limit every undeclared slice reads.
.glpk_default_clause <- function(dd) {
  if (is.infinite(dd)) "" else paste0(" default ", dd)
}


# Convert one scenario parameter to GMPL (GLPK/CBC) text. The interp_mod()
# pipeline keeps each parameter's `@data` slot authoritative, so the whole slot
# is written.
.sm_to_glpk <- function(obj) {
  if (obj@type == "set") {
    if (nrow(obj@data) == 0) {
      ret <- c(paste("set ", obj@name, " := ;", sep = ""), "")
    } else {
      ret <- c(paste("set ", obj@name, " := ",
                     paste(obj@data[[1]], collapse = " "), ";", sep = ""), "")
    }
  } else if (obj@type == "map") {
    if (nrow(obj@data) == 0) {
      ret <- paste("set ", obj@name, " := ;", sep = "")
    } else {
      ret <- paste("set ", obj@name, " := ", sep = "")
      ret <- c(ret, apply(obj@data, 1, function(x) {
        paste(paste(x, collapse = " "), ", ", sep = "")
        }))
      ret <- c(ret, ";", "")
    }
  } else if (obj@type == "numpar") {
    if (nrow(obj@data) == 0) {
      ret <- paste("param ", obj@name, .glpk_default_clause(obj@defVal),
                   " := ;", sep = "")
    } else {
      ret <- paste("param ", obj@name, .glpk_default_clause(obj@defVal),
                   " := ", sep = "")
      fl <- obj@data[["value"]] != Inf
      if (any(fl)) {
        ret <- c(
          ret,
          paste("[", apply(
            # obj@data[fl, -ncol(obj@data), drop = FALSE],
            select(filter(obj@data, fl), -ncol(obj@data)),
            1, function(x) paste(x, collapse = ",")
            ), "] ", obj@data[["value"]][fl], sep = "")
          )
      }
      if (ncol(obj@data) == 1) ret <- gsub("[[][ ]*[]]", "", ret)
      ret <- c(ret, ";", "")
    }
  } else if (obj@type == "bounds") {
    gg <- obj@data
    gg <- gg[gg$type == "lo", , drop = FALSE]
    # gg <- gg[, colnames(gg) != "type"]
    gg <- gg |> select(-any_of("type"))
    if (nrow(gg) == 0) { #  || all(gg$value[1] == gg$value)
      ret <- paste("param ", obj@name, "Lo",
                   .glpk_default_clause(obj@defVal[1]), " := ;", sep = "")
    } else {
      ret <- paste("param ", obj@name, "Lo",
                   .glpk_default_clause(obj@defVal[1]), " := ", sep = "")
      fl <- gg[["value"]] != Inf
      if (any(fl)) {
        ret <- c(
          ret, paste("[", apply(
            # gg[fl, -ncol(gg), drop = FALSE],
            select(filter(gg, fl), -last_col()),
            1, function(x) paste(x, collapse = ",")
            ), "] ", gg[["value"]][fl], sep = ""))
      }
      if (ncol(gg) == 1) ret <- gsub("[[][ ]*[]]", "", ret)
      ret <- c(ret, ";", "")
    }
    gg <- obj@data
    gg <- gg[gg$type == "up", , drop = FALSE]
    # gg <- gg[, colnames(gg) != "type"]
    gg <- gg |> select(-any_of("type"))
    if (nrow(gg) == 0) { #  || all(gg$value[1] == gg$value)
      ret <- c(ret, paste("param ", obj@name, "Up",
                          .glpk_default_clause(obj@defVal[2]), " := ;", sep = ""))
    } else {
      ret <- c(ret, paste("param ", obj@name, "Up",
                          .glpk_default_clause(obj@defVal[2]), " := ", sep = ""))
      fl <- gg[["value"]] != Inf
      if (any(fl)) {
        ret <- c(
          ret, paste("[", apply(
            # gg[fl, -ncol(gg), drop = FALSE],
            select(filter(gg, fl), -ncol(gg)),
            1, function(x) paste(x, collapse = ",")
            ), "] ", gg[["value"]][fl], sep = "")
          )
      }
      if (ncol(gg) == 1) ret <- gsub("[[][ ]*[]]", "", ret)
      ret <- c(ret, ";", "")
    }
  } else {
    stop("Must realise")
  }
  ret
}

# Translate GAMS constraints to GLPK functions ####
# Make vector .alias_set (from gams to alias) and set_alias

# set_alias <- .set_al0
# names(set_alias) <- .alias_set

.get_glpk_loop_fast <- function(set_loop, set_cond, add_cond = NULL) {
  if (!is.null(set_cond) && substr(set_cond, 1, 1) == "(") {
    set_cond <- sub("^[(]", "", sub("[)]$", "", set_cond))
  }
  set_loop <- sub("^[(]", "", sub("[)]$", "", set_loop))
  xx <- .generate_loop_glpk(set_loop, set_cond)
  rs <- paste0("{", xx$first)
  if (!is.null(xx$end) || !is.null(add_cond)) {
    rs <- paste0(rs, " : ", paste0(xx$end, add_cond, collapse = " and "))
  }
  rs <- paste0(rs, "}")
  rs
}


.generate_loop_glpk <- function(set_num, set_loop) {
  # Consdition split and divet by subset
  while (!is.null(set_loop) && substr(set_loop, 1, 1) == "(" && substr(set_loop, nchar(set_loop), nchar(set_loop)) == ")") {
    set_loop <- substr(set_loop, 2, nchar(set_loop) - 1)
  }
  while (!is.null(set_num) && substr(set_num, 1, 1) == "(" && substr(set_num, nchar(set_num), nchar(set_num)) == ")") {
    set_num <- substr(set_num, 2, nchar(set_num) - 1)
  }
  cnd <- gsub(" ", "", strsplit(set_loop, "and ")[[1]])
  cnd_slice <- strsplit(gsub("(.*[(]|[)]| )", "",
                             strsplit(set_loop, "and ")[[1]]), ",")
  cnd_slice <- lapply(cnd_slice, .aliasName)
  cnd0 <- gsub("[(].*", "", cnd)

  to_merge_slice <- sapply(cnd_slice, paste0, collapse = "#")
  rs <- NULL
  for (i in unique(to_merge_slice)) {
    fl <- (to_merge_slice == i)
    fl1 <- seq_along(fl)[fl][1]
    rs <- c(rs, paste0(
      "("[length(cnd_slice[[fl1]]) > 1],
      paste0(cnd_slice[[fl1]], collapse = ", "), ")"[
        length(cnd_slice[[fl1]]) > 1],
      " in ", "("[sum(fl) > 1],
      paste0(cnd0[fl], collapse = " inter "), ")"[sum(fl) > 1]
    ))
  }
  # Check if subset on set (glpk is not allowed situation like "(t, g, c) in mTechGroupComm (t, g) in mTechInpGroup", mTechInpGroup - not allowed)

  not_use <- rep(FALSE, length(rs))
  sss <- unique(to_merge_slice)
  for (tt in seq_along(sss)) {
    jj <- strsplit(sss[tt], "#")[[1]]
    if (any(sapply(cnd_slice,
                   function(x) all(jj %in% x) && length(x) > length(jj)))) {
      not_use[tt] <- TRUE
    }
  }

  in_slc <- .aliasName(gsub(" ", "", strsplit(set_num, ",")[[1]]))
  not_use[sapply(strsplit(sss, "#"),
                 function(x) length(x) == 1 && all(x != in_slc))] <- TRUE

  if (any(not_use)) {
    tend <- paste0(rs[not_use], collapse = " and ")
  } else {
    tend <- NULL
  }
  rs <- paste0(rs[!not_use], collapse = ", ")
  # Rest timeslice without mapping
  timeslice <- gsub(" ", "", strsplit(set_num, ",")[[1]])
  # timeslice2 <- .aliasName(timeslice)
  rest_slice <- timeslice[!(.aliasName(timeslice) %in% c(cnd_slice, recursive = TRUE))]
  if (length(rest_slice) > 0) {
    if (rs == "") rs <- NULL
    rs <- paste0(c(rs, paste0(.aliasName(rest_slice), " in ", rest_slice)), collapse = ", ")
  }
  if (any(grep("^[,]", rs))) {
    stop("Internal: the slice list starts with a comma: ", rs, call. = FALSE)
  }
  list(first = rs, end = tend)
}
.get_glpk_loop_fast2 <- function(tx) {
  if (any(grep("[$]", tx))) {
    beg <- gsub("[$].*", "", tx)
    end <- substr(tx, nchar(beg) + 2, nchar(tx))
  } else {
    beg <- tx
    end <- NULL
  }
  .get_glpk_loop_fast(beg, end)
}

.get.bracket.glpk <- function(tmp) {
  brk0 <- gsub("[^)(]", "", tmp)
  brk <- cumsum(c("(" = 1, ")" = -1)[strsplit(brk0, "")[[1]]])
  k <- seq_along(brk)[brk == 0][1]
  end <- sub(paste0("^", paste0(paste0("[", names(brk)[1:(k - 1)], "]"),
                                rep("[^)(]*", k - 1), collapse = ""),
                    names(brk)[k]), "", tmp)
  list(beg = substr(tmp, 1, nchar(tmp) - nchar(end)), end = end)
}


# "s.t. eqCnsMINGASgrow2{y in (mMidMilestone inter mMilestoneHasNext)}: sum{y in mMidMilestone, (c, s) in mCommTimeslice, r in region : c in (mCnsMINGASgrow2_1 inter mCnsMINGASgrow2_1)}(-1 * vOutTot[c, r, y, s]+ sum{(y, yp) in mMilestoneNext, (c, s) in mCommTimeslice, r in region : c in (mCnsMINGASgrow2_1 inter mCnsMINGASgrow2_1) and yp in mMidMilestone}(pCnsMultMINGASgrow2_2[y]* vOutTot[c, r, yp, s]>=0;"

# tmp = '((comm, region, timeslice)$(mCnsMINGASgrow2_1(comm) and mMidMilestone(year) and mCommTimeslice(comm, timeslice) and mCnsMINGASgrow2_1(comm)), -1 * vOutTot(comm, region, year, timeslice))'
.handle.sum.glpk <- function(tmp) {
  hh <- .get.bracket.glpk(tmp)
  a1 <- sub("^[(]", "", sub("[)]$", "", hh$beg))
  a2 <- a1
  while (substr(a2, 1, 1) != ",") {
    a2 <- gsub("^([[:alnum:]]|[+]|[-]|[*]|[$])*", "", a2)
    if (substr(a2, 1, 1) == "(") {
      a2 <- .get.bracket.glpk(a2)$end
    }
  }
  paste0(.get_glpk_loop_fast2(substr(a1, 1, nchar(a1) - nchar(a2))), "(", .eqt.to.glpk(substr(a2, 2, nchar(a2))), ")", .eqt.to.glpk(hh$end))
}
.eqt.to.glpk <- function(tmp) {
  # ITER = get('ITER', globalenv()) + 1
  # cat(ITER, tmp, '\n')
  # assign('ITER', ITER, globalenv())
  # if (ITER > 20) stop('ITER', ITER)
  rs <- ""
  while (nchar(tmp) != 0) {
    tmp <- gsub("^[ ]*", "", tmp)
    if (substr(tmp, 1, 4) == "sum(") {
      rs <- paste0(rs, "sum", .handle.sum.glpk(substr(tmp, 4, nchar(tmp))))
      tmp <- ""
    # } else if (any(grep("^([.[:digit:]]|[+]|[-]|[ ]|[*])", tmp))) {
    #   a3 <- gsub("^([.[:digit:]_]|[+]|[-]|[ ]|[*])*", "", tmp)
    # changing pattern to include scientific numbers
    } else if (any(grep("^([.[:digit:]_]([eE][-+]?\\d+)?|[+]\\s*|[-]\\s*|[ ]|[*])",
                        tmp))) {
      a3 <- gsub("^([.[:digit:]_]([eE][-+]?\\d+)?|[+]\\s*|[-]\\s*|[ ]|[*])", "", tmp)
      rs <- paste0(rs, substr(tmp, 1, nchar(tmp) - nchar(a3)))
      tmp <- a3
    } else if (substr(tmp, 1, 1) %in% c("m", "v", "p")) {
      a1 <- sub("^[[:alnum:]_]*", "", tmp)
      vrb <- substr(tmp, 1, nchar(tmp) - nchar(a1))
      a2 <- .get.bracket.glpk(a1)
      arg <- paste0(.aliasName(strsplit(gsub("[() ]", "", a2$beg), ",")[[1]]),
                    collapse = ", ")
      if (nchar(a2$end) > 1 && substr(a2$end, 1, 1) == "$") {
        rs <- paste0(
          rs, "sum{FORIF: (", arg, ") in ", gsub("([$]|[(].*)", "", a2$end),
          "} (", vrb, "[", arg, "])",
          .eqt.to.glpk(gsub("^[^)]*[)]", "", a2$end))
        )
        tmp <- ""
      } else {
        rs <- paste0(rs, vrb, "[", arg, "]", .eqt.to.glpk(a2$end))
        tmp <- ""
      }
    } else if (substr(tmp, 1, 1) == "=") {
      rs <- paste0(rs, c("g" = ">=", "e" = "=", "l" = "<=")[substr(tmp, 2, 2)])
      tmp <- substr(tmp, 4, nchar(tmp))
    } else if (substr(tmp, 1, 1) == ";") {
      rs <- paste0(rs, ";")
      tmp <- substr(tmp, 2, nchar(tmp))
    } else {
      stop("Cannot parse the equation template; unrecognised token at: ",
           substr(tmp, 1, 40), call. = FALSE)
    }
  }
  rs
}

# Equation declaration
.equation.from.gams.to.glpk <- function(eqt) {
  declaration <- gsub("[.][.].*", "", eqt)
  rs <- paste0("s.t. ", gsub("[($].*", "", declaration))
  if (nchar(declaration) != nchar(gsub("[($].*", "", declaration))) {
    rs <- paste0(rs, .get_glpk_loop_fast2(gsub("^[[:alnum:]_]*", "", declaration)))
  }
  rs <- paste0(rs, ": ", gsub("[[][ ]*[]]", "",
                              .eqt.to.glpk(gsub(".*[.][.][ ]*", "", eqt))))
  rs
}



