# class model ####
# setTimeSlices <- .setTimeSlices

#' An S4 class to represent model
#'
#' @name class-model
#' @aliases model
#'
#' @slot name `r get_slot_doc("model", "name")`
#' @slot desc `r get_slot_doc("model", "desc")`
#' @slot data `r get_slot_doc("model", "data")`
#' @slot config `r get_slot_doc("model", "config")`
#' @slot misc `r get_slot_doc("model", "misc")`
#'
#' @include class-config.R class-repository.R
#'
#' @export
setClass("model",
  representation(
    name = "character",
    desc = "character", # Details
    data = "list",
    config = "config",
    # optimizeRetirement = "logical",
    misc = "list"
  ),
  prototype(
    name = "",
    desc = "", # Details
    data = list(),
    config = new("config"),
    # optimizeRetirement = FALSE,
    misc = list()
  ),
  S3methods = FALSE
)

setMethod("initialize", "model", function(.Object, ...) {
  .Object
})

# add <- function(...) UseMethod("add")


#' Create new model object
#'
#' @param name name of the model
#' @param desc free-text description of the model.
#' @param obj a `model` object (the `setHorizon` / `getHorizon` methods).
#' @param ... configuration parameters (see class config) and model elements (classes commodity, technology, etc.)
#'
#' @return model object containing model elements (`@data`) and configuration (`@config`)
#' @rdname newModel
#' @family model scenario
#' @export
#'
#' @examples
#' \dontrun{
#' mod <- newModel(
#'   name = "MyModel",
#'   desc = "My first model",
#'   data = model_repository,
#'   discount = 0.05,
#'   horizon = newHorizon(period = 2020:2050,
#'                        intervals = rep(5, 10)),
#'   calendar = calendars$d365_h24
#'   )
#' }
newModel <- function(name = "", desc = "", ...) {
  # mdl <- .data2slots("model", name,
  #                    ignore_args = unique(c(config_slots, horizon_slots)),
  #                    ignore_classes = "repository", ...)
  obj <- new("model")
  .assert_object_name(name, what = "model")
  obj@name <- name
  obj@desc <- desc
  arg <- list(...)
  if (is_empty(arg)) return(obj)

  ## flatten unnamed lists if any ####
  # nn <- names(arg)
  ii <- sapply(seq_along(arg), function(i) {
    inherits(arg[[i]], "list") && names(arg)[[i]] == ""
    })
  if (any(ii)) {
    arg <- list_flatten(arg, name_spec = "{inner}")
  }
  #
  ## named slots ####
  repo <- newRepository("default")
  ### @misc ####
  if (!is.null(arg$misc)) {
    if (!inherits(arg$misc, "list")) stop('"misc" must be a named list')
    if (is_empty(obj@misc)) {
      obj@misc <- arg$misc
    } else {
      obj@misc <- c(obj@misc, arg$misc)
    }
    arg$misc <- NULL
  }
  ### @data | @repository ####
  if (!is.null(arg$data) | !is.null(arg$repository)) {
    if (is.null(arg$data)) {
      arg$data <- arg$repository; arg$repository <- NULL
    } else {
      if (!is.null(arg$repository))
        stop("Only one of 'data' or 'repository' arguments can be assigned.")
    }
    if (inherits(arg$data, c("repository"))) {
      repo <- arg$data
    } else if (!inherits(arg$data, "list")) {
      # arg$data <- purrr::list_flatten(arg$data, name_spec = "{inner}")
      repo <- do.call("add", c(object = repo, arg$data))
    } else {
      stop('"data" ("repository") must be a "repository" or "list" object')
    }
    # obj@data <- repo@data
    obj <- add(obj, arg$data)
    arg$data <- NULL
  }
  ### @config ####
  if (!is.null(arg$config)) {
    if (!inherits(arg$config, "config")) {
      stop('"config" argument must be an object of class "cofig"')
    }
    obj@config <- arg$config
    arg$config <- NULL
  }
  ### @horizon ####
  if (!is.null(arg$horizon)) {
    if (!inherits(arg$horizon, "horizon")) {
      stop('"horizon" argument must be an object of class "horizon"')
    }
    obj@config@horizon <- arg$horizon
    arg$horizon <- NULL
  }
  ### @horizon ####
  if (!is.null(arg$calendar)) {
    if (!inherits(arg$calendar, "calendar")) {
      stop('"calendar" argument must be an object of class "calendar"')
    }
    obj@config@calendar <- arg$calendar
    arg$calendar <- NULL
  }
  ### @geoscale ####
  if (!is.null(arg$geoscale)) {
    if (!is_geoscale(arg$geoscale)) {
      stop('"geoscale" argument must be a "geoscales::GeoScale" object')
    }
    obj@config@geoscale <- arg$geoscale
    arg$geoscale <- NULL
  }
  if (is_empty(arg)) return(obj)
  #
  ## unnamed args, process by class ####
  ### repository objects ####
  ii <- sapply(arg, function(x) inherits(x, c("repository")))
  if (any(ii)) {
    for (ob in arg[ii]) {obj <- add(obj, ob)}
  }
  arg <- arg[!ii]
  ### @config obj ####
  ii <- sapply(arg, function(x) inherits(x, c("config")))
  if (any(ii)) {
    if (sum(ii) > 1) stop('Two or more "config" objects found.')
    obj@config <- arg[ii]
    arg[ii] <- NULL
  }
  ### @horizon obj ####
  ii <- sapply(arg, function(x) inherits(x, c("horizon")))
  if (any(ii)) {
    if (sum(ii) > 1) stop('Two or more "horizon" objects found.')
    obj@config@horizon <- arg[ii]
    arg[ii] <- NULL
  }
  ### @geoscale obj ####
  ii <- sapply(arg, is_geoscale)
  if (any(ii)) {
    if (sum(ii) > 1) stop('Two or more "geoscale" objects found.')
    obj@config@geoscale <- arg[ii][[1]]
    arg[ii] <- NULL
  }
  if (is_empty(arg)) return(obj)
  #
  ## named other slots ####
  ex_slots <- c(".S3Class", "name", "desc")
  ### @config slots ####
  config_slots <- names(getSlots("config"))
  config_slots <- config_slots[!(config_slots %in% ex_slots)]
  ii <- names(arg) %in% config_slots
  if (any(ii)) {
    obj@config <- do.call("update", c(object = obj@config, arg[ii]))
    arg[ii] <- NULL
  }
  if (is_empty(arg)) return(obj)
  ### @horizon slots #### !!! write update(config) with config & horizon slots
  horizon_slots <- names(getSlots("horizon"))
  horizon_slots <- horizon_slots[!(horizon_slots %in% ex_slots)]
  ii <- names(arg) %in% horizon_slots
  if (any(ii)) {
    obj@config@horizon <- .data2slots("horizon", obj@config@horizon, arg[ii])
    obj@config@horizon <- do.call("update",
                                  c(object = obj@config@horizon, arg[ii]))
    arg[ii] <- NULL
  }
  if (is_empty(arg)) return(obj)
  ii <- sapply(arg, inherits, what = newRepository()@permit)
  if (any(ii)) obj <- add(obj, arg[ii])
  arg <- arg[!ii]
  if (is_empty(arg)) return(obj)
  for (i in seq_along(arg)) {
    if (inherits(arg[[i]], "list")) {
      arg_i <- purrr::flatten(arg[[i]])
      for (j in seq_along(arg_i)) {
        obj <- add(obj, arg_i[[j]])
      }
    }
  }
  # if (length(arg) > 0)
  # warning("Ignoring ", length(arg), " arguments.\n",
  #         "names: ", paste(names(arg), collapse = ", "), "\nclasses: ",
  #         paste(sapply(arg, class), collapse = ", "))
  obj
#
#   config_slots <- config_slots[config_slots %in% names(args)]
#   mdl@config <- .data2slots(
#     "config", "", ignore_classes = "repository",
#     ignore_args = c("timeslice", names(args)[!(names(args) %in% config_slots)]),
#     ...)
#   # ignore_args = c(names(args)[!(names(args) %in% config_slots)], mlst_vec), ...)
#
#   if (any(names(args) == "timeslice")) {
#     mdl@config <- setTimeSlices(mdl@config, timeslice = args$timeslice)
#   } else {
#     mdl@config <- setTimeSlices(mdl@config, timeslice = "ANNUAL")
#   }
#
#   #    args <- list(...)
#   #    if (any(names(args) %in% mlst_vec)) {
#   #      if (sum(names(args) %in% mlst_vec) != 2) stop('Undefined all need parameters for setMileStoneYears')
#   #      mdl <- setMileStoneYears(mdl, start = args$start, interval = args$interval)
#   #    }
#   mdl
}


#' @rdname newModel
#' @aliases setHorizon getHorizon
#' @export
setMethod("setHorizon", signature(obj = "model"),
  # signature(obj = "model", period = "numeric", intervals = "numeric"),
  function(obj, ...) {
    args <- list(...)
    has_h <- sapply(args, function(x) inherits(x, "horizon"))
    if (any(has_h)) {
      if (sum(has_h) > 1) stop('Two or more "horizon" objects found.')
      obj@config@horizon <- args[has_h]
    } else {
      obj@config <- setHorizon(obj@config, ...)
    }
    obj
  }
)

#' @rdname newModel
#' @export
setMethod("getHorizon", signature(obj = "model"), function(obj) {
  getHorizon(obj@config)
})

# Methods ####
## [[ ####
#' @export
setMethod("[[", c("model", "ANY"), function(x, i) {
  flatten_mod_data(x@data)[i]
  }
)

#' @export
setMethod("[", c("model", "ANY"), function(x, i) {
  flatten_mod_data(x@data)[i]
}
)

## $ ####
#' @export
setMethod("$", "repository", function(x, name) x@data[[name]])

setReplaceMethod("$", c("repository", "ANY"),
                 function(x, name, value) {
                   nm <- names(x@data)
                   ii <- which(nm == value@name)
                   if (length(ii) > 0) {
                     # replace name
                     nm[ii] <- value@name
                     x@data[[name]] <- value
                     names(x@data) <- nm
                   } else {
                     x@data[[name]] <- value
                   }
                   x
                 }
)

## names ####
#' @export
#' @family repository
setMethod("names", "repository", function(x) names(x@data))

# Name of the repository that `add(model, <object>)` creates when the caller
# names none. Anything but "" -- see the note in add.model().
.default_repo_name <- "default_repository"

add.model <- function(obj, ..., overwrite = FALSE, repo_name = NULL) {
  # cls <- c('technology', 'commodity', 'region', 'commodity',
  #          'constraint', 'costs',
  #          'stock', 'reserve',
  #          'supply', 'weather', 'demand',
  #          'trade', 'export', 'import', 'storage', 'tax', 'sub')
  cls <- newRepository()@permit
  # if (class(obj) != "model") stop('Applying add.model to class ', class(obj))
  arg <- list(...)
  while (any(sapply(arg, function(x) class(x)[1] == 'list'))) {
    arg <- list_flatten(arg, name_spec = "{inner}")
  }
  ## Calendar from solve must be added to interpolate
  arg_classes <- sapply(arg, class)
  # if (any(arg_classes == "calendar")) {
  #   if (length(arg_classes[arg_classes == "calendar"]) > 1) {
  #     stop("Only one calendar object is allowed")
  #   }
  #   obj@data$calendar <- arg[arg_classes == "calendar"]
  #   arg <- arg[arg_classes != "calendar"]
  # }

  ## Add to repository
  if (any(!(sapply(arg, class) %in% c(cls, 'repository')))) {
    stop(paste('Unknown class "', paste(unique(sapply(arg, class)[
      !(sapply(arg, class) %in% c(cls, 'repository'))]), collapse = '", "'),
      '"', sep = ''))
  }
  # cc <- sapply(arg, function(x) class(x)[1])
  ii <- sapply(arg, function(x) inherits(x, cls))
  # An incoming bare object whose class+name already lives in ONE OF THE
  # MODEL'S REPOSITORIES is a REPLACEMENT, not an addition: with
  # `overwrite = TRUE` it swaps in where the old object sits (this is what
  # lets a kit module -- a re-declared `SUP_GAS`/`EWIN`/`ENUC` -- supersede
  # the base declaration); without it, it is an error. Previously such an
  # object was silently appended to the default repository NEXT TO the old
  # one (the bare-object path returns before the cross-repository duplicate
  # check below), and interpolation then used both.
  if (any(ii)) {
    for (k in which(ii)) {
      x <- arg[[k]]
      hit_repo <- NA_integer_; hit_obj <- NA_integer_
      for (ri in seq_along(obj@data)) {
        rdat <- obj@data[[ri]]@data
        oi <- which(vapply(rdat, function(y)
          identical(class(y)[1], class(x)[1]) && identical(y@name, x@name),
          logical(1)))
        if (length(oi)) { hit_repo <- ri; hit_obj <- oi[1]; break }
      }
      if (!is.na(hit_repo)) {
        if (!overwrite) {
          stop('Object "', x@name, '" (', class(x)[1], ') already exists in ',
               'repository "', obj@data[[hit_repo]]@name,
               '". Use `overwrite = TRUE` to replace it.', call. = FALSE)
        }
        obj@data[[hit_repo]]@data[[hit_obj]] <- x
        ii[k] <- FALSE            # handled: keep it off the default-repo path
        arg[k] <- list(NULL)
      }
    }
    drop_k <- vapply(arg, is.null, logical(1))
    arg <- arg[!drop_k]; ii <- ii[!drop_k]
  }
  if (any(ii)) {
    # arg <- arg[cc != 'repository']
    # Generate name
    # Objects added straight to a model (rather than to a named repository) land
    # in an auto-created one. It used to be built with the class prototype's
    # EMPTY name, which cannot work: `obj@data[[""]]` is always NULL, so the
    # "does it exist already?" test below was always TRUE and EVERY add()
    # appended ANOTHER empty-named repository. With two of them present,
    # `ff == repo_name` matched two positions and `obj@data[[fl]]` became
    # RECURSIVE indexing -- `obj@data[[c(2, 3)]]` -- which fails with
    # "subscript out of bounds". A model could therefore be given exactly one
    # object this way; a second `add()` errored.
    #
    # Naming the repository makes the lookup work, so repeated adds accumulate
    # in one place. The name is also what the repository branch further down
    # already demands of a user-supplied repository ("Empty repository name is
    # not allowed"), so the auto-created one no longer breaks the class's own
    # rule.
    if (is.null(repo_name)) repo_name <- .default_repo_name
    ff <- c(sapply(obj@data, function(x) x@name), recursive = TRUE)
    if (!any(ff == repo_name)) {
      # `newRepository()`, NOT `new("repository", name = ...)`: the class's
      # `initialize` method discards `...` outright (it only fills `@permit`),
      # so `new()` silently returns a repository whose name is still "" no
      # matter what is passed. That was the other half of this bug -- a
      # user-supplied `repo_name` was dropped exactly like the default one, so
      # `add(mod, x, repo_name = "mine")` was equally unrepeatable.
      obj@data[[repo_name]] <- newRepository(repo_name)
      ff <- c(sapply(obj@data, function(x) x@name), recursive = TRUE)
    }
    # Positional, and deliberately ONE position: a legacy model deserialised
    # with two same-named repositories would otherwise index recursively again.
    fl <- which(ff == repo_name)[1]
    for (i in seq(along = arg[ii])) {
      obj@data[[fl]] <- add(obj@data[[fl]], arg[ii][[i]], overwrite = overwrite)
    }
  }
  arg <- arg[!ii]
  if (is_empty(arg)) return(obj)
  # cc <- sapply(arg, function(x) class(x)[1])
  ii <- sapply(arg, function(x) inherits(x, "repository"))
  if (any(ii)) {
    #    if (any(sapply(arg, class) != 'repository'))
    #      stop('You can not mix class repository and other for command add')
    # arg <- arg[sapply(arg, class) == 'repository']
    ff <- c(sapply(obj@data, function(x) x@name), recursive = TRUE)
    for (i in seq(along = arg[ii])) {
      nm <- arg[ii][[i]]@name # new repository name
      if (nm == "") stop('Empty repository name is not allowed.')
      if (any(ff == nm)) {
        # add data to existing repository
        obj@data[[nm]] <- add(obj@data[[nm]], arg[ii][[i]],
                              overwrite = overwrite)
      } else {
        # !!! add name-check with other repositories
        obj@data[[nm]] <- arg[ii][[i]]
      }
      # With `overwrite = TRUE` an incoming repository SUPERSEDES same-named
      # objects wherever they sit: a kit module (e.g. EWIN_SITES carrying a
      # re-declared `EWIN`) replaces the base declaration in its own
      # repository instead of tripping the duplicate check below.
      if (isTRUE(overwrite)) {
        keys <- vapply(arg[ii][[i]]@data,
                       function(y) paste(class(y)[1], y@name), character(1))
        for (ri in seq_along(obj@data)) {
          if (identical(obj@data[[ri]]@name, nm)) next
          rk <- vapply(obj@data[[ri]]@data,
                       function(y) paste(class(y)[1], y@name), character(1))
          dup <- rk %in% keys
          if (any(dup)) obj@data[[ri]]@data <- obj@data[[ri]]@data[!dup]
        }
      }
    }
    arg <- arg[!ii]
  }
  # check duplicated names in class
  hh <- c(
    sapply(obj@data, function(x) {
      sapply(x@data, function(y) paste(class(y), ' - ', y@name, sep = ''))
    }), recursive = TRUE)
  if (anyDuplicated(hh)) {
    hh <- unique(hh[duplicated(hh)])
    stop('Duplicated objects in "class - name"\n',
         paste(hh, sep = "\n"))
  }
  ## check duplicated names in all objects
  ff <- c(lapply(obj@data, function(x) sapply(x@data, function(y) y@name)),
          recursive = TRUE)
  if (anyDuplicated(ff)) {
    stop(paste('Duplicated objects "',
               paste(unique(ff[duplicated(ff)]), collapse = '", "'),
               '"', sep = ''))
  }
  if (length(arg) > 0) {
    warning("Ignored objects: ", paste(names(arg), ", "))
  }
  obj
}

#' Add an object to the model's repository
#'
#' @param obj model object
#' @param ... model elements, allowed classes: ...
#' @param overwrite logical, if TRUE, objects with the same name will be overwritten, error will be reported if FALSE
#' @param repo_name character, optional name of a (sub-)repository to add the object.
#'
#' @method add model
#' @rdname add
#' @aliases add
#'
#' @return model object with added elements to the repository
#'
#' @details There is no `add` method for a `scenario`: a scenario's inputs are
#'   already interpolated. Add objects to the model and interpolate again.
#' @export
setMethod("add", "model", add.model)

summary.model <- function(object, ...) {
  cat("Model: ", object@name, "\n")
  cat("Description: ", object@desc, "\n")
  cat("Repositories: ", paste(names(object@data), collapse = ", "), "\n")
  reg <- get_region(object)
  if (length(reg) > 0L) {
    cat("Regions: ", length(reg), " (", .preview_chr(reg), ")\n", sep = "")
  }
  cnt <- .object_counts(object)
  if (length(cnt) > 0L) {
    cat("Objects: ", sum(cnt), "\n", sep = "")
    print(cnt)
  }
  invisible(cnt)
}

# Objects by class across every repository of the model -- the count
# `summary()` already gives for a single repository, so that a reader can get it
# from a model without reaching into `@data`.
#' @noRd
.object_counts <- function(object) {
  cls <- unlist(lapply(object@data, function(rp) {
    objs <- if (methods::is(rp, "repository")) rp@data else list(rp)
    vapply(objs, function(o) class(o)[1], "")
  }), use.names = FALSE)
  if (length(cls) == 0L) {
    return(integer(0))
  }
  tb <- table(cls)
  stats::setNames(as.integer(tb), names(tb))
}

#' @noRd
.preview_chr <- function(x, n = 5L) {
  paste0(paste(utils::head(x, n), collapse = ", "),
         if (length(x) > n) ", ..." else "")
}

#' @rdname summary
#' @method summary model
#' @export
setMethod("summary", "model", summary.model)

