# calendar-class ####
#' An S4 class to represent sub-annual time resolution structure.
#'
#' @name class-calendar
#'
#' @description
#' Sub-annual time resolution is represented by nested, named
#' time-frames and time-timeslices.
#'
#' @md
#' @slot name `r get_slot_doc("calendar", "name")`
#' @slot desc `r get_slot_doc("calendar", "desc")`
#' @slot timeframes `r get_slot_doc("calendar", "timeframes")`
#' @slot year_fraction `r get_slot_doc("calendar", "year_fraction")`
#' @slot year_start `r get_slot_doc("calendar", "year_start")`
#' @slot utc_offset_minutes `r get_slot_doc("calendar", "utc_offset_minutes")`
#' @slot timetable `r get_slot_doc("calendar", "timetable")`
#' @slot timeslice_share `r get_slot_doc("calendar", "timeslice_share")`
#' @slot default_timeframe `r get_slot_doc("calendar", "default_timeframe")`
#' @slot timeframe_rank `r get_slot_doc("calendar", "timeframe_rank")`
#' @slot timeslices_in_frame `r get_slot_doc("calendar", "timeslices_in_frame")`
#' @slot timeslice_family `r get_slot_doc("calendar", "timeslice_family")`
#' @slot timeslice_ancestry `r get_slot_doc("calendar", "timeslice_ancestry")`
#' @slot next_in_timeframe `r get_slot_doc("calendar", "next_in_timeframe")`
#' @slot next_in_year `r get_slot_doc("calendar", "next_in_year")`
#' @slot misc `r get_slot_doc("calendar", "misc")`
#'
#' @include generics.R defaults.R
#' @rdname class-calendar
#' @export
setClass("calendar", # alt: timestructure, timescales, timescheme, timeframe, schedule
  representation(
    name = "character",
    desc = "character",
    timeframes = "list", # renamed `timeslice_map` // alt.names: hierarchy, nest, ..
    year_fraction = "numeric",
    year_start = "list", # list(month = , day = ): first day of the model year
    utc_offset_minutes = "integer",
    timetable = "data.frame", # renames `levels`
    timeslice_share = "data.frame", # !!! rename to fraction?
    default_timeframe = "character", # renamed `default_timeslice_level`
    timeframe_rank = "integer", # renamed `misc$deep`
    timeslices_in_frame = "integer", # renamed `misc$nlevel`
    timeslice_family = "data.frame", # renamed `parent_child`
    timeslice_ancestry = "data.frame", # renamed `all_parent_child`
    next_in_timeframe = "data.frame", # renamed `misc$next_timeslice`
    next_in_year = "data.frame", # renamed `misc$fyear_next_timeslice`
    misc = "list"
    # full_set = "character", # renamed `all_timeslice` -> timeslice_share$timeslice
  ),
  prototype(
    name = character(),
    desc = character(),
    timeframes = list(), # Timeslices set by level
    year_fraction = as.numeric(1),
    year_start = list(month = 1L, day = 1L),
    utc_offset_minutes = 0L,
    timetable = data.frame(stringsAsFactors = FALSE),
    timeslice_share = data.frame(
      # year = integer(),
      timeslice = character(), # == time interval
      share = numeric(), # fraction of a year // rename?
      weight = numeric(),
      stringsAsFactors = FALSE
    ),
    timeslices_in_frame = integer(),
    timeslice_family = data.frame(
      # year = integer(),
      parent = character(),
      child = character(),
      stringsAsFactors = FALSE
    ),
    timeslice_ancestry = data.frame(
      # year = integer(),
      parent = character(),
      child = character(),
      stringsAsFactors = FALSE
    ),
    default_timeframe = character(), # Default timeslice
    timeframe_rank = c("ANNUAL" = 1L),
    next_in_timeframe = data.frame(
      timeslice = character(),
      timeslicep = character()
    ),
    next_in_year = data.frame(
      timeslice = character(),
      timeslicep = character()
    ),
    # all_timeslice = character(), -> timeslice_share$timeslice
    misc = list()
  ),
  S3methods = FALSE
)

setMethod("initialize", "calendar", function(.Object, ...) {
  .Object
})


#' Create timetable of time-timeslices from given structure as a list
#'
#' @param struct named list of timeframes with sets of timeslices and optional shares of every timeslice or frame in the nest
#' @param warn logical, if TRUE, warning will be issued if `ANNUAL` level does not exists in the given structure. The level will be auto-created to complete the time-structure.
#' @param year_fraction `r get_slot_doc("calendar", "year_fraction")`
#'
#' @return an data.frame with the specified structure.
#' @order 2
#' @export
#' @rdname calendar
#'
#' @examples
#' make_timetable()
#' make_timetable(list("SEASON" = c("WINTER", "SUMMER")))
#' make_timetable(list("SEASON" = c("WINTER" = .6, "SUMMER" = .4)))
#' make_timetable(list(
#'   "SEASON" = list(
#'     "WINTER" = list(.3, DAY = c("MORNING", "EVENING")),
#'     "SUMMER" = list(.7, DAY = c("MORNING", "EVENING"))
#'   )
#' ))
#'
#' make_timetable(list(
#'   "SEASON" = list("WINTER" = .3, "SUMMER" = .7),
#'   "DAY" = c("MORNING", "EVENING")
#' ))
#'
make_timetable <- function(struct = list(ANNUAL = "ANNUAL"),
                           year_fraction = 1, warn = FALSE) {
  # an old version, adjusted for data.table
  # class and content check
  if (inherits(struct, "list")) {
    # check/add ANNUAL
    if (is.null(struct$ANNUAL)) {
      if (warn) warning("Adding `ANNUAL` level to timeframes")
      struct <- c(ANNUAL = "ANNUAL", struct)
    }
    # arg <- unlist(struct)
  } else {
    stop(
      "`struct` should be a named nested list with timeframes and timeslices ",
      "(see examples)"
    )
  }
  # check for duplicates
  nms <- names(struct)
  if (anyDuplicated(nms)) {
    stop(paste('duplicated timeslice levels: "',
      paste(unique(nms[duplicated(nms)]), collapse = '", "'),
      '"',
      sep = ""
    ))
  }
  # create timetable
  dtf <- data.table(share = numeric(), stringsAsFactors = FALSE)
  if (length(struct) == 1 && is.character(struct[[1]]) && length(struct[[1]]) == 1) {
    dtf <- data.table(
      share = year_fraction,
      ANNUAL = struct[[1]],
      stringsAsFactors = FALSE
    )
    if (!is.null(names(struct))) colnames(dtf)[2] <- names(struct)[1]
  } else {
    dtf <- .timeslice_constructor(dtf, struct) # , year_fraction = year_fraction
    if (year_fraction != 1) dtf$share <- dtf$share * year_fraction
  }
  # dtf <- dtf[, c(2:ncol(dtf), 1), drop = FALSE] # arrange columns
  setcolorder(dtf, c(2:ncol(dtf)))
  if (abs(sum(dtf$share) - year_fraction) < 1e-10) {
    dtf$share <- (dtf$share / sum(dtf$share) * year_fraction)
  }

  x <- select(dtf, if_else(ncol(dtf) > 2, 2, 1):share, -share) |>
    tidyr::unite(timeslice)
  dtf <- mutate(dtf, timeslice = x$timeslice, .before = "share")
  .check_timetable(dtf, year_fraction = year_fraction) # check validity
  dtf <- dplyr::arrange(dtf, across(1:timeslice))
  dtf$weight <- 1./year_fraction
  return(dtf)
}


#' Generate a new calendar object from
#'
#' @name newCalendar
#'
#'
#' @param name `r get_slot_doc("calendar", "name")`
#' @param desc `r get_slot_doc("calendar", "desc")`
#' @param timetable `r get_slot_doc("calendar", "timetable")`
#' @param year_fraction `r get_slot_doc("calendar", "year_fraction")`
#' @param year_start `r get_slot_doc("calendar", "year_start")`
#' @param utc_offset_minutes `r get_slot_doc("calendar", "utc_offset_minutes")`
#' @param default_timeframe `r get_slot_doc("calendar", "default_timeframe")`
#' @param misc `r get_slot_doc("calendar", "misc")`
#' @param ... ignored
#'
#' @rdname newCalendar
#' @return an object of class `calendar` with the specified structure.
#'
#' @description
#' Calendars are defined by the structure of timeframes and time-timeslices
#' with shares of time in a year. The structure is represented by a
#' `timetable` data.frame with levels of timeframes in the named columns,
#' and names of individual time-timeslices in every timeframe.
#' The number of rows in `timetable` is equal to the total number
#' of time-timeslices on the lowest level.
#' Every timeframe is a set of timeslices ("timeslices") - a named fragment
#' of time with a year-share. Timeframes have nested structure.
#' A parent may have any number of children, so a level can be irregular
#' (months of 28-31 days above the days of the year). Each timeslice is named
#' by the shortest trailing part of its path of labels that is unique (a day
#' numbered through the year keeps its own label under a month; an hour needs
#' its day), and the lowest level keeps the `timeslice` column of the
#' timetable when it names every row uniquely.
#' \describe{
#'   \item{ANNUAL}{character, annual, the top level of timeframes}
#'   \item{TIMEFRAME2}{character, (optional) first subannual level of timeframes}
#'   \item{TIMEFRAME3}{character, (optional) second subannual level of timeframes}
#'   \item{...}{character, (optional) further subannual levels of timeframes}
#'   \item{timeslice}{character, name of the timeslices used in sets to refer to the lowest level of timeframes. If not specified, will be auto-created with the formula: `{TIMESLICE2}_{TIMESLICE3}...`}
#' }
#'
#' @order 1
#' @export
#'
#' @examples
#' newCalendar()
newCalendar <- function(
    name = "",
    desc = "",
    timetable = NULL,
    year_fraction = 1,
    year_start = list(month = 1L, day = 1L),
    utc_offset_minutes = 0L,
    default_timeframe = NULL,
    misc = list(
      pTimesliceWeight = NULL
    ),
    ...) {
  if (is.data.frame(timetable)) {
    colnames(timetable) <- .rename_slice_compat(colnames(timetable),
                                                "timetable")
  }
  obj <- .init_calendar(timetable = timetable, year_fraction = year_fraction)
  arg <- list(...)
  arg$name <- name
  arg$desc <- desc
  arg$misc <- misc
  if (!is.null(arg$name)) {
    .assert_object_name(arg$name, what = "calendar")
    obj@name <- arg$name
  }
  if (!is.null(arg$desc)) obj@desc <- arg$desc
  if (!is.null(arg$misc)) obj@misc <- arg$misc
  obj@year_start <- .check_year_start(year_start)
  obj@utc_offset_minutes <- .check_utc_offset(utc_offset_minutes)
  if (!is.null(arg$default_timeframe)) {
    if (!(obj@default_timeframe %in% names(obj@timeframes))) {
      stop(
        "The default_timeframe = ", default_timeframe,
        " is inconsistent with timeframes:\n       ",
        paste(names(obj@timeframes), collapse = " ")
      )
    }
    obj@default_timeframe <- arg$default_timeframe
  }
  obj
}


# Model-year anchor ####
# `year_start` places the first day of the model year. A nontrivial anchor makes
# model year `y` span [year_start(y), year_start(y + 1)); the anchored year is
# the STARTING Gregorian year, so Indian "FY 2021-22" is year 2021. The anchor
# is carried and reported only -- it does not drive timeslice-to-timestamp
# alignment, which stays on the calendar year. Rules mirror
# `timescales::calendar_build()` so both packages refuse the same inputs.
.check_year_start <- function(x) {
  if (is.null(x)) return(list(month = 1L, day = 1L))
  if (!is.list(x) || !all(c("month", "day") %in% names(x))) {
    stop("`year_start` must be `list(month = , day = )`.", call. = FALSE)
  }
  m <- suppressWarnings(as.integer(x$month))
  d <- suppressWarnings(as.integer(x$day))
  if (length(m) != 1L || is.na(m) || m < 1L || m > 12L) {
    stop("`year_start$month` must be an integer in 1:12.", call. = FALSE)
  }
  if (length(d) != 1L || is.na(d) || d < 1L || d > 31L) {
    stop("`year_start$day` must be an integer in 1:31.", call. = FALSE)
  }
  list(month = m, day = d)
}

.check_utc_offset <- function(x) {
  if (is.null(x)) return(0L)
  v <- suppressWarnings(as.integer(x))
  if (length(v) != 1L || is.na(v)) {
    stop("`utc_offset_minutes` must be a single integer number of minutes.",
         call. = FALSE)
  }
  v
}

# A calendar serialised before these slots existed does not carry them, and
# `obj@year_start` would raise "no slot of name". Same guard pattern as
# `R/class-config.R` (`methods::.hasSlot`).
.year_start <- function(cal) {
  dflt <- list(month = 1L, day = 1L)
  if (is.null(cal) || !isS4(cal) || !methods::.hasSlot(cal, "year_start")) {
    return(dflt)
  }
  ys <- cal@year_start
  if (!is.list(ys) || !all(c("month", "day") %in% names(ys))) return(dflt)
  ys
}

.utc_offset <- function(cal) {
  if (is.null(cal) || !isS4(cal) ||
      !methods::.hasSlot(cal, "utc_offset_minutes")) {
    return(0L)
  }
  v <- cal@utc_offset_minutes
  if (length(v) != 1L || is.na(v)) 0L else as.integer(v)
}

# TRUE when the anchor is anything other than January 1.
.is_fiscal_year_start <- function(ys) {
  ys <- if (is.list(ys)) ys else .year_start(ys)
  !(identical(as.integer(ys$month), 1L) && identical(as.integer(ys$day), 1L))
}

.print_if_not_empty <- function(x, pref = NULL, suff = NULL) {
  x <- as.character(x)
  msg <- paste0(pref, x, suff)
  if (length(x) != 0) cat(msg, "\n")
}

# print calendar ####
setMethod("print", "calendar", function(x, ...) {
  cat('An object of class "calendar"\n')
  .print_if_not_empty(x@name, "name: ")
  .print_if_not_empty(x@desc, "desc: ")
  ys <- .year_start(x)
  if (.is_fiscal_year_start(ys)) {
    cat(sprintf("year_start: month=%d, day=%d\n",
                as.integer(ys$month), as.integer(ys$day)))
  }
  uo <- .utc_offset(x)
  if (!identical(uo, 0L)) cat("utc_offset_minutes: ", uo, "\n", sep = "")
  printed_timeframes <- lapply(x@timeframes, function(y) {
    if (length(y) <= 10) return(y)
    y <- c(
      head(y, 5),
      # paste0(y[10], "... (", length(y), " total)")
      "...", tail(y, 5), paste0(
      "(", length(y), " total)"
    ))
    paste(y, collapse = ", ")
  })

})


# internal functions ####
# validation of names of individual time-timeslices
.check_timeslice_name <- function(nm) {
  # check / optimize script
  if (any(grep("^[A-z]", nm, invert = TRUE)) ||
    any(gsub("[[:alnum:]]*", "", nm) != "") ||
    anyDuplicated(nm)) {
    n1 <- unique(c(
      grep("^[A-z]", nm, invert = TRUE, value = TRUE),
      nm[(gsub("[[:alnum:]]*", "", nm) != "")]
    ))
    ms1 <- NULL
    ms2 <- NULL
    if (length(n1) != 0) {
      ms1 <- paste('Check timeslice names "',
        paste(n1, collapse = '", "'), '". ',
        sep = ""
      )
    }
    n2 <- unique(nm[duplicated(nm)])
    if (length(n2) != 0) {
      ms2 <- paste('Check timeslice names "',
        paste(n2, collapse = '", "'), '"',
        sep = ""
      )
    }
    ms <- paste(ms1, ms2, sep = "")
    stop(ms)
  }
}

# validation of calendar@timetable
.check_timetable <- function(dtf, year_fraction = 1) {
  # adjusted for data.table & dtplyr
  sl <- select(dtf, timeslice)
  dtf <- select(dtf, -any_of("timeslice")) # to fit "old" check algo
  dtf <- select(dtf, -any_of("weight")) # !!! add check of weights
  # check / optimize the script
  if (ncol(dtf) < 2) {
    stop("time-timeslices data.table must have more than one columns")
  }
  if (colnames(dtf)[ncol(dtf)] != "share") {
    stop("The time-timeslices data.table must have `share` column")
  }
  # rcs <- colnames(dtf)[-ncol(dtf)]
  rcs <- select(dtf, -share) |> colnames()
  if (anyDuplicated(rcs)) {
    stop(paste('duplicated timeslice levels: "',
      paste(unique(rcs[duplicated(rcs)]), collapse = '", "'), '"',
      sep = ""
    ))
  }

  # check length
  fl <- apply(
    # dtf[, -c(1, ncol(dtf)), drop = FALSE],
    select(dtf, -1, -share),
    2, function(x) length(unique(x)) == 1
  )

  if (any(fl)) {
    stop(paste('all timeslice levels except "ANNUAL", ',
      'should have more than one elements, check: "',
      paste(colnames(dtf)[c(FALSE, fl, FALSE)], collapse = '", "'), '"',
      sep = ""
    ))
  }
  if (length(unique(dtf[[1]])) != 1) {
    stop("first timeslice should have only one 'ANNUAL' element")
  }
  rcs <- c(
    apply(select(dtf, -share), 2, function(x) unique(x)),
    recursive = TRUE
  )
  if (anyDuplicated(rcs)) {
    stop(paste('duplicated timeslice names in levels: "',
      paste(unique(rcs[duplicated(rcs)]), collapse = '", "'), '"',
      sep = ""
    ))
  }
  # Check sum == year_fraction
  if (round(sum(dtf$share) - year_fraction, 7) != 0) {
    stop(
      "Sum of timeslice shares must be equal to the given year_fraction = ",
      year_fraction, ", check: ", sum(dtf$share)
    )
  }
  # full year
  ll <- apply(select(dtf, -share), 1, paste, collapse = ".")
  if (anyDuplicated(ll)) {
    stop(paste('duplicated sets in time-timeslices. ("',
      paste(ll[duplicated(ll)], collapse = '", "'), '").',
      sep = ""
    ))
  }
}

# internal function to ??? create timeslices table from a given list with structure
# !!! ToDo: optimize/rewrite for data.table
.timeslice_constructor <- function(dtf, arg) {
  dtf <- as.data.frame(dtf) # doesn't work with data.table - debug/rewrite
  # check / optimize script
  if (is.null(names(arg)) || any(names(arg) == "")) {
    stop(paste("Unnamed arguments: ",
      paste(capture.output(print(arg)), collapse = "\n"),
      sep = "\n"
    ))
  }
  add_val <- function(dtf, val_sh, val_nm) {
    dtf0 <- dtf
    dtf <- dtf[0, , drop = FALSE]
    dtf[[lv]] <- character()
    if (nrow(dtf0) != 0) {
      dtf[1:(nrow(dtf0) * length(val_sh)), ] <- NA
      for (i in 2:ncol(dtf0)) dtf[[i]] <- dtf0[[i]]
      dtf[, lv] <- c(t(matrix(val_nm, length(val_sh), nrow(dtf0))))
      dtf[, "share"] <- dtf0[, "share"] * c(t(matrix(
        val_sh,
        length(val_sh),
        nrow(dtf0)
      )))
    } else {
      dtf[1:length(val_sh), ] <- NA
      dtf[, lv] <- val_nm
      dtf[, "share"] <- val_sh
    }
    dtf
  }
  while (length(arg) != 0) {
    lv <- names(arg)[1]
    dtf[, lv] <- rep(character(), nrow(dtf))
    if (is.character(arg[[1]]) ||
      (!is.null(names(arg[[1]])) &&
        is.numeric(arg[[1]]))) {
      if (is.character(arg[[1]])) {
        val_sh <- rep(1 / length(arg[[1]]), length(arg[[1]]))
        val_nm <- arg[[1]]
      } else {
        val_sh <- arg[[1]]
        val_nm <- names(arg[[1]])
      }
      .check_timeslice_name(val_nm)
      if (any(val_sh <= 0) || round(sum(val_sh), 10) != 1) { # avoiding precision issues on some systems (Mac/M2-Si)
        stop(paste(paste('Check time-timeslice data for level "', lv, '"\n',
          sep = ""
        ), paste(capture.output(print(arg[[1]])), collapse = "\n"), sep = "\n"))
      }
      arg <- arg[-1]
      dtf <- add_val(dtf, val_sh, val_nm)
    } else if (is.list(arg[[1]])) {
      arg2 <- arg[[1]] # arg <- arg[-1]
      if (is.null(names(arg2)) || any(names(arg2) == "")) {
        stop(paste(
          paste('Check time-timeslice data for level "', lv, '"\n',
            sep = ""
          ), paste(capture.output(print(arg[[1]])), collapse = "\n"),
          sep = "\n"
        ))
      }
      if (is.numeric(arg2[[1]])) {
        if (!all(sapply(arg2, is.numeric))) {
          stop(paste(
            paste('Check time-timeslice data for level "', lv, '"\n',
              sep = ""
            ), paste(capture.output(print(arg[[1]])), collapse = "\n"),
            sep = "\n"
          ))
        }
        dtf <- add_val(dtf, c(arg2, recursive = TRUE), names(arg2))
        arg <- arg[-1]
      } else {
        if (!all(sapply(arg2, is.list))) {
          stop(paste(
            paste('Check time-timeslice data for level "', lv, '"\n',
              sep = ""
            ), paste(capture.output(print(arg[[1]])), collapse = "\n"),
            sep = "\n"
          ))
        }
        dtf0 <- dtf
        dtf <- NULL
        arg2 <- arg[[1]]
        for (i in seq(length.out = length(arg2))) {
          dtf1 <- .timeslice_constructor(add_val(
            dtf0, arg2[[i]][[1]],
            names(arg2)[i]
          ), arg2[[i]][-1])
          if (i == 1) {
            dtf <- dtf1
          } else {
            if (ncol(dtf) != ncol(dtf1) || any(colnames(dtf) != colnames(dtf1))) {
              stop(paste("Set of timeslice have to be the same for all ",
                "(check list timeslice arguments).",
                sep = ""
              ))
            }
            dtf <- rbind(dtf, dtf1)
          }
        }
        arg <- arg[-1]
      }
    } else {
      stop(paste('Unknown type of argument for timeslice level "', lv, '"',
        sep = ""
      ))
    }
  }
  as.data.table(dtf)
}

# internal function to populate all slots of `calendar` from given calendar@timetable
.complete_calendar <- function(obj, year_fraction = 1, ref = NULL) {
  if (nrow(obj@timetable) == 0) {
    warning('no timeslices desc, using default: "ANNUAL"')
    obj@timetable <- make_timetable()
  } else if (is.null(obj@timetable$weight)) {
    obj@timetable <- mutate(
      obj@timetable,
      weight = 1 / sum(obj@timetable$share)
    )
  }
  # validate the timetable
  .check_timetable(obj@timetable, year_fraction = year_fraction)
  # obj@misc <- list()
  dtf <- obj@timetable |> select(-any_of(c("timeslice")))

  # timeframe_rank / levels
  d <- select(dtf, -any_of(c("share", "year", "timeslice", "weight")))
  obj@timeframe_rank <- 1:ncol(d)
  names(obj@timeframe_rank) <- colnames(d)

  # number of timeslices on every level
  obj@timeslices_in_frame <- sapply(d, function(x) length(unique(x)))

  # The calendar is built from the timetable's rows, so a level may have a
  # different number of children under each parent (months of 28-31 days).
  # `node` holds, per row, the name of the timeslice the row belongs to at
  # every level.
  fnames <- colnames(d)
  nframes <- length(fnames)
  if (nframes == 0) stop("Empty timeframes / timeslices")
  node <- .calendar_nodes(as.data.frame(obj@timetable), fnames, ref = ref)

  # share of every timeslice in a year
  # Timeframe contract: the top (ANNUAL) slice is FULL-YEAR magnitude --
  # share = weight = 1 regardless of sampling -- while sub-annual slices
  # keep their true duration shares (summing to year_fraction) and weight
  # 1/year_fraction. Sums crossing into ANNUAL annualize via
  # pTimesliceAgg = weight[child]/weight[parent] = 1/year_fraction; every
  # sub-annual level keeps sum(share * weight) == 1.
  shares <- list(data.table(timeslice = node[1, 1], share = 1, weight = 1))
  for (i in seq_len(nframes)[-1]) {
    # ROW-ORDER grouping: a bare tapply sorts groups alphabetically, which
    # silently reorders any vocabulary that does not collate
    # chronologically (e.g. seasons WIN/SPR/SUM/FAL) -- and
    # `@next_in_year` (full-year storage) is derived from this order.
    # The timetable's row order IS the calendar's chronology.
    timeslice_names <- factor(node[, i], levels = unique(node[, i]))
    # share-weighted mean of the rows' weights: a parent's weight must not
    # depend on how many children it has (months of 28-31 days)
    sh <- tapply(dtf$share, timeslice_names, sum)
    wh <- tapply(dtf$share * dtf$weight, timeslice_names, sum) / sh
    wh <- wh / sum(wh * sh)
    shares[[i]] <- data.table(timeslice = names(sh), share = as.numeric(sh),
                              weight = as.numeric(wh))
  }
  obj@timeslice_share <- rbindlist(shares)

  # @structure
  if (nframes == 1) {
    obj@timeframes <- list()
    obj@timeframes[fnames[1]] <- fnames[1]
  } else {
    obj@timeframes <- lapply(seq_len(nframes), function(i) unique(node[, i]))
  }
  names(obj@timeframes) <- fnames

  obj@default_timeframe <- colnames(d)[ncol(d)]

  # @timeslice_share$timeslice
  # obj@timeslice_share$timeslice <- obj@timeslice_share$timeslice

  # @timeslice_family
  if (nrow(obj@timetable) == 1) {
    obj@timeslice_family <- obj@timeslice_family[0, , drop = FALSE]
    obj@timeslice_ancestry <- obj@timeslice_ancestry[0, , drop = FALSE]
  } else {
    # parent-child pairs level by level; children stay grouped under their
    # parent in chronological order, which `@next_in_timeframe` relies on
    obj@timeslice_family <- do.call(rbind, lapply(
      seq_len(nframes - 1),
      function(i) {
        x <- unique(data.frame(parent = node[, i], child = node[, i + 1],
                               stringsAsFactors = FALSE))
        x[order(match(x$parent, unique(x$parent))), , drop = FALSE]
      }
    ))
    rownames(obj@timeslice_family) <- NULL
    # @timeslice_ancestry
    tmp <- obj@timeslice_family
    tmp$nlev <- NA
    for (i in seq_along(obj@timeframes)) {
      tmp$nlev[tmp$parent %in% obj@timeframes[[i]]] <- i
    }
    ll <- tmp[tmp$nlev + 1 == length(obj@timeframes), -3]
    for (i in rev(seq_along(obj@timeframes))[-(1:2)]) {
      gg <- tmp[tmp$nlev == i, -3]
      g3 <- gg
      colnames(gg)[2] <- "sht"
      l2 <- ll
      colnames(l2)[1] <- "sht"
      g2 <- merge(gg, l2)
      g2$sht <- NULL
      ll <- rbind(ll, g2, g3)
    }
    obj@timeslice_ancestry <- ll
  }
  # next timeslice in the same nest & in a year
  # obj@timeslices_in_frame <- NULL
  if (nrow(obj@timetable) != 1) {
    tmp <- obj@timeslice_family
    tmp$next_timeslice <- NA
    j <- 1
    for (i in 1:(nrow(tmp) - 1)) {
      if (tmp$parent[i] == tmp$parent[i + 1]) {
        tmp$next_timeslice[i] <- tmp$child[i + 1]
      } else {
        tmp$next_timeslice[i] <- tmp$child[j]
        j <- i + 1
      }
      # if (tmp[i, "parent"] == tmp[i + 1, "parent"]) {
      #   tmp[i, "next_timeslice"] <- tmp[i + 1, "child"]
      # } else {
      #   tmp[i, "next_timeslice"] <- tmp[j, "child"]
      #   j <- i + 1
      # }
    }
    tmp$next_timeslice[i + 1] <- tmp$child[j]
    obj@next_in_timeframe <- data.table(
      timeslice = tmp$child, timeslicep = tmp$next_timeslice,
      stringsAsFactors = FALSE
    )
    n1 <- c(lapply(obj@timeframes[-1], function(x) x), recursive = TRUE)
    names(n1) <- NULL
    n2 <- c(lapply(obj@timeframes[-1], function(x) c(x[-1], x[1])),
            recursive = TRUE)
    names(n2) <- NULL
    obj@next_in_year <- data.table(
      timeslice = n1,
      timeslicep = n2,
      stringsAsFactors = FALSE
    )
  }
  obj@year_fraction <- year_fraction
  obj@timeslice_family <- as.data.table(obj@timeslice_family)
  obj@timeslice_ancestry <- as.data.table(obj@timeslice_ancestry)
  obj@next_in_timeframe <- as.data.table(obj@next_in_timeframe)
  obj@next_in_year <- as.data.table(obj@next_in_year)
  obj
}

# Name of the timeslice each timetable row belongs to, at every level.
# A timeslice at level i is the path of labels from level 2 down to i. Its
# name is the shortest trailing part of that path that is still unique
# (so a day numbered through the year keeps its own label under a month,
# while an hour needs its day). In a regular calendar every label repeats
# under each parent, so this is the full path joined by "_", as before.
# The lowest level takes the timetable's `timeslice` column when it names
# every row uniquely. With `ref` (the timetable of the calendar the rows were
# taken from) the names are those of `ref`, so a sample keeps the full
# calendar's names even where a shorter label would be unique in the sample.
.calendar_nodes <- function(tt, frames, ref = NULL) {
  n <- nrow(tt)
  nfr <- length(frames)
  if (!is.null(ref)) {
    idx <- match(as.character(tt$timeslice), as.character(ref$timeslice))
    if (anyNA(idx)) {
      stop("Timeslices not in the reference calendar: ",
           paste(utils::head(tt$timeslice[is.na(idx)], 4), collapse = ", "),
           call. = FALSE)
    }
    out <- .calendar_nodes(as.data.frame(ref), frames)[idx, , drop = FALSE]
  } else {
    out <- .calendar_node_names(tt, frames)
  }
  for (i in seq_len(nfr)[-1]) {
    # row order is the calendar's chronology: a timeslice's rows must be
    # contiguous, or the successor chains would jump between parents
    r <- rle(out[, i])$values
    if (anyDuplicated(r)) {
      stop("Timetable row order breaks the calendar's chronology: the rows of ",
           frames[i], " '", r[duplicated(r)][1], "' are not contiguous. ",
           "Rows must run in time order (a structural requirement; ",
           "hour-major order is the usual cause).", call. = FALSE)
    }
  }
  nms <- unlist(lapply(seq_len(nfr), function(i) unique(out[, i])))
  if (anyDuplicated(nms)) {
    stop("Timeslice names repeat across timeframes: \"",
         paste(unique(nms[duplicated(nms)]), collapse = "\", \""), "\"",
         call. = FALSE)
  }
  out
}

.calendar_node_names <- function(tt, frames) {
  n <- nrow(tt)
  nfr <- length(frames)
  lab <- lapply(frames, function(f) as.character(tt[[f]]))
  out <- matrix(NA_character_, n, nfr, dimnames = list(NULL, frames))
  out[, 1] <- lab[[1]]
  for (i in seq_len(nfr)[-1]) {
    path <- do.call(paste, c(lab[2:i], sep = "_"))
    np <- length(unique(path))
    nm <- path
    if (i == nfr && !is.null(tt$timeslice) &&
        !anyDuplicated(tt$timeslice) && np == n) {
      nm <- as.character(tt$timeslice)
    } else {
      for (s in i:2) {
        cand <- do.call(paste, c(lab[s:i], sep = "_"))
        if (length(unique(cand)) == np) {
          nm <- cand
          break
        }
      }
    }
    out[, i] <- nm
  }
  out
}

# initialize calendar object from given list ("struct") or "timetable"
.init_calendar <- function(struct = NULL, timetable = NULL, year_fraction = 1) {
  tsl <- new("calendar")
  if (is.null(timetable)) {
    if (is.null(struct)) {
      tsl@timetable <- make_timetable()
    } else {
      tsl@timetable <- make_timetable(struct)
    }
  } else if (!is.null(struct)) {
    stop("Only one parameter `struct` or `timetable` can be specified")
  } else {
    tsl@timetable <- timetable
  }
  .complete_calendar(tsl, year_fraction = year_fraction)
}


#### migrated from class-timeslice ####
# the functions below to be review/rewritten






# ToDo: write methods: ####
## `add` ####
## `update` ####

