# Saved on disk scenario and model objects have the same structure as in memory  objects. The only difference is that data-frame slots are saved in `parquet`  format, while other "large" slots are saved in `RData` format.  Saved on disk objects have the same structure of directories and files as in  memory objects. The in-memory object stores the information about the path to  each slot on disk, the dimensions of the data-frame slots, the file format, and the file name. This information is stored in the `@misc` slot of the in-memory object. The `inMemory` slot of the object is set to `FALSE` to indicate that the object is saved on disk. The scenario or model object itself with stored  on disk slots is saved in the same directory as `scen.RData` or `mod.RData`. The access to the saved on disk slots is provided by the `getData` function. (toDo: add getSlot function and/or `slot` method)
# The structure of the information stored in the `@misc` slot of the in-memory part of an object is a nested `list`, where every level corresponds to a directory. The last level of the nested list contains the information about the file format, the file name, and the dimensions of the data-frame slots or length of the vector slot.


#' Save scenario object on disk in parquet format using `arrow` package.
#'
#' @param object scenario object.
#' @param path character. Path to scenario directory.
#' @param embed_model `NULL` (default), `TRUE`, or `FALSE`. Controls whether
#'   the model is embedded in the saved scenario or referenced from the model
#'   store (see [save_model()]). `NULL`: reference the store entry, saving the
#'   model to the store first when nothing is stored under that name; embed
#'   when the name is taken by different content (store entries update in
#'   place, so writing would replace the version other scenarios reference).
#'   `TRUE`: always embed (self-contained folder). `FALSE`: require an
#'   existing store hit, error otherwise, and never write to the store.
#'   A referenced save stores only `{name, hash, path}`; [load_scenario()]
#'   resolves it back via the registry / model store.
#' @param embed_datasets the same choice for the big data tables and maps —
#'   the geoscale on `@settings` and, when the model is embedded, its
#'   geoscale and its repositories' weather/demand tables (see
#'   [save_dataset()]). `NULL` (default) references whatever identical
#'   content is already in the dataset store; `TRUE` always embeds; `FALSE`
#'   requires a store hit.
#' @param format file format (currently `parquet` only, arrow or feather will be implemented in further releases).
#' @param overwrite logical. Overwrite existing scenario directory.
#' @param clean_start logical. Clean scenario directory before saving.
#' @param write_log logical. Write (update) logfile.
#' @param verbose logical. Print messages.
#'
#' @details
#' This is the only writer of a run's `modOut/` store: [read_solution()] leaves
#' the solution in memory, and without a save it does not survive the session.
#' The store is written for the ACTIVE run — whichever `@misc$run` names — so
#' saving while one run is active does not persist another's solution.
#' [import_solution()] does the read and the save in one call.
#'
#' @return scenario object with most of the slots saved on disk.
#' @export
#'
#' @examples
#' \dontrun{
#' scen_BASE@path # check the scenarion directory
#' scen_BASE <- save_scenario(scen_BASE) # saving in the default directory
#' }
save_scenario <- function(
    object,
    path = object@path,
    embed_model = NULL,
    embed_datasets = NULL,
    format = get_storage_format(),
    overwrite = TRUE,
    clean_start = FALSE,
    write_log = TRUE,
    verbose = TRUE) {
  # On-disk STORAGE format. feather/IPC and parquet are both compressible and
  # both support lazy, filtered reads through open_dataset(); they trade off
  # differently -- parquet is smaller, feather reads faster. "arrow" and "ipc"
  # are aliases for feather; "csv" stays csv.
  format <- if (tolower(format) %in% c("arrow", "ipc")) {
    "feather"
  } else {
    tolower(format)
  }
  # identify directories
  if (is.null(path)) {
    object@path <- fp(get_scenarios_path(), object@name)
    message("Scenarios directory: ", object@path)
  } else {
    object@path <- path
  }

  # a sealed scenario is an archive: no rewrites (see ?seal_scenario)
  .scenario_seal_guard(object)

  # An on-disk scenario (interpolate_model(ondisk = TRUE)) already has its
  # parameter stores in place, in whatever codec `storage_format` was when they
  # were written — but the thin object, the layout markers, the manifest, and
  # the registry row still need writing, otherwise the folder has data and no
  # `object.RData` and load_scenario() fails. So an on-disk scenario skips only
  # the obj2disk() data walk below, never the shell.
  ondisk_data <- isOnDisk(object)

  # Model reference vs embedding. `embed_model = NULL` (auto): reference the
  # model store entry, putting the model there first when the store has
  # nothing under that name (see save_model()); embed when the name is taken
  # by different content, since store entries update in place and writing
  # would replace the version other scenarios reference. TRUE forces
  # embedding; FALSE requires an existing store hit and never writes. A
  # referenced save replaces the model in the SAVED copy with a stub carrying
  # `misc$model_ref`; the returned in-memory object keeps its model.
  model_ref <- NULL
  model_hash_ <- ""
  if (!isTRUE(embed_model) && nzchar(object@model@name %||% "")) {
    model_hash_ <- tryCatch(model_hash(object@model), error = function(e) "")
    store_dir <- if (nzchar(model_hash_)) {
      tryCatch(.model_store_resolve(object@model@name, model_hash_),
               error = function(e) NULL)
    }
    if (is.null(store_dir) && is.null(embed_model)) {
      # The auto-store happens HERE, before obj2disk() below thins the model:
      # model_hash() hashes content, so a thinned model hashes differently
      # from its in-memory original and would be stored under one hash and
      # referenced by another.
      st <- .model_autostore(object@model, format = format, verbose = verbose)
      if (!is.null(st)) {
        model_hash_ <- st$hash
        store_dir <- st$path
      }
    }
    if (!is.null(store_dir)) {
      model_ref <- list(name = object@model@name, hash = model_hash_,
                        source = "ref",
                        path = .registry_rel_path(store_dir))
    } else if (isFALSE(embed_model)) {
      stop("embed_model = FALSE, but model '", object@model@name, "' (",
           substr(model_hash_, 1, 8), ") is not in the model store ('",
           get_models_path(), "'). save_model() it first, or use ",
           "embed_model = NULL/TRUE.")
    }
  }
  full_model <- NULL
  if (!is.null(model_ref)) {
    full_model <- object@model
    stub <- new("model")
    stub@name <- object@model@name
    stub@misc$model_ref <- model_ref
    object@model <- stub
    if (verbose) {
      cat("Model '", model_ref$name, "' referenced from the store (",
          substr(model_ref$hash, 1, 8), "), not embedded\n", sep = "")
    }
  }

  # Dataset references (see save_dataset()): the geoscale map on @settings
  # and — when the model is EMBEDDED — the model's own geoscale and its
  # repositories' big tables become {name, hash} refs when the identical
  # content is in the dataset store. A referenced model resolves its own
  # datasets when its store entry loads.
  ds_entries <- list()
  full_settings_gs <- NULL
  model_ds_backup <- NULL
  if (!isTRUE(embed_datasets)) {
    th <- .thin_dataset_slot(object@settings, embed_datasets, id = "settings",
                             verbose = verbose)
    if (!is.null(th$entry)) {
      object@settings <- th$obj
      ds_entries[[length(ds_entries) + 1L]] <- th$entry
      full_settings_gs <- th$full
    }
    if (is.null(model_ref) && is(object@model, "model")) {
      model_backup <- object@model   # captured BEFORE any thinning
      touched_model <- FALSE
      mth <- .thin_dataset_slot(object@model@config, embed_datasets,
                                id = "config", verbose = verbose)
      if (!is.null(mth$entry)) {
        object@model@config <- mth$obj
        ds_entries[[length(ds_entries) + 1L]] <- mth$entry
        touched_model <- TRUE
      }
      for (rp in names(object@model@data)) {
        repo <- object@model@data[[rp]]
        if (!is(repo, "repository") || !is.null(repo@misc[["repo_ref"]])) next
        for (ob in names(repo@data)) {
          th2 <- .thin_dataset_slot(repo@data[[ob]], embed_datasets, id = ob,
                                    verbose = verbose)
          if (!is.null(th2$entry)) {
            repo@data[[ob]] <- th2$obj
            ds_entries[[length(ds_entries) + 1L]] <- th2$entry
            touched_model <- TRUE
          }
        }
        object@model@data[[rp]] <- repo
      }
      if (touched_model) model_ds_backup <- model_backup
    }
  }

  # sourceCode blocks identical to the package's own templates are dropped
  # from the saved copy (~0.5 MB per scenario) and restored from the current
  # package on load; user-overridden blocks fail the identity test and are
  # kept verbatim.
  sourceCode_full <- object@settings@sourceCode
  if (length(sourceCode_full)) {
    same <- vapply(
      names(sourceCode_full),
      function(k) identical(sourceCode_full[[k]], .modelCode[[k]]),
      logical(1)
    )
    if (any(same)) {
      object@settings@sourceCode[names(sourceCode_full)[same]] <- NULL
      object@misc$sourceCode_default <- names(sourceCode_full)[same]
    }
  }

  .t_start <- proc.time()[["elapsed"]]
  # clean directories
  if (clean_start) {
    if (verbose) message("Cleaning directory '", object@path, "'")
    if (write_log) {
      ff <- list.files(object@path, include.dirs = TRUE)
      ff <- ff[!(ff == "logfile.csv")]
      clear_status <- unlink(fp(object@path, ff),
        recursive = TRUE,
        force = TRUE
      )
      if (clear_status != 0) {
        stop(
          "Cannot delete content of'", object@path,
          "' directory"
        )
      }
      rm(ff)
    } else {
      clear_status <- unlink(fp(object@path),
        force = TRUE,
        recursive = TRUE
      )
      if (clear_status != 0) stop("Cannot delete '", object@path, "' directory")
    }
  }

  # create scenario directories
  if (!dir.exists(object@path)) {
    if (verbose) cat("Creating directory '", object@path, "'\n")
    dir.create(object@path, recursive = TRUE)
  }

  # write format and log
  format_file <- fp(object@path, "format")
  write(format, format_file, append = FALSE)
  class_file <- fp(object@path, "class")
  write(class(object), class_file, append = FALSE)
  # Directory-layout version. Bumped to 2 when `modOut@variables` became a list
  # of `variable` objects, moving each variable's data from
  # `variables/<v>/` down to `variables/<v>/data/`. Without the marker, new code
  # reading an old directory finds no `data/` sub-directory, and
  # `get_lazy_data()` returns NULL rather than erroring -- every result would
  # silently come back empty.
  write(as.character(.SCENARIO_LAYOUT), fp(object@path, "layout"), append = FALSE)
  log_file <- (fp(object@path, "logfile.csv"))
  write(paste(lubridate::now(tzone = "UTC"), "format", format, sep = ","),
    file = log_file, append = TRUE
  )

  if (!ondisk_data) {
    if (verbose) {
      cat("Saving large slots of scenario object",
        " '", object@name, "' ", "on disk\n",
        sep = ""
      )
    }
    # Layout 3: the solution store belongs to its run — with an active run,
    # modOut is written under runs/[<variant>/]<solve>/modOut instead of the
    # top-level modOut/ (which remains the fallback for solved scenarios that
    # predate run records, e.g. loaded from layout 2). An OWN-PROBLEM VARIANT
    # additionally owns its modInp: the store goes to runs/<variant>/modInp/
    # (the scenario-level modInp/ stays the base problem's), plus the
    # variant.yml manifest and the problem swap file. The base problem gets
    # its symmetric swap file <object>/problem.RData, enabling
    # read_solution(run=) to switch problems in both directions.
    run_label <- object@misc$run %||% ""
    active_variant <- .run_variant(object)
    mo <- NULL
    if (nzchar(run_label)) {
      mo <- object@modOut
      object@modOut <- new("modOut") # keep the main walk off the modOut slot
    }
    mi <- NULL
    if (nzchar(active_variant)) {
      mi <- object@modInp
      object@modInp <- new("modInp") # keep the main walk off the modInp slot
    }
    object <- obj2disk(
      object,
      path = object@path,
      format = format,
      verbose = verbose,
      min_rows = getOption("energyRt.ondisk_min_rows", 1e5)
    )
    if (!is.null(mi)) {
      object@modInp <- obj2disk(
        mi,
        path = fp(object@path, "runs", active_variant, "modInp"),
        format = format,
        verbose = verbose
      )
    }
    if (!is.null(mo)) {
      .mo_path <- fp(.run_dir(object, active_variant, run_label), "modOut")
      # `read_solution(ondisk = TRUE)` already streamed the solution into this
      # store; its data slots are empty, so re-running the walk would write
      # nothing and record dim-0 bookkeeping over a complete store.
      object@modOut <- if (isOnDisk(mo) &&
                         identical(gsub("[\\/]+", "/", getObjPath(mo) %||% ""),
                                   gsub("[\\/]+", "/", .mo_path))) {
        mo
      } else {
        obj2disk(mo, path = .mo_path, format = format, verbose = verbose)
      }
    }
    # swap file for the ACTIVE problem (variant.RData / problem.RData)
    .write_problem_swap(object, object@modInp)
  } else {
    if (verbose) {
      cat("Scenario data already on disk; refreshing the scenario shell ",
          "(scen.RData, manifest, registry)\n", sep = "")
    }
    # The data walk is skipped, but a solve AFTER an ondisk interpolation
    # leaves the solution in memory — park it into its run store so the thin
    # object.RData stays thin.
    if (nzchar(.run_variant(object))) {
      # A re-save of an already-stored variant is fine (its modInp store sits
      # under the variant dir). What is NOT supported is a variant problem
      # whose store was written to the scenario level by
      # interpolate_model(ondisk = TRUE) — that location belongs to the base.
      mi_path <- gsub("[\\/]+", "/", getObjPath(object@modInp) %||% "")
      expected <- gsub("[\\/]+", "/", .problem_modinp_root(object))
      if (!identical(mi_path, expected)) {
        stop("Own-problem variants of an ondisk-interpolated scenario are ",
             "not supported yet: interpolate_model(ondisk = TRUE) writes ",
             "the parameter store to the scenario level, which belongs to ",
             "the base problem. Interpolate the variant's problem in memory.")
      }
    }
    # interpolate_model(ondisk = TRUE) leaves @modOut NULL (prototype);
    # only a materialized in-memory solution needs parking
    if (!is.null(object@modOut) && !isOnDisk(object@modOut) &&
        length(object@modOut@variables)) {
      run_label <- object@misc$run %||% ""
      modout_path <- if (nzchar(run_label)) {
        fp(.run_dir(object, .run_variant(object), run_label), "modOut")
      } else {
        fp(object@path, "modOut")
      }
      object@modOut <- obj2disk(
        object@modOut,
        path = modout_path,
        format = format,
        verbose = verbose
      )
    }
    .write_problem_swap(object, object@modInp)
  }
  # object.RData is the BASE problem's one and only home (problem.RData is
  # retired): with the base problem active the shell is (re)written from
  # the in-memory object; with a VARIANT active the existing shell is left
  # untouched — the variant's problem lives in its own variant.RData, and
  # the base shells must never be overwritten by a variant's. A
  # variant-born scenario (no base problem ever materialized) writes a
  # shell flagged `misc$has_base = FALSE`, so a later swap to base errors
  # informatively instead of restoring garbage.
  scen_shell_path <- fp(object@path, "scen.RData")
  if (!nzchar(.run_variant(object))) {
    object@misc$has_base <- TRUE
    save(object, file = scen_shell_path)
  } else if (!file.exists(scen_shell_path)) {
    e_born <- new.env(parent = emptyenv())
    e_born$scen <- object
    e_born$scen@misc$variant <- NULL
    e_born$scen@misc$run <- NULL
    e_born$scen@misc$has_base <- FALSE
    e_born$scen@modInp <- new("modInp")
    e_born$scen@modOut <- new("modOut")
    save(list = "scen", envir = e_born, file = scen_shell_path)
    rm(e_born)
  }
  mf_model <- model_ref %||% list(
    name = object@model@name %||% "",
    hash = model_hash_,
    source = "embedded"
  )
  .write_scenario_manifest(object, format, model = mf_model,
                           datasets = if (length(ds_entries)) ds_entries)
  .registry_record_scenario(object)
  # the returned in-memory object keeps its full model, datasets & sourceCode
  if (!is.null(full_model)) object@model <- full_model
  if (!is.null(model_ds_backup)) object@model <- model_ds_backup
  if (!is.null(full_settings_gs)) {
    object@settings@geoscale <- full_settings_gs
    object@settings@misc[["dataset_ref"]] <- NULL
  }
  object@settings@sourceCode <- sourceCode_full
  cat("Scenario '", object@name, "' saved in '", object@path, "'\n", sep = "")
  dirsize <- dir_size(object@path)
  cat("Directory size: ", round(dirsize / 1024^2, 2), " MB\n", sep = "")
  object@misc$dirsize <- dirsize
  if (verbose) {
    cat(sprintf("save_scenario: %.2f sec elapsed\n",
                proc.time()[["elapsed"]] - .t_start))
  }
  return(invisible(object))
}


# mem2disk
# mem_to_disk
# disk2mem

# Target rows per row group (parquet) / record batch (feather) when writing a
# store. arrow's own default is one group per incoming batch, which for a
# data.table is 32,768 rows regardless of table size; see the note at the
# write_dataset() calls below for what that costs.
.EN_ROWS_PER_GROUP <- 1000000L

# Compression codec for feather/IPC datasets. `write_dataset(format = "feather")`
# takes a Codec object as `codec`, not the `compression` string parquet uses;
# passing the string errors. Falls back to no compression when the codec is
# unavailable in this arrow build.
.en_ipc_codec <- function(compression, level = NULL) {
  cmp <- tolower(compression)
  if (identical(cmp, "lz4")) cmp <- "lz4_frame"
  z <- try(if (is.null(level) || identical(cmp, "lz4_frame")) {
    arrow::Codec$create(cmp)
  } else {
    arrow::Codec$create(cmp, compression_level = as.integer(level))
  }, silent = TRUE)
  if (inherits(z, "try-error")) {
    warning("arrow codec '", compression, "' unavailable; writing uncompressed",
            call. = FALSE)
    return(NULL)
  }
  z
}

data2disk <- function(
    obj,
    path = NULL,
    format = get_storage_format(),
    compression = get_storage_compression(),
    compression_level = get_storage_compression_level(),
    verbose = FALSE) {
  # saves certain type of data to disk, returns TRUE if saved, FALSE if not
  if (is.null(path)) path <- getObjPath(obj)
  stopifnot(!is.null(path))
  # dir.create(path, recursive = TRUE, showWarnings = FALSE)
  # obj_class <- class(obj)

  # One writer for both shapes: an atomic vector becomes a one-column table
  # named after the slot. It used to be written as csv unconditionally, which
  # put csv files in a store whose other slots were feather/parquet -- a
  # directory arrow refuses to open as one dataset.
  if (inherits(obj, c("character", "numeric", "logical")) &&
      !inherits(obj, "data.frame")) {
    obj <- as.data.table(obj)
    data.table::setnames(obj, old = "obj", new = basename(path))
  }
  if (inherits(obj, "data.frame")) {
    obj <- as.data.table(obj)
    obj_class <- class(obj)
    # if (verbose) cat(path, format, "\n")
    if (anyDuplicatedSets(obj)) obj <- rename_duplicated_sets(obj)
    dir.create(path, recursive = TRUE, showWarnings = FALSE)
    # Compression is spelled differently per format: parquet takes
    # `compression` + `compression_level`, feather/IPC takes a `codec` object.
    # csv takes neither.
    .cmp <- !identical(tolower(compression), "uncompressed")
    # Row group size is load-bearing and the default is wrong. write_dataset()
    # emits ONE ROW GROUP PER RECORD BATCH, and a data.table reaches arrow in
    # 32,768-row batches, so every table written here was split into ~32k-row
    # groups however large it was. Each group repeats the dictionary and
    # carries its own statistics, and a group that small often spans a single
    # run of a sorted key, which makes its dictionary 1:1 and useless.
    # Measured on a 2.9M-row hourly table: 33.1 MB at the default against
    # 15.1 MB here, and 1.95x across a 49 MB set. The same argument applies to
    # feather, where a row group is a record batch.
    if (format == "parquet" && .cmp) {
      arrow::write_dataset(obj, path = path, format = "parquet",
                           compression = compression,
                           compression_level = as.integer(compression_level),
                           min_rows_per_group = .EN_ROWS_PER_GROUP,
                           max_rows_per_group = 2L * .EN_ROWS_PER_GROUP)
    } else if (format %in% c("feather", "arrow", "ipc") && .cmp) {
      arrow::write_dataset(obj, path = path, format = "feather",
                           codec = .en_ipc_codec(compression, compression_level),
                           min_rows_per_group = .EN_ROWS_PER_GROUP,
                           max_rows_per_group = 2L * .EN_ROWS_PER_GROUP)
    } else {
      arrow::write_dataset(obj, path = path, format = format)
    }
    # write(format, file = fp(path, "format"), append = FALSE)
    # write(obj_class, file = fp(path, "class"), append = FALSE)
    return(invisible(TRUE))
  }
  return(FALSE)
}

obj2disk <- function(
    obj,
    path = NULL,
    format = get_storage_format(),
    save_not_S4 = FALSE,
    force_save = FALSE,
    verbose = FALSE,
    delay = 0,
    min_rows = 0L) {
  # `min_rows`: a table with fewer rows stays in the object (and so in its
  # .RData) instead of getting a file of its own. Writing one small file per
  # slot of every model object is what made saving a large model take half an
  # hour; save_scenario() and save_model() pass
  # getOption("energyRt.ondisk_min_rows"). The default 0 keeps every non-empty
  # table on disk, which callers that empty the slot afterwards rely on.
  Sys.sleep(delay)
  # identifies which slots of S4 obj are savable,
  # proceeds with saving and wiping the saved slots with marks in @misc
  if (is.null(path)) path <- getObjPath(obj)
  stopifnot(!is.null(path))
  # dir.create(path, recursive = TRUE, showWarnings = FALSE)
  # obj_class <- class(obj)
  # if (inherits(obj, "list")) browser()
  # if (inherits(obj, "modOut")) browser()
  # if (inherits(obj, "weather")) browser()
  if (isOnDisk(obj)) {
    # stopifnot(dir.exists(path))
    # return(obj)
    if (!dir.exists(path)) {
      dir.create(path, recursive = TRUE, showWarnings = FALSE)
    }
  }
  isSaved <- FALSE
  if (isS4(obj)) {
    cl <- class(obj)[1]
    obj <- set_ondisk_slots(obj)
    ondsk <- get_ondisk_slots(obj)
    stopifnot(all(ondsk %in% slotNames(obj)))
    for (s in ondsk) { # slots to save
      if (isS4(slot(obj, s))) {
        # cat("slot ", s, ": \n", sep = "")
        slot(obj, s) <- obj2disk(
          slot(obj, s),
          path = fp(path, s),
          format = format,
          verbose = verbose,
          min_rows = min_rows
        )
        if (isOnDisk(slot(obj, s))) isSaved <- TRUE
      } else if (inherits(slot(obj, s), "list")) {
        # list of S4s (repo@data, modInp@parameters) or data.frames, ...
        if (inherits(obj, "repository")) {
          # cat("repository: '", obj@name, "'\n", sep = "")
          if (verbose) cat("model@data[['", obj@name, "']]\n", sep = "")
        } else if (inherits(obj, "model")) {
          # cat("model@data[['", s, "']]: \n", sep = "")
        } else {
          if (verbose) cat(cl, "@", s, "\n", sep = "")
        }
        # cat(cl, "@", s, ": \n", sep = "")
        nm <- names(obj@misc$onDisk[[s]])
        # dim_list <- vector("list", length(nm)); names(dim_list) <- nm
        # dim_list <- list()
        if (is(obj, "model") & s == "data") {
          make_progress_bar <- FALSE
        } else {
          if (verbose) {
            make_progress_bar <- TRUE
          } else {
            make_progress_bar <- FALSE
          }
        }
        if (make_progress_bar) p <- progressr::progressor(along = nm)
        for (i in nm) { # loop over list
          if (make_progress_bar) p(i)
          if (isS4(slot(obj, s)[[i]])) { # list of S4
            # cat("\n", s, i, "\n")
            slot(obj, s)[[i]] <- obj2disk(
              slot(obj, s)[[i]],
              path = fp(path, s, i),
              save_not_S4 = TRUE,
              format = format,
              verbose = verbose,
              min_rows = min_rows
            )
            # if (inherits(obj, "weather")) browser()
            if (isOnDisk(slot(obj, s)[[i]])) isSaved <- TRUE
          } else { # call data2disk for not S4 elements
            # if (i == "vObjective") browser()
            if (any(obj@misc$onDisk[[s]][[i]]$class %in% "data.frame")) {
              save_i <- obj@misc$onDisk[[s]][[i]]$dim[1] >= max(1L, min_rows)
            } else {
              save_i <- obj@misc$onDisk[[s]][[i]]$length >= max(1L, min_rows)
            }
            if (isTRUE(save_i)) {
              xs <- data2disk(
                # !!! check why not all data.frames are data.tables
                obj = as.data.table(slot(obj, s)[[i]]),
                path = fp(path, s, i),
                format = format,
                verbose = verbose
              )
              if (xs) {
                isSaved <- TRUE
                # dim_list[[i]] <- dim(slot(obj, s)[[i]])
                slot(obj, s)[[i]] <- reset_slot(slot(obj, s)[[i]])
                # slot(obj, s) <- setObjPath(slot(obj, s),
                # path = fp(path, s))
              }
            }
          }
        }
        # save dim_list
      } else { # obj@s slot is not S4
        if (any(obj@misc$onDisk[[s]]$class %in% "data.frame")) {
          save_i <- obj@misc$onDisk[[s]]$dim[1] >= max(1L, min_rows)
        } else {
          save_i <- obj@misc$onDisk[[s]]$length >= max(1L, min_rows)
        }
        if (isTRUE(save_i)) {
          xs <- data2disk(
            obj = slot(obj, s),
            path = fp(path, s),
            format = format,
            verbose = verbose
          )
          if (xs) {
            isSaved <- TRUE
            # store dim
            slot(obj, s) <- reset_slot(slot(obj, s))
            obj <- setObjPath(obj, path = fp(path))
          }
        }
      }
    }
  } else if (save_not_S4 && NROW(obj) >= max(1L, min_rows)) {
    x <- data2disk(
      obj = obj,
      path = fp(path),
      format = format, verbose = verbose
    )
    if (x) {
      isSaved <- TRUE
      # store dim
      obj <- reset_slot(obj)
    }
  }
  # mark if any data is on disk
  # if (inherits(obj, "scenario")) browser()
  if (isSaved) {
    obj <- mark_ondisk(obj)
    obj <- setObjPath(obj, path = path)
    # } else {
    #   obj <- mark_inMemory(obj)
  }
  return(obj)
}

reset_slot <- function(x) {
  if (inherits(x, "data.frame")) {
    return(as.data.table(x)[0, ])
  }
  if (is.vector(x)) {
    return(x[0])
  }
  return(x)
}


rename_duplicated_sets <- function(x) {
  # x - table
  stopifnot(inherits(x, "data.frame"))
  nm <- colnames(x)
  # nm <- c("a", "b", "c", "b", "b", "a", "a", "a")
  ii <- duplicated(nm)
  if (any(ii)) {
    all_sets <- unique(nm)
    # !!! add check for numeric endings !!!
    # nm <- c("a", "b", "c", "b2", "b", "a", "a5", "a")
    for (s in all_sets) {
      jj <- nm %in% s
      if (length(nm[jj]) > 1) {
        nm2 <- c(s, paste0(s, seq(2, length(nm[jj]))))
        nm[jj] <- nm2
      }
    }
    colnames(x) <- nm
  }
  x
}

anyDuplicatedSets <- function(x) {
  if (!inherits(x, "data.frame")) {
    return(NULL)
  }
  any(duplicated(colnames(x)))
}

# The extensions each dataset format writes. `write_dataset(format =
# "feather")` names its files `.arrow`, so feather owns three spellings.
.en_format_ext <- list(
  csv = "csv", parquet = "parquet",
  feather = c("arrow", "feather", "ipc"), RData = "RData"
)

# Infer a dataset's format from the extensions present; NULL when they are
# mixed or unrecognized -- a mix means two writers disagreed about the codec,
# which arrow cannot read as one dataset.
#
# An EMPTY vector matches the first format vacuously, and that is deliberate: a
# slot with no rows writes no files, and reading such a directory as csv yields
# an empty dataset. A directory that does not exist at all still fails in the
# reader below, which is how get_lazy_data() tells "never written" (fine) from
# "written but the folder moved" (an error worth raising).
.en_sniff_format <- function(ext) {
  for (fmt in names(.en_format_ext)) {
    if (all(ext %in% .en_format_ext[[fmt]])) return(fmt)
  }
  NULL
}

# The codec to use when REWRITING an existing store. Priority:
#   1. the files already there -- authoritative, because a directory holding two
#      codecs is not a readable dataset (see en_open_dataset);
#   2. the format recorded in the owning manifest (scenario.yml / model.yml /
#      repository.yml / dataset.yml), for a store whose data dir is empty;
#   3. the storage option.
# Nothing here consults the option while files exist, so changing the option
# never mixes codecs inside a store that is already written.
.store_format <- function(data_dir = NULL, manifest = NULL) {
  if (!is.null(data_dir) && dir.exists(data_dir)) {
    ext <- unique(tools::file_ext(list.files(data_dir)))
    # only files decide; an empty store matches every format vacuously (see
    # .en_sniff_format) and must fall through to the manifest instead
    if (length(ext)) {
      fmt <- .en_sniff_format(ext)
      if (!is.null(fmt)) return(fmt)
    }
  }
  if (!is.null(manifest) && file.exists(manifest)) {
    mf <- tryCatch(yaml::read_yaml(manifest), error = function(e) NULL)
    fmt <- tolower(as.character(mf$format %||% ""))
    if (length(fmt) == 1L && nzchar(fmt)) {
      if (fmt %in% c("arrow", "ipc")) fmt <- "feather"
      if (fmt %in% names(.en_format_ext)) return(fmt)
    }
  }
  get_storage_format()
}

en_open_dataset <- function(path, format = NULL, engine = "arrow") {
  # if (basename(path) == "vObjective") browser()
  # identify format
  ff <- list.files(path)
  ext <- tools::file_ext(ff) |> unique()
  sniffed <- .en_sniff_format(ext)
  if (is.null(format)) {
    if (is.null(sniffed)) {
      stop(
        "Cannot identify format of the dataset\n     ",
        paste0(length(ff), " files or directories, extensions: '"),
        paste(ext, collapse = "', '"), "'"
      )
    }
    format <- sniffed
  } else {
    # A declared format must match what is on disk: reading parquet files as
    # feather fails deep inside arrow with an opaque message, and a directory
    # that mixes codecs cannot be one dataset whatever the caller declares.
    format <- tolower(format)
    if (format %in% c("arrow", "ipc")) format <- "feather"
    if (!format %in% names(.en_format_ext)) {
      stop("Unknown dataset format: '", format, "'.")
    }
    if (length(ext) && !all(ext %in% .en_format_ext[[format]])) {
      stop("Dataset '", path, "' was opened as '", format,
           "' but holds extensions '", paste(ext, collapse = "', '"),
           "'. The store's recorded format and its files disagree.")
    }
  }

  if (engine == "arrow") {
    if (format == "csv") {
      return(arrow::open_csv_dataset(path))
    }
    if (format == "parquet") {
      return(arrow::open_dataset(path))
    }
    if (format %in% c("feather", "arrow", "ipc")) {
      return(arrow::open_dataset(path, format = "feather"))
    }
  }
  if (format == "RData") {
    # load
    stop("Reading an on-disk dataset in RData format is not implemented.",
         call. = FALSE)
    return(NULL)
  }
}


#' Is object stored in memory?
#'
#' @param object Object, checks
#'
#' @return Logical value, TRUE if object is stored in memory, FALSE if on disk.
#'
#' @export
#'
#' @examples
#' \dontrun{
#' isInMemory(scen_BASE)
#' }
isInMemory <- function(object) {
  if (!isS4(object)) {
    has_path <- try({!is.null(object$misc$inMemory)}, silent = TRUE)
    if (inherits(has_path, "try-error")) {
      return(TRUE)
    }
    if (is.character(has_path)) {
      return(!is.null(object$path))
    }
    return(TRUE)
  }
  sts <- slotNames(object)
  if (any(sts %in% "inMemory")) {
    return(object@inMemory)
  } else if (any(sts %in% "misc")) {
    if (!is.null(object@misc$inMemory)) {
      return(object@misc$inMemory)
    }
  }
  return(TRUE)
}

#' Is object stored on disk?
#'
#' The complement of [isInMemory()]. An on-disk object holds its data in an
#' Arrow dataset rather than in its slots, so reading it is a scan rather than a
#' subset -- which is what makes predicate pushdown possible for it and
#' pointless for an in-memory one.
#'
#' @param object Object, checks
#'
#' @return Logical value, TRUE if object is stored on disk, FALSE if in memory.
#'
#' @seealso [isInMemory()]
#' @export
#'
#' @examples
#' \dontrun{
#' isOnDisk(scen_BASE)
#' }
isOnDisk <- function(object) {
  !isInMemory(object)
}


getObjPath <- function(obj, path = NULL) {
  if (!isS4(obj)) {
    return(NULL)
  }
  sts <- slotNames(obj)
  if (any(sts %in% "path")) {
    return(obj@path)
  } else if (any(sts %in% "misc")) {
    if (!is.null(obj@misc$path)) {
      return(obj@misc$path)
    }
  }
  return(NULL)
}

setObjPath <- function(obj, path = NULL) {
  if (!isS4(obj)) {
    return(obj)
  }
  sts <- slotNames(obj)
  if (any(sts %in% "path")) {
    obj@path <- path
    return(obj)
  } else if (any(sts %in% "misc")) {
    obj@misc$path <- path
    return(obj)
    # }
  }
  return(obj)
}


get_lazy_data <- function(obj,
                          slot = NULL, element = NULL,
                          InMemory = isInMemory(obj),
                          path = NULL,
                          collect_data = TRUE,
                          default = NULL,
                          optional = FALSE,
                          filter = NULL
                          ) {
  # check if the object is "inMemory"
  if (InMemory) {
    if (is.null(slot)) {
      x <- obj
    } else {
      if (!.hasSlot(obj, slot)) {
        return(NULL)
      }
      x <- slot(obj, slot)
    }
    if (!is.null(element)) x <- x[[element]]
    return(.en_apply_filter(x, filter))
  }
  if (is.null(path)) path <- getObjPath(obj)
  stopifnot(!is.null(path))
  if (!is.null(slot) && !.hasSlot(obj, slot)) {
    return(NULL)
  }
  path <- paste(c(path, slot, element), collapse = "/")
  if (file.exists(path) || dir.exists(path)) path <- normalizePath(path)
  qu <- try(en_open_dataset(path), silent = TRUE)
  if (inherits(qu, "try-error")) {
    ff <- list.files(path)
    if (length(ff) == 0) {
      # Distinguish "never written" (an empty slot writes no dataset — normal)
      # from "written but not there" (the folder was moved/renamed): the
      # object's own onDisk bookkeeping records what was saved. Silently
      # returning NULL in the second case made every result of a moved
      # scenario come back as zero rows.
      expected <- tryCatch({
        od <- if (.hasSlot(obj, "misc")) obj@misc$onDisk else NULL
        if (!is.null(slot)) od <- od[[slot]]
        if (!is.null(element)) od <- od[[element]]
        isTRUE(od$dim[1] > 0) || isTRUE(od$length > 0)
      }, error = function(e) FALSE)
      if (expected && !optional) {
        # Classed, so a caller can tell a FAILED READ from an absent
        # variable. Report code that wraps getData() in a tryCatch otherwise
        # has to treat both as "no data", which turns a moved folder into
        # silently empty output. The message is unchanged.
        stop(errorCondition(
          paste0("On-disk data expected but not found: ", path, "\n",
                 "  The scenario/model folder may have been moved or renamed. ",
                 "Re-load it with load_scenario() / load_model() to rebase ",
                 "its paths."),
          class = c("energyRt_ondisk_missing", "energyRt_error"),
          path = path))
      }
      return(NULL)
    }
    stop("Cannot open dataset: ", path, "\n",
        "Files: ", paste(ff, collapse = ", "))
  }
  # Push the predicate into the Arrow query so only matching row groups /
  # batches are read. Filtering after collect() reads the whole dataset first.
  qu <- .en_apply_filter(qu, filter)
  if (collect_data) {
    qu <- collect(qu)
  }
  if (is.null(qu)) {return(default)}
  return(qu)
}

get_lazy_dim_names <- function(obj, slot = NULL, element = NULL,
                               InMemory = isInMemory(obj),
                               path = NULL) {
  # returns dim and names of the object's slot if available
  # if (obj@name == "pTechStock") browser()
  ll <- list(
    dim = NULL,
    names = NULL
  )
  # check if the object is "inMemory"
  if (InMemory) {
    if (is.null(slot)) {
      x <- obj # slot is not assigned
    } else {
      if (!.hasSlot(obj, slot)) {
        return(ll)
      }
      x <- slot(obj, slot)
    }
    if (!is.null(element)) x <- x[[element]]
    ll$dim <- dim(x)
    ll$names <- colnames(x)
    return(ll)
  }
  # not inMemory object
  if (is.null(path)) path <- getObjPath(obj)
  stopifnot(!is.null(path))
  # browser() !!! Add path check

  if (!is.null(slot) && !.hasSlot(obj, slot)) {
    return(ll) # no data
  }
  # One branch for `parameter` and `variable` alike. The `modOut` container used
  # to be handled separately, reading `colnames()` off the list ELEMENT; once
  # those elements became S4 objects that returned NULL, which `findData()`'s
  # value-column filter reads as "no value column" -- silently dropping every
  # variable from `getData()`. Passing the object itself removes the trap.
  if (inherits(obj, "modelData")) {
    ll$dim <- obj@misc$onDisk[[slot]]$dim
    ll$names <- slot(obj, slot) |> colnames()
  } else {
    stop("get_lazy_dim_names: not implemented for object type ", class(obj))
  }
  # ll$names <- obj@misc$onDisk[[slot]]$dimnames
  # path <- paste(c(path, slot, element), collapse = "/") |> normalizePath()
  # qu <- try(en_open_dataset(path), silent = TRUE)
  # if (inherits(qu, "try-error")) {
  #   return(ll)
  # }
  return(ll)
}



# On-disk directory layout version, written to `<scen>/layout` by
# `save_scenario()` and checked by `load_scenario()`.
#   1  modOut@variables stored as `variables/<v>/`      (data.frames)
#   2  modOut@variables stored as `variables/<v>/data/` (`variable` objects)
#   3  solve artifacts + the solution store live per run under
#      `runs/[<variant>/]<solve>/{run.yml, solver/, modOut/}`; the scenario
#      carries a `scenario.yml` manifest (default_variant, active run).
#      Layout 2 is still readable; `save_scenario()` writes only 3.
.SCENARIO_LAYOUT <- 3L

.save_slots <- list(
  weather = c("weather"),
  demand = c("demand"),
  repository = c("data"),
  model = c("data"),
  parameter = c("data"),
  # Without this entry `set_ondisk_slots()` finds no match for a `variable`,
  # `@misc$onDisk` is never recorded, nothing is written, and `save_scenario()`
  # reports success having stored no results at all.
  variable = c("data"),
  modInp = c("parameters"),
  modOut = c("variables"),
  scenario = c("model", "modInp", "modOut")
)

set_ondisk_slots <- function(obj) {
  # obj - object to be marked
  for (o in names(.save_slots)) {
    if (inherits(obj, o)) {
      if (.hasSlot(obj, "misc")) {
        obj@misc$onDisk <- list()
        for (s in .save_slots[[o]]) {
          obj@misc$onDisk[[s]] <- list()
          if (inherits(slot(obj, s), "list")) {
            for (i in names(slot(obj, s))) {
              obj@misc$onDisk[[s]][[i]] <- list()
              obj@misc$onDisk[[s]][[i]]$class <- class(slot(obj, s)[[i]])
              obj@misc$onDisk[[s]][[i]]$dim <- dim(slot(obj, s)[[i]])
              obj@misc$onDisk[[s]][[i]]$length <- length(slot(obj, s)[[i]])
              obj@misc$onDisk[[s]][[i]]$size <- object.size(slot(obj, s)[[i]])
            }
          } else {
            obj@misc$onDisk[[s]] <- list()
            obj@misc$onDisk[[s]]$class <- class(slot(obj, s))
            obj@misc$onDisk[[s]]$dim <- dim(slot(obj, s))
            obj@misc$onDisk[[s]]$length <- length(slot(obj, s))
            obj@misc$onDisk[[s]]$size <- size(slot(obj, s))
          }
        }
      } else {
        stop("Object has no slot 'misc'")
      }
    }
  }
  return(obj)
}

get_ondisk_slots <- function(obj) {
  if (!isS4(obj)) {
    return(NULL)
  }
  if (!.hasSlot(obj, "misc")) {
    return(NULL)
  }
  return(names(obj@misc$onDisk))
}

mark_ondisk <- function(obj) {
  sts <- slotNames(obj)
  if (any(sts %in% "inMemory")) {
    obj@inMemory <- FALSE
    return(obj)
  } else if (any(sts %in% "misc")) {
    obj@misc$inMemory <- FALSE
    return(obj)
  }
  return(obj)
}

mark_inMemory <- function(obj) {
  sts <- slotNames(obj)
  if (any(sts %in% "inMemory")) {
    obj@inMemory <- TRUE
    return(obj)
  } else if (any(sts %in% "misc")) {
    obj@misc$inMemory <- TRUE
    return(obj)
  }
  return(obj)
}


# load_scenario <- function(path, inMemory = FALSE) {
#
# }


#' Load scenario (in progress)
#'
#' @section Slots stay on disk:
#' A loaded scenario keeps its data-frame slots in the Arrow store rather than
#' in memory, so reading one directly — `obj@demand`, `obj@capacity` — returns
#' an **empty frame** rather than the data, and `isInMemory()` is `FALSE`.
#' [getData()] goes through the lazy store and is unaffected, so it is the
#' route to use; `findData()` and [get_variable()] likewise. This bites report
#' and plotting code written against an in-memory model, where the symptom is
#' an empty table rather than an error.
#'
#' @param path character. Path to saved with function `save_scenario` scenario directory.
#' @param name character. Name to assign to the loaded scenario object.
#' By default, the name is taken from the loaded scenario object.
#' @param env environment. Environment to assign the loaded scenario object.
#' @param overwrite logical. Overwrite existing scenario object in the environment.
#' @param ignore_errors logical. Ignore load errors and continue execution.
#' This option is useful when some data is missing or corrupted.
#' @param verbose logical. Print messages.
#'
#' @return TRUE if scenario is loaded, FALSE if not.
#' @export
#'
#' @examples
#' \dontrun{
#' load_scenario("scenarios/base")
#' }
load_scenario <- function(
    path,
    name = NULL,
    env = .scen,
    overwrite = FALSE,
    ignore_errors = FALSE,
    verbose = TRUE) {
  # A `path` that is not an existing file/directory is resolved as a
  # scenario NAME: registry first, then a scan of the scenarios store
  # (see .scenario_resolve).
  if (!file.exists(path) && !dir.exists(path)) {
    resolved <- if (!grepl("[\\/]", path)) .scenario_resolve(path) else NULL
    if (is.null(resolved)) {
      msg <- paste0(
        "'", path, "' is neither an existing scenario directory nor a ",
        "registered scenario name.\n",
        "  Run refresh_registry() to rescan the scenarios store ('",
        get_scenarios_path(), "'), or pass the folder path.")
      if (!ignore_errors) stop(msg)
      if (verbose) message(msg)
      return(invisible(FALSE))
    }
    path <- resolved
  }
  # Anchor the path absolutely before anything is derived from it. The on-disk
  # slot paths are rebased onto `scen_root` below, so a relative path here is
  # kept verbatim and every later read breaks the moment the working directory
  # changes -- as it does inside rmarkdown::render().
  path <- normalizePath(path, winslash = "/", mustWork = FALSE)
  finf <- file.info(path)
  if (finf$isdir) {
    .mark_notice("scenario", path, basename(path))
    # Layout check before anything is read. An older directory stores each
    # variable's data one level up from where this version looks for it, and
    # that reads as "no data" rather than as an error -- so refuse it outright.
    lay <- fp(path, "layout")
    ver <- if (file.exists(lay)) {
      suppressWarnings(as.integer(readLines(lay, warn = FALSE)[1]))
    } else {
      1L
    }
    if (is.na(ver) || !(ver %in% c(2L, 3L))) {
      msg <- paste0(
        "Scenario directory '", path, "' uses on-disk layout ",
        if (is.na(ver)) "?" else ver, ", this version of energyRt reads ",
        "layouts 2 and 3.\n",
        "  Layout 2 moved each variable's data from `variables/<name>/` to ",
        "`variables/<name>/data/` when `modOut@variables` became a list of ",
        "`variable` objects.\n",
        "  Re-run and re-save the scenario with this version."
      )
      if (!ignore_errors) stop(msg)
      if (verbose) message(msg)
      return(invisible(FALSE))
    }
    if (ver == 2L && verbose) {
      message(
        "Scenario '", basename(path), "' uses on-disk layout 2; it loads ",
        "fine. Run upgrade_scenario_layout('", path, "') to migrate it to ",
        "layout 3 (per-run folders with provenance under runs/)."
      )
    }
    scen_root <- path # the directory actually being loaded (for path rebase)
    path <- fp(path, "scen.RData")
    if (!file.exists(path)) {
      msg <- paste0("Scenario file '", path, "' has not been found.")
      if (!ignore_errors) stop(msg)
      if (verbose) message(msg)
      return(invisible(FALSE))
    }
  } else {
    scen_root <- dirname(path)
  }
  if (!(exists(".en_tmp") && is.environment(.en_tmp))) {
    .en_tmp <- new.env(parent = .GlobalEnv)
  }
  # on.exit(rm(.en_tmp))
  nm <- load(path, envir = .en_tmp)
  if (length(nm) != 1) {
    msg <- paste0(
      "Scenario file '", path,
      "' must contain only one (scenario) object",
      ", actual number of objects: ", length(nm)
    )
    if (!ignore_errors) stop(msg)
    if (verbose) message(msg)
    return(invisible(FALSE))
  }
  if (!inherits(get(nm, envir = .en_tmp), "scenario")) {
    msg <- paste0(
      path, " must contain a 'scenario' object; actual class: ",
      class(get(nm, envir = .en_tmp))
    )
    if (!ignore_errors) stop(msg)
    if (verbose) message(msg)
    return(invisible(FALSE))
  }
  scen_obj <- get(nm, envir = .en_tmp)

  # migrate modInp objects saved before the 2026-08 slot cleanup
  # (set -> sets; gams.equation/costs.equation -> user_constraints/user_costs)
  scen_obj@modInp <- .upgrade_modInp(scen_obj@modInp)

  # Rebase every stored path onto the folder actually loaded: the saved
  # object recorded save-time paths (relative to the then-working directory),
  # which break when the folder is moved or getwd() differs. Deterministic
  # reconstruction, so nothing depends on the stored strings.
  scen_obj <- tryCatch(
    .scenario_rebase_paths(scen_obj, scen_root),
    error = function(e) {
      warning("Could not rebase the scenario's on-disk paths (",
              conditionMessage(e), ")", call. = FALSE)
      scen_obj
    })

  # restore the sourceCode blocks dropped at save time (identical to the
  # package templates then; refilled from the CURRENT package — a re-solve
  # uses current code, and the run's actual script is preserved in its run
  # directory). User-overridden blocks were saved verbatim and stay.
  dk <- scen_obj@misc$sourceCode_default
  if (length(dk)) {
    for (k in dk) {
      if (is.null(scen_obj@settings@sourceCode[[k]])) {
        scen_obj@settings@sourceCode[[k]] <- .modelCode[[k]]
      }
    }
  }

  # resolve a model reference (scenario saved with embed_model ref)
  ref <- scen_obj@model@misc$model_ref
  if (!is.null(ref)) {
    mod <- tryCatch(
      load_model(ref$name, hash = ref$hash, verbose = FALSE),
      error = function(e) NULL)
    if (is.null(mod) && !is.null(ref$path)) {
      cand <- fp(dirname(get_registry_file()), ref$path)
      cand_h <- tryCatch(yaml::read_yaml(fp(cand, "model.yml"))$hash,
                         error = function(e) "")
      # accept the recorded path only when it still holds the recorded
      # VERSION — an in-place-updated entry falls through to the warning
      if (file.exists(fp(cand, "mod.RData")) &&
          startsWith(cand_h %||% "", ref$hash %||% "")) {
        mod <- tryCatch(load_model(ref$name, path = cand, verbose = FALSE),
                        error = function(e) NULL)
      }
    }
    if (is.null(mod)) {
      # exact version gone (entry updated in place): resolve by NAME, warn
      cur <- tryCatch(.model_store_resolve(ref$name, NULL),
                      error = function(e) NULL)
      if (!is.null(cur)) {
        cur_h <- tryCatch(yaml::read_yaml(fp(cur, "model.yml"))$hash,
                          error = function(e) "")
        mod <- tryCatch(load_model(ref$name, path = cur, verbose = FALSE),
                        error = function(e) NULL)
        if (!is.null(mod)) {
          warning("Scenario '", scen_obj@name, "' references model '",
                  ref$name, "' @", substr(ref$hash %||% "", 1, 8),
                  "; the store now holds @", substr(cur_h %||% "", 1, 8),
                  " — loading the current version. Results may not ",
                  "reproduce; re-save the scenario to adopt it, or seal_model() the ",
                  "inputs of finished work.", call. = FALSE)
        }
      }
    }
    if (is.null(mod)) {
      msg <- paste0(
        "Scenario '", scen_obj@name, "' references model '", ref$name, "@",
        substr(ref$hash %||% "", 1, 8), "' which is not in the registry or ",
        "the model store ('", get_models_path(), "').\n",
        "  Run refresh_registry() to rescan, or re-save the scenario with ",
        "embed_model = TRUE from a session that has the model."
      )
      if (!ignore_errors) stop(msg)
      if (verbose) message(msg)
      return(invisible(FALSE))
    }
    scen_obj@model <- mod
    if (verbose) {
      message("Model '", ref$name, "' resolved from the model store")
    }
  }

  # resolve dataset references: the geoscale map on @settings, and — for an
  # embedded model — its geoscale and its repositories' big tables (a
  # referenced model already resolved its own datasets in load_model())
  resolve_ds <- function() {
    scen_obj@settings <<- .resolve_dataset_refs(scen_obj@settings,
                                                verbose = verbose)
    if (is.null(ref) && is(scen_obj@model, "model")) {
      scen_obj@model@config <<- .resolve_dataset_refs(scen_obj@model@config,
                                                      verbose = verbose)
      for (rp in names(scen_obj@model@data)) {
        repo <- scen_obj@model@data[[rp]]
        if (!is(repo, "repository")) next
        for (ob in names(repo@data)) {
          o <- repo@data[[ob]]
          if (isS4(o) && .hasSlot(o, "misc")) {
            repo@data[[ob]] <- .resolve_dataset_refs(o, verbose = verbose)
          }
        }
        scen_obj@model@data[[rp]] <<- repo
      }
    }
    TRUE
  }
  ds_ok <- tryCatch(resolve_ds(), error = function(e) e)
  if (inherits(ds_ok, "error")) {
    if (!ignore_errors) stop(ds_ok)
    if (verbose) message(conditionMessage(ds_ok))
    return(invisible(FALSE))
  }

  # scen.RData holds the BASE problem; the manifest's `default:` run names
  # what should be ACTIVE. When that is a variant run, activate it — the
  # loaded object then matches what was last saved, exactly as before the
  # problem.RData retirement.
  def <- tryCatch(.scenario_default_run(scen_obj), error = function(e) NULL)
  if (!is.null(def) && nzchar(def$variant %||% "") &&
      !identical(def$variant, .run_variant(scen_obj))) {
    scen_act <- tryCatch(
      read_solution(scen_obj, run = .run_id(def$variant, def$solve),
                    echo = FALSE),
      error = function(e) {
        if (verbose) {
          message("Could not activate the default run '",
                  .run_id(def$variant, def$solve), "': ",
                  conditionMessage(e))
        }
        NULL
      })
    if (!is.null(scen_act)) scen_obj <- scen_act
  }
  assign(nm, scen_obj, envir = .en_tmp)

  if (is.null(name)) name <- get(nm, envir = .en_tmp)@name
  if (is.null(env)) {
    scen <- get(nm, envir = .en_tmp)
    return(scen)
  }
  if (exists(name, envir = env) & !overwrite) {
    msg <- paste0(
      "Scenario '", name,
      "' already exists in 'env' environment. \n",
      "Use 'overwrite = TRUE' or different name"
    )
    if (!ignore_errors) stop(msg)
    if (verbose) message(msg)
    return(invisible(FALSE))
  }
  if (!exists(name, envir = env) | overwrite) {
    assign(name, get(nm, envir = .en_tmp), envir = env)
    assign(nm, NULL, envir = .en_tmp)
    return(invisible(TRUE))
  }
  # assign(name, get(nm, envir = .en_tmp), envir = env)
  # assign(nm, NULL, envir = .en_tmp)
  # return(invisible(TRUE))
  # return(get(name, envir = env))
  # return(nm)
  return(invisible(FALSE))
}

#' Load several registered scenarios at once
#'
#' @description
#' The batch companion of [load_scenario()]: resolves scenario NAMES through
#' the project registry (all registered scenarios by default) and loads each
#' as a thin on-disk shell. The result — a named list, or a filled
#' environment — feeds [getData()] directly:
#' `getData(load_scenarios(), name = "vTechOut", merge = TRUE)`.
#'
#' A registered scenario whose folder is gone is skipped with a warning
#' (run [refresh_registry()] to drop the stale row).
#'
#' @param names character, scenario names to load; `NULL` (default) = every
#'   scenario in the registry.
#' @param run character, optional run id to activate in each loaded scenario
#'   via [read_solution()] (scenarios without that run keep their default,
#'   with a warning).
#' @param env environment to assign the scenarios into (e.g. `.scen`), or
#'   `NULL` (default) to return them as a named list.
#' @param verbose logical.
#' @return a named list of scenarios, or (with `env=`) the loaded names,
#'   invisibly.
#' @rdname load_scenario
#' @export
load_scenarios <- function(names = NULL, run = NULL, env = NULL,
                           verbose = TRUE) {
  if (is.null(names)) {
    reg <- .registry_open()
    names <- find_in_registry(reg, type = "scenario")$name
  }
  stopifnot(is.character(names))
  out <- list()
  for (nm in names) {
    sc <- tryCatch(
      load_scenario(nm, env = NULL, verbose = verbose),
      error = function(e) {
        warning("Scenario '", nm, "' could not be loaded: ",
                conditionMessage(e), call. = FALSE)
        NULL
      })
    if (is.null(sc)) next
    if (!is.null(run)) {
      sc <- tryCatch(read_solution(sc, run = run, echo = FALSE),
                     error = function(e) {
                       warning("Scenario '", nm, "' has no run '", run,
                               "'; keeping its default solution.",
                               call. = FALSE)
                       sc
                     })
    }
    out[[nm]] <- sc
  }
  if (is.null(env)) return(out)
  for (nm in names(out)) assign(nm, out[[nm]], envir = env)
  invisible(names(out))
}

## - DRAFTS -------------------------------------------------------####

#' Loads objects from disk to memory
#'
#' @param object Object of S4 class, saved on disk (scenario, model, etc.)
#' @param verbose If TRUE, prints messages
#'
#' @return Object of the same S4 class as input object, with
#' all of the slots loaded in memory.
#' @export
#'
#' @examples
#' \dontrun{
#' obj2mem(scen_ondisk)
#' }
obj2mem <- function(object, verbose = isVerbose()) {
  if (!isS4(object)) {
    stop("Object must be of S4 class, actual class: ", class(object))
  }
  if (isInMemory(object)) return(invisible(object))
  if (!.hasSlot(object, "misc")) {
    stop("Object of class ", class(object), " has no 'misc' slot")
  }
  sls <- names(object@misc$onDisk)
  if (isDebug() && length(sls) == 0)
    cli::cli_warn("{obj@name}: marked on-disk but @misc$onDisk lists no slots.")
  obj_pth <- getObjPath(object)
  for (s in sls) {
    pth <- fp(obj_pth, s)
    if (isS4(slot(object, s))) {
      # cat(getObjPath(slot(object, s)), "\n")
      slot(object, s) <- obj2mem(slot(object, s), verbose = verbose)
    } else if (inherits(slot(object, s), "list")) {
      sls2 <- names(object@misc$onDisk[[s]])
      # A repository's `@data` is where the object count lives (thousands on
      # a converted model), so report progress there instead of printing one
      # path per table. Mirrors `obj2disk()`, and stays silent unless the
      # caller registered a handler (see `set_progress_bar()`).
      p <- if (length(sls2) > 1L) progressr::progressor(along = sls2) else NULL
      for (i in sls2) {
        if (!is.null(p)) p(i)
        if (isS4(slot(object, s)[[i]])) {
          slot(object, s)[[i]] <- obj2mem(slot(object, s)[[i]], verbose = verbose)
        } else {
          if (object@misc$onDisk[[s]][[i]]$dim[1] == 0) next
          pth2 <- fp(pth, i)
          if(verbose) cat(pth2, "\n")
          slot(object, s)[[i]] <- en_open_dataset(pth2) |> collect()}
      }
      # cat(s, "\n")
    } else {
      if (object@misc$onDisk[[s]]$dim[1] == 0) next
      if(verbose) cat(pth, "\n")
      slot(object, s) <- en_open_dataset(pth) |> collect()
    }
  }
  object <- mark_inMemory(object)
  invisible(object)
}


# compare_slots <- function(obj1, obj2) {
#
# }





# ---------------------------------------------------------------------------
# (was R/arrow_filter.R, merged 2026-09-21)
# ---------------------------------------------------------------------------

# Predicate pushdown for on-disk data ------------------------------------------
#
# A filter is a named list mapping a column to the values to keep, e.g.
# `list(timeslice = c("d001_h00", "d001_h01"), region = c("ES111", "PT111"))`.
# Applied to an Arrow query it restricts what is read from disk; applied to a
# data frame it subsets in memory, so both branches of `get_lazy_data()` return
# the same rows.
#
# Columns named in the filter that the data does not have are ignored: a filter
# is a restriction on the dimensions a dataset happens to carry, and requiring
# every dataset to carry every dimension would make it unusable as a default.

# Apply a named-list filter to an Arrow query or a data frame.
.en_apply_filter <- function(x, filter) {
  if (is.null(x) || is.null(filter) || !length(filter)) return(x)
  if (!is.list(filter) || is.null(names(filter)) || any(!nzchar(names(filter)))) {
    stop("`filter` must be a named list of column = allowed values",
         call. = FALSE)
  }
  cols <- .en_filter_cols(x)
  if (is.null(cols)) return(x)
  for (nm in names(filter)) {
    vals <- filter[[nm]]
    if (!nm %in% cols || is.null(vals) || !length(vals)) next
    x <- if (inherits(x, "data.frame")) {
      x[as.character(x[[nm]]) %in% as.character(vals), , drop = FALSE]
    } else {
      # `filter()` on an arrow_dplyr_query is lazy; the restriction reaches the
      # scanner and limits what is read.
      dplyr::filter(x, !!rlang::sym(nm) %in% !!as.character(vals))
    }
  }
  x
}

# Column names of an Arrow query, Dataset or data frame; NULL when unknown.
.en_filter_cols <- function(x) {
  if (inherits(x, "data.frame")) return(names(x))
  out <- tryCatch(names(x), error = function(e) NULL)
  if (is.null(out)) out <- tryCatch(x$schema$names, error = function(e) NULL)
  out
}

