## Python/Pyomo
## No `export_format`/`import_format`: both fall through to the
## `exchange_format` option (Arrow IPC by default). See the `*_sqlite` /
## `*_rdata` presets below for the legacy containers.
Pyomo <- list(
  name = "pyomo",
  lang = "PYOMO",
  # solver = "cplex"
  # solver = "glpk"
  solver = "cbc"
)

pyomo_cbc <- Pyomo
pyomo_cbc$name <- "pyomo_cbc"


pyomo_cplex <- Pyomo
pyomo_cplex$name <- "pyomo_cplex"
pyomo_cplex$solver <- "cplex"

pyomo_cplex_barrier <- pyomo_cplex
pyomo_cplex_barrier$name <- "pyomo_cplex_barrier"

pyomo_cbc <- Pyomo; pyomo_cbc$name <- "pyomo_cbc"

pyomo_cplex <- Pyomo
pyomo_cplex$solver <- "cplex"; pyomo_cplex$name <- "pyomo_cplex"

pyomo_cplex_barrier <- pyomo_cplex;
pyomo_cplex_barrier$name <- "pyomo_cplex_barrier"
pyomo_cplex_barrier$inc4 <- {
"opt.options['lpmethod'] = 4
opt.options['solutiontype'] = 2"}

pyomo_glpk <- Pyomo
pyomo_glpk$name <- "pyomo_glpk"
pyomo_glpk$solver <- "glpk"

## HiGHS through Pyomo's APPSI interface.
##
## `appsi_highs` talks to HiGHS in-process through `highspy` rather than writing
## an LP/NL file and invoking an external binary. Requires `highspy` in the
## Python environment; see `en_install_python_deps()` for the version constraint.
pyomo_highs <- Pyomo
pyomo_highs$name <- "pyomo_highs"
pyomo_highs$solver <- "appsi_highs"

## Interior point, matching `julia_highs_barrier` exactly. HiGHS spells the
## choice `solver = ipm`.
##
## Crossover is off. Crossover recovers a basic (vertex) solution from the
## interior point and does not scale: on a large LP it can cost more than the
## barrier solve itself. Off is the usual setting for energy-system models and
## matches `julia_highs_barrier`.
##
## Consequence for duals: without crossover the duals are INTERIOR-POINT duals
## -- a point in the interior of the optimal dual face rather than a vertex of
## it. On a degenerate LP (ties between marginal units, common in these models)
## a vertex dual would be an arbitrary pick among many; the interior point is
## the better-behaved choice, not a worse one. (Relevant to the parked duals
## feature, drafts/duals.R.)
pyomo_highs_barrier <- pyomo_highs
pyomo_highs_barrier$name <- "pyomo_highs_barrier"
pyomo_highs_barrier$inc4 <- {
"opt.options['solver'] = 'ipm'
opt.options['run_crossover'] = 'off'"}

## Write a named free-MPS file instead of solving. `inc4` runs after the model is
## complete and before `opt.solve()`, so the model can be serialised and the solve
## skipped. `symbolic_solver_labels` keeps energyRt's own variable and constraint
## names; JuMP's `write_to_file` emits generic `c1_2`/`OBJ` labels instead, which
## cannot be mapped back to model objects. For handing a model to an external
## solver (e.g. NVIDIA cuOpt's `cuopt_cli`) and reading the solution back.
pyomo_mps <- pyomo_highs
pyomo_mps$name <- "pyomo_mps"
pyomo_mps$inc4 <- {
"model.write('model.mps', io_options={'symbolic_solver_labels': True})
print('MPS written to model.mps; skipping solve', flush=True)
raise SystemExit(0)"}

## The matrix routes #########################################################
# Three ways to reach a solver through an MPS file, differing in WHO WRITES THE
# MATRIX -- which is also what decides how the solution is read back:
#
#   writer    row/col names in the MPS      decoded by
#   Pyomo     symbolic, ~67 chars           inst/python/sol_to_energyrt.py
#   multimod  positional (c0, r0)           the _col_index / _row_index files
#
# Positional naming is why the multimod matrix is small -- in a Pyomo MPS the
# labels are the bulk of the file (~188 B per nonzero against ~35). The cost is
# that the `.mps` means nothing without the index files written beside it, so
# they must never be separated. They stay local: the solver is sent the matrix
# alone and returns positional names, which are resolved here.
#
# `lang = "mm"` builds the matrix with multimod, straight from the AST: no
# Pyomo model is ever constructed, which is the point. The Pyomo BUILD is the
# memory wall on large models (~1 KB per nonzero), and multimod measured 1.6x
# faster and 5.4x smaller at 19.85M nonzeros.

## multimod matrix, solved locally by HiGHS, in-process ######################
# An optional `highs_options` field (named list) is passed to HiGHS as is,
# e.g. `solver$highs_options <- list(presolve = "off")`.
mm_highs <- list(
  name = "mm_highs",
  lang = "mm",
  solver = "HiGHS",
  backend = "mm"
)

# the same, solved by HiGHS's interior point method without crossover --
# the counterpart of julia_highs_barrier on the multimod matrix route
mm_highs_barrier <- mm_highs
mm_highs_barrier$name <- "mm_highs_barrier"
mm_highs_barrier$highs_options <- list(presolve = "on", solver = "ipm", run_crossover = "off")

# bounds and right-hand sides scaled by 2^-3 inside HiGHS (unscaled on return):
# for models in MW/MWh/EUR, where HiGHS warns of excessively large row bounds and
# HiPO can stall into an IPX restart. Not for models already in GW/GWh/MEUR.
mm_highs_barrier_bs3 <- mm_highs_barrier
mm_highs_barrier_bs3$name <- "mm_highs_barrier_bs3"
mm_highs_barrier_bs3$highs_options$user_bound_scale <- -3L

# the multimod matrix solved by Julia's HiGHS (HiGHS.jl): its build carries the
# HiPO interior point solver, which the R `highs` package and pip `highspy` lack,
# and HiGHS writes the solution file itself. Needs Julia with HiGHS.jl, as the
# julia_* presets do.
mm_julia_highs_barrier <- mm_highs_barrier
mm_julia_highs_barrier$name <- "mm_julia_highs_barrier"
mm_julia_highs_barrier$mm_engine <- "julia"
mm_julia_highs_barrier_bs3 <- mm_highs_barrier_bs3
mm_julia_highs_barrier_bs3$name <- "mm_julia_highs_barrier_bs3"
mm_julia_highs_barrier_bs3$mm_engine <- "julia"

## Cloud solve on a rented GPU (Hugging Face Jobs) ############################
# `backend = "mmcloud"` makes .call_solver ship the locally written matrix, run
# cuOpt on a GPU, and decode the returned solution into <solver.dir>/output/ so
# read_solution() is unchanged. Requires a Hugging Face token (set_hf_token(),
# HF_TOKEN, or `hf auth login`) and `huggingface_hub` in the python energyRt
# already uses.
#
# Local build, remote solve -- not the other way round: measured on the 41-node
# full-year model, `cpu-performance` costs MORE per hour than `a10g-large`
# ($1.90 vs $1.50), the rented cores are ~1.9x slower than a desktop, and the
# build is single-threaded, so building remotely is slower AND dearer. Cloud
# building is worth it only to escape a local memory ceiling.
#
# cuOpt returns PRIMALS ONLY -- the duals in a decoded solution are NA.
mmcloud <- mm_highs
mmcloud$name <- "mmcloud"
mmcloud$backend <- "mmcloud"
mmcloud$cloud_flavor <- "a10g-large"
mmcloud$cloud_timeout <- "3h"
# cuOpt PDLP. linopy defaults cuOpt to method=3 (barrier) because cuOpt's own
# default 0 (concurrent) crashes; barrier asked for 118.9 GB of VRAM on a 36M
# nonzero model and died on a 22 GB card. 1 is what every large model solved with.
mmcloud$gpu_method <- 1L

mmcloud_crossover <- mmcloud
mmcloud_crossover$name <- "mmcloud_crossover"
# Crossover recovers the exact vertex optimum: measured 1.5e-7 relative error
# against 2.3e-4 without, for a small extra solve.
mmcloud_crossover$gpu_solver_options <- "--crossover 1"

## multimod matrix, solved by cuOpt on a local GPU, through WSL (Windows) ####
# `mm_engine = "cuopt_wsl"`: cuOpt is distributed for Linux, so `cuopt_cli` runs
# inside WSL on the local NVIDIA card, reading the matrix under /mnt/<drive>/.
# The solver fields are the cloud route's. The install is found through the
# optional fields `wsl_user` and `cuopt_cli`, else the environment variables
# ENERGYRT_WSL_USER and ENERGYRT_CUOPT_CLI, else WSL's default user and
# `cuopt_cli` on its PATH. PDLP needs roughly 0.7 GB of GPU memory plus ~300
# bytes per presolved nonzero.
# cuOpt returns PRIMALS ONLY -- duals are NA -- unless crossover runs.
mm_cuopt_wsl <- mm_highs
mm_cuopt_wsl$name <- "mm_cuopt_wsl"
mm_cuopt_wsl$highs_options <- NULL
mm_cuopt_wsl$solver <- "cuOpt"
mm_cuopt_wsl$mm_engine <- "cuopt_wsl"
# PDLP, as on the cloud route (concurrent mode crashes; barrier exhausts GPU memory)
mm_cuopt_wsl$gpu_method <- 1L
mm_cuopt_wsl$gpu_time_limit <- 7200

mm_cuopt_wsl_crossover <- mm_cuopt_wsl
mm_cuopt_wsl_crossover$name <- "mm_cuopt_wsl_crossover"
mm_cuopt_wsl_crossover$gpu_solver_options <- "--crossover 1"

## Pyomo-written matrix, same GPU transport ###################################
# Kept because it is the route every large model solved with before the
# multimod writer existed, and because its decoder tolerates a matrix whose
# index files were lost. Prefer `mmcloud` for new work.
mmcloud_pyomo <- pyomo_mps
mmcloud_pyomo$name <- "mmcloud_pyomo"
mmcloud_pyomo$backend <- "mmcloud"
mmcloud_pyomo$cloud_flavor <- "a10g-large"
mmcloud_pyomo$cloud_timeout <- "3h"
mmcloud_pyomo$gpu_method <- 1L

mmcloud_pyomo_crossover <- mmcloud_pyomo
mmcloud_pyomo_crossover$name <- "mmcloud_pyomo_crossover"
mmcloud_pyomo_crossover$gpu_solver_options <- "--crossover 1"

## Python/Pyomo via NEOS (remote solve; no local solver, needs env var NEOS_EMAIL)
# The scenario is still BUILT locally (Pyomo reads the data into the
# ConcreteModel); only the SOLVE is dispatched to NEOS, which serialises the
# model to NL and runs the chosen commercial solver. Implemented as an
# `inc_solver` override: a tiny shim makes `opt` a duck-typed object whose
# `.solve(model, tee=...)` calls SolverManagerFactory('neos'), so the baked
# `opt.solve(model, tee=True)` in the template works unchanged and the solution
# is loaded back for the usual output extraction. `solver` must be unset (the
# writer forbids both `solver` and `inc_solver`).
# `options` is a named list of CPLEX/solver option -> value passed to the remote
# solver. With no options we keep the simple string form (opt='<solver>') that
# needs no local solver plugin; with options we build a SolverFactory object and
# set its .options (Pyomo's documented way to pass solver settings via NEOS).
.pyomo_neos_inc_solver <- function(neos_solver = "cplex", options = list()) {
  head <- c(
    "import os as _os",
    "from pyomo.opt import SolverManagerFactory as _SMF",
    "if not _os.environ.get('NEOS_EMAIL'):",
    "    raise RuntimeError('Set the NEOS_EMAIL environment variable to use the pyomo NEOS backend.')")
  if (!length(options)) {
    body <- c(
      "class _NeosOpt:",
      "    def __init__(self, solver):",
      "        self._mgr = _SMF('neos'); self._solver = solver; self.options = {}",
      "    def solve(self, model, **kw):",
      "        return self._mgr.solve(model, opt=self._solver)",
      sprintf("opt = _NeosOpt('%s')", neos_solver))
  } else {
    opts_py <- paste0("{", paste(sprintf("'%s': %s", names(options),
      unlist(options)), collapse = ", "), "}")
    body <- c(
      "from pyomo.environ import SolverFactory as _SF",
      "class _NeosOpt:",
      "    def __init__(self, solver, options):",
      "        self._mgr = _SMF('neos'); self._opt = _SF(solver)",
      "        self.options = self._opt.options",
      "        for _k, _v in options.items(): self._opt.options[_k] = _v",
      "    def solve(self, model, **kw):",
      "        return self._mgr.solve(model, opt=self._opt)",
      sprintf("opt = _NeosOpt('%s', %s)", neos_solver, opts_py))
  }
  paste(c(head, body), collapse = "\n")
}

neos_pyomo_cplex <- Pyomo
neos_pyomo_cplex$name <- "neos_pyomo_cplex"
neos_pyomo_cplex$solver <- NULL
neos_pyomo_cplex$inc_solver <- .pyomo_neos_inc_solver("cplex")

neos_pyomo_cbc <- Pyomo
neos_pyomo_cbc$name <- "neos_pyomo_cbc"
neos_pyomo_cbc$solver <- NULL
neos_pyomo_cbc$inc_solver <- .pyomo_neos_inc_solver("cbc")

# CPLEX barrier (lpmethod 4) without crossover (solutiontype 2)
neos_pyomo_cplex_barrier <- Pyomo
neos_pyomo_cplex_barrier$name <- "neos_pyomo_cplex_barrier"
neos_pyomo_cplex_barrier$solver <- NULL
neos_pyomo_cplex_barrier$inc_solver <- .pyomo_neos_inc_solver(
  "cplex", list(lpmethod = 4, solutiontype = 2))


## Julia/JuMP ####
julia_cbc <- list(
  name = "julia_cbc",
  lang = "JuMP",
  solver = "Cbc"
)

julia_glpk <- list(
  name = "julia_glpk",
  lang = "JuMP",
  solver = "GLPK"
)

julia_cplex <- list(
  name = "julia_cplex",
  lang = "JuMP",
  solver = "CPLEX"
)

julia_cplex_barrier <- julia_cplex
julia_cplex_barrier$name <- "julia_cplex_barrier"
julia_cplex_barrier$inc3 <- {'
set_optimizer_attribute(model, "CPXPARAM_LPMethod", 4) # barrier CPX_ALG_BARRIER
set_optimizer_attribute(model, "CPXPARAM_SolutionType", 2) # CPX_NONBASIC_SOLN'}

julia_highs <- list(
  name = "julia_highs",
  lang = "JuMP",
  solver = "HiGHS"
)


julia_highs_barrier <- julia_highs
julia_highs_barrier$name <- "julia_highs_barrier"
julia_highs_barrier$inc3 <- c({
'# HiGHS options in JuMP/Julia
# Uncomment options to use
set_optimizer_attribute(model, "presolve", "on")
# set_attribute(model, "time_limit", 3600.0)

# "Barrier" method
set_optimizer_attribute(model, "solver", "ipm") # barrier "Interior Point Method"
# set_optimizer_attribute(model, "ipm_optimality_tolerance", 1e-5) #
set_optimizer_attribute(model, "run_crossover", "off") # polishing the solution
'
})

# the same with bounds and right-hand sides scaled by 2^-3 (see mm_highs_barrier_bs3)
julia_highs_barrier_bs3 <- julia_highs_barrier
julia_highs_barrier_bs3$name <- "julia_highs_barrier_bs3"
julia_highs_barrier_bs3$inc3 <- paste0(julia_highs_barrier$inc3,
  'set_optimizer_attribute(model, "user_bound_scale", -3) # bounds x 2^-3 (MW/MWh/EUR models)
')

julia_highs_simplex <- julia_highs
julia_highs_simplex$name <- "julia_highs_simplex"
julia_highs_simplex$inc3 <- c({
'# HiGHS options in JuMP/Julia
# Uncomment options to use
set_optimizer_attribute(model, "presolve", "on")
# set_attribute(model, "time_limit", 3600.0)

# Simplex
set_attribute(model, "solver", "simplex")
#set_attribute(model, "simplex_strategy", "on")
'})

julia_highs_parallel <- julia_highs
julia_highs_parallel$name <- "julia_highs_parallel"
julia_highs_parallel$inc3 <- c({
'# HiGHS options in JuMP/Julia
# Uncomment options to use
set_optimizer_attribute(model, "presolve", "on")
# set_attribute(model, "time_limit", 3600.0)

# Parallel Dual simplex
set_attribute(model, "solver", "choose")
set_attribute(model, "parallel", "on")
set_attribute(model, "threads", 8)
set_attribute(model, "simplex_max_concurrency", 8)
'})


## GLPK
glpk <- list(name = "glpk", lang = "GLPK")

## GAMS
# gams_path <- options::opt("gams_path")
# gams_cmd_line <- file.path(gams_path, "gams.exe energyRt.gms")

gams_cplex <- list(
  name = "gams_cplex",
  lang = "GAMS",
  solver = "CPLEX"
)

gams_gdx_cplex <- list(
  name = "gams_gdx_cplex",
  lang = "GAMS",
  import_format = "GDX",
  export_format = "GDX",
  solver = "CPLEX"
)

gams_gdx_cplex_barrier <- gams_gdx_cplex
gams_gdx_cplex_barrier$name <- "gams_gdx_cplex_barrier"
gams_gdx_cplex_barrier$inc3 <- {"
*energyRt.holdfixed = 1;
*energyRt.dictfile = 0;
*option solvelink = 5;
*option InteractiveSolver = 1;
option iterlim = 1e9;
option reslim = 1e7;
option threads = 0;
*option LP = CPLEX;
energyRt.OptFile = 1;
*option savepoint = 1;
*option bRatio = 0;
*execute_loadpoint 'energyRt_p';

$onecho > cplex.opt
*interactive 1
*advind 0
* predual 1
* BarStartAlg 4
* tuningtilim 2400
*aggcutlim 3
*aggfill 10
*aggind 25

parallelmode -1
threads -1
lpmethod 4
*reinv 1e4

*preind: turn presolver on/off (1/0)
*preind 0
*scaind 1
*scaind -1
*predual -1
solutiontype 2

*printoptions 1
names no
freegamsmodel 1
*memoryemphasis 1

*barcolnz 5
*numericalemphasis 1
*barepcomp 1e-5
*barstartalg 2
*predual 1
*baralg 1

*epopt 1e-1
*eprhs 1e-1
*dpriind 2
*ppriind 3
*perind 1
*epmrk 0.1

*tuningdisplay 2
*simdisplay 2
*bardisplay 2

*CraInd 0

$offecho
"}


gams_gdx_cplex_parallel <- gams_gdx_cplex
gams_gdx_cplex_parallel$name <- "gams_gdx_cplex_parallel"
gams_gdx_cplex_parallel$inc3 <- {
"
*energyRt.holdfixed = 1;
*energyRt.dictfile = 0;
option solvelink = 0;
*option InteractiveSolver = 1;
option iterlim = 1e9;
option reslim = 1e7;
*option threads = 0;
*option solvelink = 5;
*option LP = CPLEX;
energyRt.OptFile = 1;
*option savepoint = 1;
*option bRatio = 0;
*execute_loadpoint 'energyRt_p';
$onecho > cplex.opt
*interactive 1
* advind 0
* predual 1
* BarStartAlg 4
* tuningtilim 2400
*aggcutlim 3
*aggfill 10
*aggind 25
*bardisplay 2
parallelmode -1
lpmethod 6
*printoptions 1
*names no
*freegamsmodel 1
*memoryemphasis 1
threads -1
*barepcomp 1e-5
*scaind 1
*predual -1
*solutiontype 2

*epopt 1e-1
*eprhs 1e-1
*barepcomp 1e-5
*epmrk 0.1

$offecho
*$exit
"} # GAMS options ####

gams_cbc <- list(
  name = "gams_cbc",
  lang = "GAMS",
  solver = "CBC"
)

## GAMS via NEOS (remote solve; text data, no local GAMS/gdx; needs NEOS_EMAIL)
# backend = "neos" makes .call_solver submit the written GAMS model to NEOS and
# fetch results instead of running gams locally. Data is sent as inlined TEXT
# (no gdx), so no local GAMS install is required. neos_solver/neos_category pick
# the remote solver and NEOS problem category.
neos_gams_cplex <- gams_cplex
neos_gams_cplex$name <- "neos_gams_cplex"
neos_gams_cplex$backend <- "neos"
neos_gams_cplex$neos_solver <- "CPLEX"
neos_gams_cplex$neos_category <- "milp"

neos_gams_cbc <- gams_cbc
neos_gams_cbc$name <- "neos_gams_cbc"
neos_gams_cbc$backend <- "neos"
neos_gams_cbc$neos_solver <- "CBC"
neos_gams_cbc$neos_category <- "milp"

# CPLEX barrier: inc3 becomes inc3.gms (included by energyRt.gms), writing a
# cplex.opt with lpmethod 4 (barrier) + solutiontype 2 (no crossover). The block
# travels with the inlined model to NEOS.
neos_gams_cplex_barrier <- neos_gams_cplex
neos_gams_cplex_barrier$name <- "neos_gams_cplex_barrier"
neos_gams_cplex_barrier$inc3 <- paste(
  "energyRt.OptFile = 1;",
  "$onecho > cplex.opt",
  "lpmethod 4",
  "solutiontype 2",
  "$offecho",
  sep = "\n")

gams_gdx_cbc <- list(
  name = "gams_gdx_cbc",
  lang = "GAMS",
  import_format = "GDX",
  export_format = "GDX",
  solver = "CBC"
)

# LEGACY exchange variants. Arrow is now the default for every JuMP/Pyomo
# preset (via the `exchange_format` option), so these name the older containers
# explicitly: one SQLite database read with sqlite3/pandas, and one RData
# bundle read with RData.jl. Both keep the historical CSV solution output.
# They exist to keep the fallback reachable, documented and testable -- prefer
# the plain presets.
pyomo_cbc_sqlite <- pyomo_cbc
pyomo_cbc_sqlite$name <- "pyomo_cbc_sqlite"
pyomo_cbc_sqlite$export_format <- "SQLite"
pyomo_cbc_sqlite$import_format <- "csv"

julia_highs_rdata <- julia_highs
julia_highs_rdata$name <- "julia_highs_rdata"
julia_highs_rdata$export_format <- "RData"
julia_highs_rdata$import_format <- "csv"


# First-order (PDLP) methods. GPU execution is a build-time property of
# libhighs (-DCUPDLP_GPU=ON); with a stock HiGHS_jll these run on the CPU,
# where the HiGHS docs note they are not competitive with ipm/simplex.
# Neither method produces a basic solution and neither supports crossover,
# so duals are approximate - use ipm/simplex when shadow prices matter.
julia_highs_pdlp <- julia_highs
julia_highs_pdlp$name <- "julia_highs_pdlp"
julia_highs_pdlp$inc3 <- c({
'# HiGHS cuPDLP-C (first-order), JuMP/Julia
set_optimizer_attribute(model, "presolve", "on")
set_optimizer_attribute(model, "solver", "pdlp")
# set_optimizer_attribute(model, "time_limit", 3600.0)
'})

julia_highs_hipdlp <- julia_highs
julia_highs_hipdlp$name <- "julia_highs_hipdlp"
julia_highs_hipdlp$inc3 <- c({
'# HiGHS native HiPDLP (first-order), JuMP/Julia
set_optimizer_attribute(model, "presolve", "on")
set_optimizer_attribute(model, "solver", "hipdlp")
# set_optimizer_attribute(model, "time_limit", 3600.0)
'})


# NVIDIA cuOpt via cuOpt.jl (a MathOptInterface wrapper). GPU-accelerated.
# LINUX ONLY: cuOpt ships no Windows build, and `libcuopt.so` must be on
# LD_LIBRARY_PATH before Julia starts. cuOpt.jl pins one cuOpt release, so the
# installed cuopt-cu12 must match the wrapper's supported version.
# First-order (PDLP) solutions carry a ~1e-4 duality gap; `crossover` recovers
# a basic solution when duals are needed.
julia_cuopt <- list(
  name = "julia_cuopt",
  lang = "JuMP",
  solver = "cuOpt"
)

# Concurrent (cuOpt's default): PDLP and barrier on the GPU, dual simplex on the
# CPU, first to finish wins. Fastest on small/medium models, but barrier's
# factorization dominates GPU memory and the winner varies between runs.
julia_cuopt_concurrent <- julia_cuopt
julia_cuopt_concurrent$name <- "julia_cuopt_concurrent"
julia_cuopt_concurrent$inc3 <- c({
'# cuOpt options in JuMP/Julia
set_optimizer_attribute(model, "method", 0) # 0 = concurrent
# set_optimizer_attribute(model, "time_limit", 3600.0)
'})

# PDLP only. No factorization, so memory is linear in nonzeros - the option for
# models whose barrier factorization does not fit in GPU memory.
julia_cuopt_pdlp <- julia_cuopt
julia_cuopt_pdlp$name <- "julia_cuopt_pdlp"
julia_cuopt_pdlp$inc3 <- c({
'# cuOpt options in JuMP/Julia
set_optimizer_attribute(model, "method", 1) # 1 = PDLP (first-order, GPU)
# set_optimizer_attribute(model, "time_limit", 3600.0)
'})

# PDLP with crossover to a basic solution: needed for duals (shadow prices),
# which a first-order solution alone does not provide.
julia_cuopt_crossover <- julia_cuopt
julia_cuopt_crossover$name <- "julia_cuopt_crossover"
julia_cuopt_crossover$inc3 <- c({
'# cuOpt options in JuMP/Julia
set_optimizer_attribute(model, "method", 1) # 1 = PDLP (first-order, GPU)
set_optimizer_attribute(model, "crossover", true) # basic solution for duals
# set_optimizer_attribute(model, "time_limit", 3600.0)
'})

solver_options <- list(
  # GLPK
  glpk = glpk,
  # Python/Pyomo
  pyomo_cbc = pyomo_cbc,
  pyomo_cbc_sqlite = pyomo_cbc_sqlite,
  pyomo_cplex = pyomo_cplex,
  pyomo_cplex_barrier = pyomo_cplex_barrier,
  pyomo_glpk = pyomo_glpk,
  pyomo_highs = pyomo_highs,
  pyomo_highs_barrier = pyomo_highs_barrier,
  pyomo_mps = pyomo_mps,
  # multimod-written matrix (lang = "mm"): local HiGHS, or a rented GPU
  mm_highs = mm_highs,
  mm_highs_barrier = mm_highs_barrier,
  mm_highs_barrier_bs3 = mm_highs_barrier_bs3,
  mm_julia_highs_barrier = mm_julia_highs_barrier,
  mm_julia_highs_barrier_bs3 = mm_julia_highs_barrier_bs3,
  mm_cuopt_wsl = mm_cuopt_wsl,
  mm_cuopt_wsl_crossover = mm_cuopt_wsl_crossover,
  mmcloud = mmcloud,
  mmcloud_crossover = mmcloud_crossover,
  # Pyomo-written matrix on the same GPU transport
  mmcloud_pyomo = mmcloud_pyomo,
  mmcloud_pyomo_crossover = mmcloud_pyomo_crossover,
  # Python/Pyomo via NEOS (remote solve)
  neos_pyomo_cplex = neos_pyomo_cplex,
  neos_pyomo_cplex_barrier = neos_pyomo_cplex_barrier,
  neos_pyomo_cbc = neos_pyomo_cbc,
  # julia
  julia_cbc = julia_cbc,
  julia_cplex = julia_cplex,
  julia_cplex_barrier = julia_cplex_barrier,
  julia_highs = julia_highs,
  julia_highs_rdata = julia_highs_rdata,
  julia_highs_barrier = julia_highs_barrier,
  julia_highs_barrier_bs3 = julia_highs_barrier_bs3,
  julia_glpk = julia_glpk,
  julia_highs_simplex = julia_highs_simplex,
  julia_highs_parallel = julia_highs_parallel,
  julia_highs_pdlp = julia_highs_pdlp,
  julia_highs_hipdlp = julia_highs_hipdlp,
  julia_cuopt = julia_cuopt,
  julia_cuopt_concurrent = julia_cuopt_concurrent,
  julia_cuopt_pdlp = julia_cuopt_pdlp,
  julia_cuopt_crossover = julia_cuopt_crossover,
  # GAMS
  gams_csv_cplex = gams_cplex,
  gams_gdx_cplex = gams_gdx_cplex,
  gams_gdx_cplex_barrier = gams_gdx_cplex_barrier,
  gams_gdx_cplex_parallel = gams_gdx_cplex_parallel,
  gams_csv_cbc = gams_cbc,
  gams_gdx_cbc = gams_gdx_cbc,
  # GAMS via NEOS (remote)
  neos_gams_cplex = neos_gams_cplex,
  neos_gams_cplex_barrier = neos_gams_cplex_barrier,
  neos_gams_cbc = neos_gams_cbc
)

usethis::use_data(solver_options, overwrite = TRUE)

## Solver options - DRAFT
# solver_options <- function(
#     lang = "Pyomo",
#     export_format = "SQLite",
#     solver = "cbc",
#     algorithm = NULL,
#     inc1 = NULL,
#     inc2 = NULL,
#     inc3 = NULL,
#     inc4 = NULL,
#     inc5 = NULL
#   ) {
#
#   options <- list(
#     lang = lang,
#     export_format = export_format,
#     solver = solver,
#     inc1 = inc1,
#     inc2 = inc2,
#     inc3 = inc3,
#     inc4 = inc4,
#     inc5 = inc5
#   )
#
#   if (lang == "Pyomo") {
#     # Pyomo
#   } else if (lang == "Julia") {
#     # Julia
#   } else if (lang == "GLPK") {
#     # GLPK
#   } else if (lang == "GAMS") {
#     # GAMS
#   } else {
#     stop("Unknown language")
#   }
# }
