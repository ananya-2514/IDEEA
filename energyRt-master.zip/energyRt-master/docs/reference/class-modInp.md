# An S4 class to represent model input

`modInp` class is used to store interpolated date for the model input
parameters. It includes all the model sets, mappings, and parameters,
interpolated to the scenario's calendar and horizon. The class is
automatically created during the interpolation step and is not intended
to be created by users.

## Slots

- `sets`:

  list. named list of character vectors with sets used in the model.

- `parameters`:

  list. named list of `parameter` objects with three tipes - set:
  detailed description of the set - parameter: all model parameters,
  interpolated for every milestone year in the model horizon if
  applicable. Names of parameters start with 'p'

  - mapping sets: auxiliary, automatically created sets used to narrow
    the dimension of variables and constraints

- `user_constraints`:

  list. named list of user-defined constraints compiled from
  `constraint` objects: solver-agnostic equation code (GAMS-flavored
  intermediate representation) that each backend writer translates into
  its language. One entry per constraint.

- `user_costs`:

  character. character vector of user cost terms compiled from `costs`
  objects, in the same solver-agnostic representation; the write step
  sums them into the `eqTotalUserCosts` equation of the objective.

- `misc`:

  list. Any additional information or data to store in the object. Also
  used to store paths to the data files of objects stored on the disk.
